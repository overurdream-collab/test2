#!/usr/bin/env python3
"""Observe the real local model through the A1 API on isolated synthetic data.

Reuses the existing real-authentication/G2 API fixture setup. No live database,
migrations, real patient data or paid inference. The provider test double is
explicitly removed before the run. Failure evidence is retained.
"""
from datetime import datetime, timezone
from hashlib import sha256
import argparse
import json
import os
from pathlib import Path
import sys
import tempfile
from time import perf_counter
import traceback

ROOT=Path(__file__).resolve().parents[1]


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--model-file',required=True,type=Path)
    parser.add_argument('--output',type=Path,default=ROOT/'docs/evidence/ai-review/live-cycle.json')
    args=parser.parse_args()
    if args.output.exists():
        raise SystemExit('Preserve existing evidence; select a new output path')
    sys.path.insert(0,str(ROOT))
    report={'schema':'mcias-a1-api-live-proof-v1','started_at':datetime.now(timezone.utc).isoformat(),
        'status':'RUNNING','transport':'ASGI_TESTCLIENT','data':'GENERATED_SYNTHETIC_ONLY',
        'financially_final':False,'ocr':'DEFERRED','actual_model_calls':0,
        'limitations':['One controlled synthetic service line; not clinical accuracy or institutional acceptance.',
            'No PostgreSQL, Windows, OCR, G5 recalculation or automatic financial approval is claimed.']}
    args.output.parent.mkdir(parents=True,exist_ok=True)
    args.output.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
    with tempfile.TemporaryDirectory(prefix='mcias-ai-api-proof-') as directory:
        os.environ.update({'MCIAS_ENVIRONMENT':'development','MCIAS_DATABASE_URL':'sqlite://',
            'MCIAS_AI_MODEL_FILE':str(args.model_file.resolve()),
            'MCIAS_AI_TIMEOUT_SECONDS':'180'})
        # This isolated proof uses SQLite fixtures, not the PostgreSQL test lane.
        os.environ.pop('MCIAS_TEST_DATABASE_URL', None)
        import pytest
        from sqlalchemy import func,select
        from sqlalchemy.orm import Session
        from mcias.app import app,get_rate_limit_db
        from mcias.models import AuditLog,SourceFile
        from mcias.models_audit import AuditSnapshot
        from mcias.models_claims import ClaimEntry
        from mcias.models_ingestion import IngestionDocument
        from mcias.services import local_ai_provider as provider
        from mcias.services.registry_service import store
        from tests.api.conftest import api_factory,synthetic_password_hash
        from tests.features.conftest import features_api
        from tests.workspace_v2.test_access_and_registry import workspace
        from tests.ai.conftest import ai_case
        monkeypatch=pytest.MonkeyPatch();factory=None
        real_provider=provider.generate
        try:
            trust=Path(directory)/'rbac-test-trust.json'
            trust.write_text('{"trusted_approvers":{}}',encoding='utf-8')
            trust.chmod(0o600)
            monkeypatch.setenv('MCIAS_RBAC_TRUST_REGISTRY',str(trust))
            factory=api_factory.__wrapped__(monkeypatch,synthetic_password_hash.__wrapped__())
            make=next(factory)
            api=features_api.__wrapped__(make)
            api=workspace.__wrapped__(api,monkeypatch,Path(directory))
            case=ai_case.__wrapped__(api,monkeypatch,Path(directory))
            app.dependency_overrides[get_rate_limit_db]=api.database
            monkeypatch.setattr(provider,'generate',real_provider)
            with Session(api.engine) as db:
                before_amount=str(db.get(ClaimEntry,case.claim_id).claimed_amount)
                before_snapshots=db.scalar(select(func.count()).select_from(AuditSnapshot))
            attest=case.attest()
            assert attest.status_code==201,attest.text
            attestation=attest.json()
            tick=perf_counter()
            response=case.run(attestation)
            report['api_elapsed_seconds']=round(perf_counter()-tick,6)
            report['http_status']=response.status_code
            report['response']=response.json()
            assert response.status_code==201,response.text
            run=response.json();result=run['result']
            report['actual_model_calls']=result.get('actual_model_calls',0)
            assert run['status']=='completed',run
            assert result['provider']['provider']=='local_llama_cpp','Provider test double was not removed'
            assert result['provider']['model_sha256']==provider.MODEL_SHA256
            assert result['provider']['usage']['completion_tokens']>0
            assert result['actual_model_calls']==1
            assert result['assessment']=='signal_detected',result
            assert len(result['findings'])==1
            finding=result['findings'][0]
            assert finding['source_reported_quantity']=='1' and finding['billed_quantity']=='2'
            assert finding['supporting_quote'] in case.service_text
            assert result['review_required'] is True and run['financially_final'] is False
            duplicate=case.run(attestation)
            assert duplicate.status_code==200 and duplicate.json()['id']==run['id'],duplicate.text
            history=api.client.get(case.base+'/runs/'+run['id'],headers=api.headers['root'])
            assert history.status_code==200 and history.json()['stale'] is False
            with Session(api.engine) as db:
                assert str(db.get(ClaimEntry,case.claim_id).claimed_amount)==before_amount
                assert db.scalar(select(func.count()).select_from(AuditSnapshot))==before_snapshots
                events=list(db.scalars(select(AuditLog).where(AuditLog.resource_type=='claim_ai_review',
                    AuditLog.resource_id==run['id'])))
                assert sum(e.action=='ai_review.started'for e in events)==1
                report['audit_events']=[{'action':e.action,'resource_id':e.resource_id,'details':e.details}for e in events]
                sources=[]
                for identity,original in case.source_documents.items():
                    doc=db.get(IngestionDocument,identity);source=db.get(SourceFile,doc.source_id)
                    assert store().get(source.storage_key,source.sha256)==original
                    sources.append({'document_id':identity,'sha256':sha256(original).hexdigest(),
                        'source_bytes_unchanged':True})
                report['sources']=sources
            report.update(status='PASSED_BOUNDED_SYNTHETIC_API_PROOF',idempotency_verified=True,
                original_sources_preserved=True,financial_amount_unchanged=True,financial_snapshots_unchanged=True)
        except Exception as exc:
            report.update(status='FAILED',error_type=type(exc).__name__)
            # Synthetic-only proof error text is retained locally, never auth headers or keys.
            report['error']=str(exc)
            print('A1 API live proof failed: '+type(exc).__name__,flush=True)
        finally:
            if factory is not None:
                factory.close()
            monkeypatch.undo()
            report['finished_at']=datetime.now(timezone.utc).isoformat()
            files=('mcias/services/ai_review_service.py','mcias/services/ai_evidence_service.py',
                'mcias/services/ai_invoice_reader.py','mcias/services/ai_evidence_context.py',
                'mcias/services/local_ai_provider.py','mcias/api/ai_review_routes.py','scripts/check_ai_review_cycle.py')
            report['source_sha256']={name:sha256((ROOT/name).read_bytes()).hexdigest()for name in files}
            args.output.write_text(json.dumps(report,ensure_ascii=False,indent=2,default=str)+'\n')
    print(json.dumps({'status':report['status'],'actual_model_calls':report['actual_model_calls'],
        'evidence':str(args.output)},ensure_ascii=False),flush=True)
    return 0 if report['status']=='PASSED_BOUNDED_SYNTHETIC_API_PROOF'else 1


if __name__=='__main__':
    raise SystemExit(main())
