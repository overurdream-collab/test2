"""Signed-policy claim trial on dedicated PostgreSQL, not clinical UAT."""
from io import BytesIO
import logging.config
import os
from zipfile import ZipFile

import pytest
from sqlalchemy import func, select
from sqlalchemy.engine import make_url
from sqlalchemy.orm import Session

from mcias.app import app, get_rate_limit_db
from mcias.models import AuditLog
from mcias.models_audit import AuditSnapshot
from tests.invoices.test_claim_trial import trial_case as build_trial, assert_originals, primary_files
from tests.workspace_v2.test_access_and_registry import workspace as build_workspace
from tests.workspace_v2.test_linked_references import linked as build_linked


@pytest.mark.skipif(not os.getenv('MCIAS_CLAIM_TRIAL_TEST_DATABASE_URL'), reason='Dedicated PG claim-trial database required')
def test_signed_claim_trial_on_postgres_preserves_two_outputs_and_audit_privacy(api_factory, monkeypatch, tmp_path):
    url = os.environ['MCIAS_CLAIM_TRIAL_TEST_DATABASE_URL']
    assert make_url(url).get_backend_name() == 'postgresql'
    with monkeypatch.context() as migration_logging:
        migration_logging.setattr(logging.config, 'fileConfig', lambda *args, **kwargs: None)
        api = api_factory(url=url)
    build_workspace.__wrapped__(api, monkeypatch, tmp_path)
    build_linked.__wrapped__(api, monkeypatch)
    case = build_trial.__wrapped__(api, monkeypatch)
    monkeypatch.setitem(app.dependency_overrides, get_rate_limit_db, api.database)
    batch = case.import_batch()
    case.approve(batch)
    result = case.run(batch)
    assert result['counts'] == {'accepted': 1, 'needs_action': 0}
    assert primary_files(case, batch, result)[1] == {next(iter(batch.identities.values())): 'accepted'}
    assert_originals(case)
    with Session(api.engine) as db:
        assert db.scalar(select(func.count()).select_from(AuditSnapshot)) == 1
        events = list(db.scalars(select(AuditLog).where(AuditLog.action == 'claim_trial.completed',
                                                       AuditLog.resource_id == batch.batch_id)))
        assert len(events) == 1 and len(events[0].hash) == 64
        assert not {'beneficiary_name', 'source_values', 'invoice_match', 'quote'} & set(events[0].details)
        definitions = list(db.scalars(select(AuditLog).where(AuditLog.action == 'policy_definition.recorded',
            AuditLog.organization_id == api.organization_id)))
        assert definitions and all(len(event.resource_id) == 36 for event in definitions)
        assert all(len(event.details['policy_fingerprint']) == 64 for event in definitions)
