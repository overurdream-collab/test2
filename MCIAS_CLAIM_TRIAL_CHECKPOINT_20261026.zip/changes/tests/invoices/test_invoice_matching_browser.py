"""Chromium → real API → native PDF matching; preview never changes finances."""
from urllib.parse import urlsplit

from tests.ai.test_ai_review_browser import browser_case


def open_match(page, case, claim_id=None):
    page.evaluate('''async (id) => {
      const {openInvoiceMatch} = await import('/workspace-assets/invoice_matching.js');
      openInvoiceMatch(window.aiTest, id);
    }''', claim_id or case.claim_id)
    page.locator('[data-invoice-match]').wait_for()


def test_existing_audit_table_opens_grounded_read_only_comparison(invoice_case):
    case = invoice_case
    with browser_case(case) as (page, exchanges, held, fulfill, errors):
        page.evaluate('''async () => {
          const {auditWorkspace} = await import('/workspace-assets/audit_workspace.js');
          auditWorkspace({...window.aiTest, navigate: () => {}, scope: 'institution'});
        }''')
        page.locator('[name=audit-batch]').select_option(case.batch_id)
        row = page.locator('tr').filter(has_text=case.claim_id)
        row.get_by_role('button', name='Compare invoice', exact=True).click()
        result = page.locator('[data-invoice-match-result]')
        result.get_by_text('Compared fields agree — review required', exact=True).wait_for()
        assert 'Candidate comparison — no financial approval' in page.locator('#drawer').inner_text()
        assert 'Financial effect: none' in result.inner_text()
        comparisons = result.locator('[data-invoice-comparisons]')
        assert comparisons.locator('tbody tr').count() >= 7
        assert comparisons.locator('[data-invoice-quote]').count() >= 7
        assert 'Field bounds in points:' in comparisons.inner_text()
        assert case.invoice.document_id in result.inner_text()
        assert 'Original claims source hash:' in result.inner_text()
        assert page.locator('#drawer').get_by_role('button', name='Approve', exact=True).count() == 0
        assert page.locator('#drawer').get_by_role('button', name='Reject', exact=True).count() == 0
        assert any(item['path'] == case.base and item['status'] == 200 for item in exchanges)
        assert all(item['method'] == 'GET' for item in exchanges), exchanges
        assert not errors, errors


def test_missing_invoice_is_incomplete_not_a_financial_rejection(invoice_case):
    case = invoice_case
    with browser_case(case) as (page, exchanges, held, fulfill, errors):
        open_match(page, case, case.other_claim_id)
        result = page.locator('[data-invoice-match-result]')
        result.get_by_text('Insufficient evidence for comparison', exact=True).wait_for()
        result.get_by_text('No invoice available for comparison', exact=True).wait_for()
        assert 'Missing evidence is not a financial violation.' in result.inner_text()
        assert result.locator('[data-invoice-comparisons]').count() == 0
        assert all(item['method'] == 'GET' for item in exchanges)
        assert not errors, errors


def test_disabled_preview_displays_safe_retry_without_source_text(invoice_case, monkeypatch):
    monkeypatch.delenv('MCIAS_DOCUMENT_READER_MODE', raising=False)
    with browser_case(invoice_case) as (page, exchanges, held, fulfill, errors):
        open_match(page, invoice_case)
        page.locator('#drawer [role=alert]').get_by_text('Request could not be completed', exact=True).wait_for()
        assert page.locator('#drawer').get_by_role('button', name='Retry', exact=True).count() == 1
        assert page.locator('[data-invoice-quote]').count() == 0
        assert any(item['path'] == invoice_case.base and item['status'] == 503 for item in exchanges)
        assert all(item['method'] == 'GET' for item in exchanges)
        assert not errors, errors


def test_closed_drawer_cannot_render_late_original_source(invoice_case):
    case = invoice_case
    with browser_case(case, hold=lambda request:
            urlsplit(request.url).path == case.base) as (page, exchanges, held, fulfill, errors):
        open_match(page, case)
        page.locator('[data-invoice-match-result] [aria-busy=true]').wait_for()
        # Drive browser events until the request is intercepted, without relying
        # on an arbitrary inference timeout or a fake progress indicator.
        page.wait_for_function('''() => performance.getEntriesByType('resource')
          .some(item => item.name.includes('/workspace-assets/invoice_matching.js'))''')
        page.wait_for_timeout(50)
        assert len(held) == 1
        page.get_by_role('button', name='Close', exact=True).click()
        fulfill(held.pop())
        page.wait_for_timeout(50)
        assert not page.locator('#drawer').evaluate('(dialog) => dialog.open')
        assert page.locator('[data-invoice-quote]').count() == 0
        assert case.invoice.document_id not in page.locator('#drawer').text_content()
        assert not errors, errors


def test_arabic_mobile_dark_preview_preserves_text_and_read_only_actions(invoice_case):
    case = invoice_case
    with browser_case(case) as (page, exchanges, held, fulfill, errors):
        page.set_viewport_size({'width': 390, 'height': 844})
        page.evaluate('''async () => {
          const {preferences} = await import('/workspace-assets/ui.js');
          preferences.lang = 'ar'; preferences.theme = 'dark';
          document.documentElement.lang = 'ar';
          document.documentElement.dir = 'rtl';
          document.documentElement.dataset.theme = 'dark';
        }''')
        open_match(page, case)
        page.get_by_text('الحقول المقارنة متوافقة — المراجعة مطلوبة', exact=True).wait_for()
        assert page.locator('[data-invoice-match]').get_attribute('dir') == 'rtl'
        assert page.locator('[data-invoice-comparisons] tbody tr').count() >= 7
        assert page.locator('#drawer').get_by_role('button', name='تحديث المقارنة', exact=True).count() == 1
        assert page.locator('#drawer').get_by_role('button', name='اعتماد', exact=True).count() == 0
        assert page.evaluate('document.documentElement.scrollWidth <= window.innerWidth')
        assert all(item['method'] == 'GET' for item in exchanges)
        assert not errors, errors


def test_literal_pdf_markup_cannot_execute_in_candidate_evidence(invoice_case):
    case = invoice_case
    markup = '<img src=x onerror=window.invoiceInjected=true>'
    extra = case.upload([{**case.row, 'invoice_reference': 'SYN-UNRELATED-INVOICE', 'provider': markup}],
                        filename='SYN-untrusted-native-invoice.pdf')
    with browser_case(case) as (page, exchanges, held, fulfill, errors):
        open_match(page, case)
        page.locator('[data-invoice-document="' + extra.document_id + '"]').wait_for(state='attached')
        assert markup in page.locator('#drawer').text_content()
        assert page.locator('#drawer img[src=x]').count() == 0
        assert page.evaluate('window.invoiceInjected === undefined')
        assert all(item['method'] == 'GET' for item in exchanges)
        assert not errors, errors


def test_hidden_button_and_backend_denial_for_missing_sensitive_permission(invoice_case):
    from tests.workspace_v2.test_access_and_registry import grants

    case = invoice_case
    codes = ['profile.read', 'claims.read', 'claims.review', 'ingestion.read', 'medical_fields.text.read']
    assert grants(case.api, codes, user='admin').status_code == 200
    with browser_case(case, user='admin') as (page, exchanges, held, fulfill, errors):
        visible = page.evaluate('''async () => {
          const {canInvoiceMatch} = await import('/workspace-assets/invoice_matching.js');
          return canInvoiceMatch(window.aiTest.context);
        }''')
        assert not visible
        # Even a forged direct request must be refused by the actual API.
        status = page.evaluate('''async (base) => {
          try { await window.aiTest.api.request(base); return 200; }
          catch (error) { return error.status; }
        }''', case.base)
        assert status == 403
        assert page.locator('[data-invoice-match]').count() == 0
        assert page.locator('[data-invoice-quote]').count() == 0
        assert not errors, errors
