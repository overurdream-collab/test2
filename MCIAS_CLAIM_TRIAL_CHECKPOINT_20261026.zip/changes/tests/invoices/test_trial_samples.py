"""Trial sources are explicit, mutually consistent and never overwrite originals."""
from datetime import date
from decimal import Decimal
from hashlib import sha256
from io import BytesIO
import json

from openpyxl import load_workbook
import pytest

from mcias.ingestion.document_reader_preview import preview_pdf
from mcias.seed.claim_trial_samples import CLAIMS_FILE, INVOICE_FILE, files, write_files


def test_trial_files_contain_one_complete_explicit_source_line_and_invoice():
    data = files(date(2026, 10, 25))
    assert set(data) == {CLAIMS_FILE, INVOICE_FILE, 'mapping.json', 'README_AR.md'}
    mapping = json.loads(data['mapping.json'])
    book = load_workbook(BytesIO(data[CLAIMS_FILE]), read_only=False)
    rows = list(book.active.values)
    assert len(rows) == 2 and book.active.sheet_view.rightToLeft
    values = dict(zip(rows[0], rows[1]))
    assert values['الرقم التأميني'] == 'SYN-INS-EMPLOYEE'
    assert values['اسم المستفيد'] == 'SYN موظف تجريبي'
    assert values['مقدم الخدمة'] == 'SYN-LINKED-HOSPITAL' and values['الخدمة'] == 'SYN-VISIT'
    assert values['الدرجة'] == 'B' and values['تاريخ الخدمة'] == '25/10/2026'
    assert Decimal(values['المطلوب']) == Decimal('1000')
    assert Decimal(values['إجمالي التحمل']) == Decimal('100')
    assert Decimal(values['الصافي']) == Decimal('900')
    assert values['الكمية'] == '1'
    assert set(mapping['columns'].values()) <= set(values)
    assert mapping['columns']['claimed_amount'] == 'الصافي'
    assert mapping['columns']['quantity'] == 'الكمية'
    assert mapping['currency'] == 'LYD' and mapping['date_format'] == 'DMY'
    raw = data[INVOICE_FILE]
    preview = preview_pdf(raw, 'SYN-sample-document', sha256(raw).hexdigest())
    assert preview['issues'] == [] and preview['page_count'] == 1
    fields = preview['pages'][0]['fields']
    assert fields['beneficiary']['value'] == values['الرقم التأميني']
    assert 'beneficiary_name' not in fields
    assert fields['provider']['value'] == values['مقدم الخدمة']
    assert fields['service']['value'] == values['الخدمة']
    assert fields['invoice_reference']['value'] == values['رقم الفاتورة']
    assert fields['quantity']['value'] == '1' and fields['unit_price']['value'] == values['السعر']
    assert fields['net']['value'] == values['الصافي']
    assert all(item['source']['sha256'] == sha256(raw).hexdigest() for item in fields.values())
    assert 'يحتاج إجراء' in data['README_AR.md'].decode()
    assert 'سياسة مالية مؤسسية موقعة' in data['README_AR.md'].decode()
    book.close()


def test_writing_trial_samples_preserves_existing_output_files(tmp_path):
    output = tmp_path / 'samples'
    data = files(date(2026, 10, 25))
    written = write_files(output, data)
    assert len(written) == 4 and all(path.read_bytes() == data[path.name] for path in written)
    before = {path.name: sha256(path.read_bytes()).hexdigest() for path in written}
    with pytest.raises(FileExistsError):
        write_files(output, files(date(2026, 10, 26)))
    assert {path.name: sha256(path.read_bytes()).hexdigest() for path in written} == before


def test_symlinked_output_and_existing_targets_are_rejected(tmp_path):
    original = tmp_path / 'original'
    original.mkdir()
    symbolic = tmp_path / 'link'
    symbolic.symlink_to(original, target_is_directory=True)
    with pytest.raises(ValueError, match='symbolic'):
        write_files(symbolic / 'child', {'sample.txt': b'synthetic'})
    target = original / 'sample.txt'
    target.symlink_to(tmp_path / 'missing')
    with pytest.raises(FileExistsError):
        write_files(original, {'sample.txt': b'synthetic'})
    assert target.is_symlink() and not (tmp_path / 'missing').exists()


def test_sample_writer_rejects_parent_traversal_and_nested_names(tmp_path):
    with pytest.raises(ValueError, match='parent traversal'):
        write_files(tmp_path / 'one' / '..' / 'two', {'sample.txt': b'synthetic'})
    with pytest.raises(ValueError, match='plain name'):
        write_files(tmp_path / 'samples', {'../sample.txt': b'synthetic'})
    assert not (tmp_path / 'sample.txt').exists()
