"""Full laptop seed collisions require explicit provider/service relationships.

These use real seeded references, Excel/PDF ingestion and trial APIs. A shared
service code is neither an arbitrary first match nor a reason to invent a price.
"""
from datetime import date
from decimal import Decimal

from sqlalchemy.orm import Session

from mcias.models import User
from mcias.schemas.registry import RecordCreate
from mcias.seed.reference_inputs import seed_reference_inputs
from mcias.services import registry_service as registry
from tests.invoices.test_claim_trial import trial_case  # noqa: F401
from tests.workspace_v2.test_linked_references import linked  # noqa: F401


def full_laptop_inputs(case):
    with Session(case.api.engine) as db:
        actor=db.get(User,case.api.ids['root'])
        seed_reference_inputs(db,actor)
        services=registry.effective_records(db,actor,'providers.services',date.today())
        assert len([row for row in services if row['values']['service_code']=='SYN-VISIT'])==2
        db.commit()


def test_full_laptop_seed_selects_service_from_unique_provider_tariff_link(trial_case):
    case=trial_case
    full_laptop_inputs(case)
    batch=case.import_batch()
    result=case.run(batch)
    assert result['counts']=={'accepted':0,'needs_action':1},result
    row=result['rows'][0]
    check=row['reference_check']
    assert check['references']['service']['id']==case.api.linked['SERVICE-visit']['id']
    assert check['references']['provider_tariff']['id']==case.api.linked['PRICE-HOSPITAL-visit']['id']
    assert Decimal(check['calculation']['expected_net'])==Decimal('900')
    assert Decimal(check['calculation']['beneficiary_copay_percent'])==Decimal('10')
    assert row['invoice_match']['identity']['status']=='MATCH'
    assert row['snapshot_id'] is None
    assert 'missing_or_ambiguous_signed_policy' in row['action_reasons']
    assert row['financially_final'] is False


def test_multiple_explicit_tariff_linked_services_remain_ambiguous(trial_case):
    case=trial_case
    full_laptop_inputs(case)
    with Session(case.api.engine) as db:
        actor=db.get(User,case.api.ids['root'])
        additional=registry.create_record(db,actor,'providers.services',RecordCreate(
            title='SYN additional explicit visit reference',effective_from=date.today(),
            values={'record_code':'SYN-TRIAL-OTHER-VISIT','service_code':'SYN-VISIT',
                    'coding_system':'LOCAL'},terms={'service_type':'visit'}))
        price=case.api.linked['PRICE-HOSPITAL-visit']
        registry.create_record(db,actor,'providers.prices',RecordCreate(
            title='SYN second explicitly linked visit tariff',effective_from=date.today(),
            values={**price['values'],'record_code':'SYN-TRIAL-OTHER-VISIT-PRICE'},
            links={**price['links'],'service':additional['id']}))
        db.commit()
    batch=case.import_batch()
    result=case.run(batch)
    assert result['counts']=={'accepted':0,'needs_action':1},result
    row=result['rows'][0]
    service=next(item for item in row['reference_check']['checks'] if item['code']=='service')
    assert service['status']=='hold' and service['reason']=='ambiguous_reference'
    assert row['reference_check']['calculation'] is None
    assert 'service' not in row['reference_check']['references']
    assert row['invoice_match']['identity']['status']=='MATCH'
    assert row['snapshot_id'] is None and row['primary_bucket']=='needs_action'
