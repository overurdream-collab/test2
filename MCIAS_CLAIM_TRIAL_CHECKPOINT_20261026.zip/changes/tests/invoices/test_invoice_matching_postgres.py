"""Actual native-PDF matching on a dedicated migrated PostgreSQL database.

No parser/model stub is used. This verifies storage, permissions, source
locations and audit integration, not general invoice accuracy or production UAT.
"""
import json
import logging.config
import os
from types import SimpleNamespace

import pytest
from sqlalchemy import func, select
from sqlalchemy.engine import make_url
from sqlalchemy.orm import Session

from mcias.app import app, get_rate_limit_db
from mcias.models import AuditLog, SourceFile
from mcias.models_audit import AuditSnapshot
from mcias.models_claims import ClaimAttachment, ClaimEntry
from mcias.models_ingestion import IngestionDocument
from mcias.services.registry_service import store
from tests.invoices.conftest import invoice_case as build_invoice_case
from tests.workspace_v2.test_access_and_registry import workspace as build_workspace


@pytest.mark.skipif(not os.getenv('MCIAS_INVOICE_TEST_DATABASE_URL'),
                    reason='Dedicated migrated PostgreSQL invoice test database required')
def test_native_invoice_match_on_postgres_preserves_financial_state_and_audit_privacy(
        api_factory, monkeypatch, tmp_path):
    url = os.environ['MCIAS_INVOICE_TEST_DATABASE_URL']
    if make_url(url).get_backend_name() != 'postgresql':
        pytest.fail('Invoice persistence proof requires an isolated PostgreSQL test database')
    # Preserve pytest logging capture while running the actual Alembic upgrade.
    with monkeypatch.context() as migration_logging:
        migration_logging.setattr(logging.config, 'fileConfig', lambda *args, **kwargs: None)
        api = api_factory(url=url)
    # PostgreSQL is already migrated; features_api would insert its seed twice.
    build_workspace.__wrapped__(api, monkeypatch, tmp_path)
    case = build_invoice_case.__wrapped__(api, monkeypatch, SimpleNamespace(param={'attach': False}))
    monkeypatch.setitem(app.dependency_overrides, get_rate_limit_db, api.database)
    # This bundle uses one unrelated service and one exact target service.
    source = case.upload([{**case.row, 'service': 'SYN-OTHER-SERVICE'}, case.row])
    with Session(api.engine) as db:
        amount = db.get(ClaimEntry, case.claim_id).claimed_amount
        snapshots = db.scalar(select(func.count()).select_from(AuditSnapshot))
        attachments = db.scalar(select(func.count()).select_from(ClaimAttachment))
        classified = db.scalar(select(func.count()).select_from(AuditLog).where(
            AuditLog.action == 'claim_invoice.linked'))

    first = api.client.get(case.base, headers=api.headers['root'])
    assert first.status_code == 200, first.text
    body = first.json()
    assert body['status'] == 'CONSISTENT_FIELDS', body
    assert body['selected_candidate'] == {'document_id': source.document_id, 'page': 2}
    assert body['review_required'] is True and body['financially_final'] is False
    assert body['financial_effect'] == 'NONE'
    assert all(row['status'] == 'MATCH' and row['document_source']['page'] == 2
               for row in body['comparisons'])
    again = api.client.get(case.base, headers=api.headers['root'])
    assert again.status_code == 200 and again.json() == body

    with Session(api.engine) as db:
        assert db.get(ClaimEntry, case.claim_id).claimed_amount == amount
        assert db.scalar(select(func.count()).select_from(AuditSnapshot)) == snapshots
        assert db.scalar(select(func.count()).select_from(ClaimAttachment)) == attachments
        assert db.scalar(select(func.count()).select_from(AuditLog).where(
            AuditLog.action == 'claim_invoice.linked')) == classified
        events = list(db.scalars(select(AuditLog).where(
            AuditLog.action == 'invoice_match.preview', AuditLog.resource_id == case.claim_id)))
        assert len(events) == 2
        assert all(event.organization_id == api.organization_id and event.actor_id == api.ids['root']
                   and event.hash and len(event.hash) == 64 for event in events)
        metadata = json.dumps([event.details for event in events], ensure_ascii=False)
        for private in (case.row['beneficiary'], case.row['service'], case.row['provider'],
                        'bbox_points', 'quote', '100.00', '20.00', '80.00'):
            assert private not in metadata
        assert all(event.details['financial_effect'] == 'NONE' for event in events)
        for document_id, original in case.source_documents.items():
            document = db.get(IngestionDocument, document_id)
            original_source = db.get(SourceFile, document.source_id)
            assert store().get(original_source.storage_key, original_source.sha256) == original
