"""Deterministic mutations at parsing/reauthentication boundaries.

The original PDF/XLSX parsers and authorization guards remain real. Hooks only
change identity or extraction readiness at the boundary under examination; no
claimed evidence or expected parser output is substituted.
"""
import pytest
from sqlalchemy import func, select, update
from sqlalchemy.orm import Session

from mcias.models import AuditLog, User
from mcias.models_ingestion import IngestionJob, QuarantineItem
from mcias.services import invoice_matching_service as service


def test_organization_reassignment_after_preview_cannot_disclose_old_org_fields(invoice_case, monkeypatch):
    case = invoice_case
    original = service.preview
    boundary = []

    def move_after_comparison(db, actor, claim_id):
        result = original(db, actor, claim_id)
        assert result['status'] == 'CONSISTENT_FIELDS'
        boundary.append(True)
        # Existing technical identity still has all nonfinancial permissions in
        # its new organization. Only fresh claim ownership prevents disclosure.
        db.execute(update(User).where(User.id == actor.id).values(
            organization_id=case.api.other_organization_id))
        db.commit()
        return result

    monkeypatch.setattr(service, 'preview', move_after_comparison)
    response = case.api.client.get(case.base, headers=case.api.headers['root'])
    assert boundary == [True]
    assert response.status_code == 404, response.text
    assert response.json()['detail']['code'] == 'invoice_claim_not_found'
    assert case.row['beneficiary'] not in response.text
    assert case.row['provider'] not in response.text
    assert 'comparisons' not in response.json()
    with Session(case.api.engine) as db:
        assert db.get(User, case.api.ids['root']).organization_id == case.api.other_organization_id
        assert db.scalar(select(func.count()).select_from(AuditLog).where(
            AuditLog.action == 'invoice_match.preview')) == 0


@pytest.mark.parametrize('change', ['job_status', 'manifest', 'quarantine'])
def test_claim_readiness_changes_during_pdf_parse_invalidate_result(invoice_case, monkeypatch, change):
    case = invoice_case
    original_input = service._claim_input
    original_parser = service.isolated_preview_pdf
    state = {}

    def capture_request_session(db, actor, claim):
        result = original_input(db, actor, claim)
        state['db'] = db
        return result

    def change_readiness_after_parsing(*args, **kwargs):
        parsed = original_parser(*args, **kwargs)
        assert not parsed['issues']
        db = state['db']
        job = db.scalar(select(IngestionJob).where(
            IngestionJob.document_id == case.claim_document_id))
        assert job.status == 'extracted' and job.manifest['complete'] is True
        # The claim-side job changes, leaving invoice-side verification intact.
        # The post-parse freshness fingerprint must therefore reject this result.
        # Using the request transaction makes this boundary deterministic on the
        # fixture's in-memory SQLite connection; this is not a PG locking test.
        if change == 'job_status':
            job.status = 'review_required'
        elif change == 'manifest':
            job.manifest = {**job.manifest, 'complete': False}
        else:
            db.add(QuarantineItem(job_id=job.id, reason='SYN explicit readiness review',
                                  locator={'kind': 'sheet', 'index': 1, 'row': 2}))
        db.flush()
        state['changed'] = True
        return parsed

    monkeypatch.setattr(service, '_claim_input', capture_request_session)
    monkeypatch.setattr(service, 'isolated_preview_pdf', change_readiness_after_parsing)
    response = case.api.client.get(case.base, headers=case.api.headers['root'])
    assert state.get('changed') is True
    assert response.status_code == 409, response.text
    assert response.json()['detail']['code'] == 'invoice_inputs_changed_during_preview'
    assert case.row['beneficiary'] not in response.text
    assert 'comparisons' not in response.json()
    with Session(case.api.engine) as db:
        assert db.scalar(select(func.count()).select_from(AuditLog).where(
            AuditLog.action == 'invoice_match.preview')) == 0
