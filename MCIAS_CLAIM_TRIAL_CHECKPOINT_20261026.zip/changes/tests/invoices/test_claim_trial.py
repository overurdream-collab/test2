"""One runnable synthetic claim journey using real existing components.

G2/G4 upload/import, linked G3 references, signed G5 policy enrollment, native
invoice comparison and encrypted result export are real. No OCR/model or
financial snapshot is substituted. These are technical tests, not clinical UAT.
"""
from datetime import datetime
from decimal import Decimal
from hashlib import sha256
from io import BytesIO
from types import SimpleNamespace
from zipfile import ZipFile

from openpyxl import load_workbook
import pytest
from reportlab.pdfgen import canvas
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from mcias.models import AuditLog, MFAFactor, Permission, Role, SourceFile, UserRole
from mcias.models_audit import AuditSnapshot
from mcias.models_claims import ClaimEntry
from mcias.models_ingestion import IngestionDocument
from mcias.services.registry_service import store
from tests.workspace_v2.test_linked_references import linked, linked_mapping  # noqa: F401
from tests.workspace_v2.test_mapping_and_results import upload_batch
from tests.workspace_v2.net_cycle_fixtures import (
    approve_batch_policies, case_row, configure_signers, workbook,
)


def native_invoice(rows):
    """Explicit source facts; quantities are present, never inferred by a test."""
    output = BytesIO()
    pdf = canvas.Canvas(output, invariant=1)
    for row in rows:
        pdf.drawString(35, 800, 'SYNTHETIC TRIAL INVOICE - NOT A REAL INVOICE')
        for index, (key, value) in enumerate(row.items()):
            pdf.drawString(35, 760 - index * 23, f'{key}: {value}')
        pdf.showPage()
    pdf.save()
    return output.getvalue()


@pytest.fixture
def trial_case(linked, monkeypatch):
    api = linked
    monkeypatch.setenv('MCIAS_DOCUMENT_READER_MODE', 'native_preview')
    with Session(api.engine) as db:
        # Real runtime setup registers the same codes explicitly. These rows
        # remain isolated to this test DB and never grant staff access.
        for code in ('medical_fields.text.read', 'medical_fields.beneficiary_token.read',
                     'medical_fields.beneficiary_name.read'):
            if db.scalar(select(Permission.id).where(Permission.code == code)) is None:
                db.add(Permission(code=code))
        db.commit()
    configure_signers(api, monkeypatch)
    case = SimpleNamespace(api=api, sources={})

    def import_batch(rows=None, *, missing=(), invoice_only=()):
        rows = rows or [case_row()]
        book = load_workbook(BytesIO(workbook(rows)))
        sheet = book.active
        sheet.cell(1, sheet.max_column + 1, 'الكمية')
        for number in range(2, len(rows) + 2):
            sheet.cell(number, sheet.max_column, '1')
        output = BytesIO(); book.save(output)
        original = output.getvalue()
        batch_id, document_id = upload_batch(api, original, 'SYN-claim-trial.xlsx')
        body = linked_mapping()
        body['columns']['quantity'] = 'الكمية'
        path = '/api/v1/claims/batches/' + batch_id
        mapped = api.client.put(path + '/mapping', json=body, headers=api.headers['root'])
        assert mapped.status_code == 200, mapped.text
        resumed = api.client.post(path + '/resume', headers=api.headers['root'])
        assert resumed.status_code == 200 and resumed.json()['status'] == 'imported', resumed.text
        with Session(api.engine) as db:
            identities = {claim.claim_reference: claim.id for claim in db.scalars(
                select(ClaimEntry).where(ClaimEntry.batch_id == batch_id))}
        case.sources[document_id] = original
        result = SimpleNamespace(batch_id=batch_id, document_id=document_id,
                                 raw=original, identities=identities, rows=rows)
        for index, row in enumerate(rows, 1):
            if row['invoice_reference'] in missing:
                continue
            facts = {
                'invoice_reference': row['invoice_reference'],
                'beneficiary': row['beneficiary'], 'provider': row['provider'],
                'service': row['service'],
                'service_date': datetime.strptime(row['date'], '%d/%m/%Y').date().isoformat(),
                'gross': row['gross'], 'copay': row['copay'], 'net': row['net'],
                'currency': 'LYD', 'quantity': '1', 'unit_price': row['unit'],
            }
            if row['invoice_reference'] in invoice_only:
                facts.pop('beneficiary')
            content = native_invoice([facts])
            uploaded = api.client.post('/api/v1/ingestion/uploads?filename=SYN-trial-invoice-' + str(index) + '.pdf',
                content=content, headers={**api.headers['root'], 'Content-Type': 'application/octet-stream'})
            assert uploaded.status_code == 200, uploaded.text
            assert uploaded.json()['status'] in ('extracted', 'duplicate'), uploaded.text
            invoice_id = uploaded.json()['document_id']
            linked_invoice = api.client.post('/api/v1/claims/entries/' +
                identities[row['invoice_reference']] + '/attachments/' + invoice_id + '?kind=invoice',
                headers=api.headers['root'])
            assert linked_invoice.status_code == 201, linked_invoice.text
            case.sources[invoice_id] = content
        return result

    def run(batch, headers=None):
        response = api.client.post('/api/v1/audits/batches/' + batch.batch_id + '/trial-run',
                                   headers=headers or api.headers['root'])
        assert response.status_code == 201, response.text
        return response.json()

    case.import_batch, case.run = import_batch, run
    case.approve = lambda batch: approve_batch_policies(api, batch.batch_id)
    return case


def assert_originals(case):
    with Session(case.api.engine) as db:
        for identity, original in case.sources.items():
            document = db.get(IngestionDocument, identity)
            source = db.get(SourceFile, document.source_id)
            assert source.sha256 == sha256(original).hexdigest()
            assert store().get(source.storage_key, source.sha256) == original


def primary_files(case, batch, run):
    output = run.get('primary_outputs')
    if output is None:
        response = case.api.client.post('/api/v1/result-files/batches/' + batch.batch_id + '/primary',
                                        headers=case.api.headers['root'])
        assert response.status_code == 201, response.text
        output = response.json()
    response = case.api.client.get('/api/v1/result-files/' + output['id'] + '/primary-download',
                                   headers=case.api.headers['root'])
    assert response.status_code == 200, response.text
    exported = {}
    with ZipFile(BytesIO(response.content)) as archive:
        assert set(archive.namelist()) == {'accepted.xlsx', 'needs_action.xlsx'}
        for filename in archive.namelist():
            book = load_workbook(BytesIO(archive.read(filename)), read_only=False)
            assert book.active.sheet_view.rightToLeft
            rows = list(book.active.values)
            for row in rows[1:]:
                assert row[0] not in exported, 'A service line appeared in both main outputs'
                exported[row[0]] = filename.removesuffix('.xlsx')
            book.close()
    assert set(exported) == set(batch.identities.values())
    return output, exported


def test_one_claim_can_run_with_real_invoice_and_signed_policy_then_download_two_files(trial_case):
    case = trial_case
    access = case.api.client.get('/api/v1/me/features', headers=case.api.headers['root'])
    assert access.status_code == 200 and access.json()['claim_trial_enabled'] is True
    batch = case.import_batch()
    case.approve(batch)
    run = case.run(batch)
    assert run['counts'] == {'accepted': 1, 'needs_action': 0}, run
    assert run['total_lines'] == len(run['rows']) == 1
    assert run['financially_final'] is False
    row = run['rows'][0]
    assert row['primary_bucket'] == 'accepted'
    assert row['invoice_match']['identity']['status'] == 'MATCH'
    assert row['invoice_match']['checks_complete'] is True
    assert row['reference_check']['calculation']['beneficiary_copay_percent'] == '10'
    with Session(case.api.engine) as db:
        snapshot = db.get(AuditSnapshot, row['snapshot_id'])
        assert snapshot.verification['status'] == 'verified'
        assert Decimal(snapshot.calculation['payable']) == Decimal('900')
        assert snapshot.calculation['copay_deducted_again'] is False
        assert db.get(ClaimEntry, row['line_id']).claimed_amount == Decimal('900')
    output, exported = primary_files(case, batch, run)
    assert exported == {row['line_id']: 'accepted'}
    read = case.api.client.get('/api/v1/audits/batches/' + batch.batch_id + '/trial-run',
                               headers=case.api.headers['root'])
    assert read.status_code == 200, read.text
    assert read.json()['fingerprint'] == run['fingerprint']
    assert read.json()['rows'] == run['rows']
    assert_originals(case)


def test_missing_invoice_keeps_price_and_copay_checks_and_does_not_stop_other_lines(trial_case):
    case = trial_case
    rows = [case_row(1), case_row(2, gross='1200', unit='1200', copay='120', net='1080'), case_row(3)]
    batch = case.import_batch(rows, missing={rows[1]['invoice_reference']},
                              invoice_only={rows[2]['invoice_reference']})
    case.approve(batch)
    run = case.run(batch)
    assert run['total_lines'] == len(run['rows']) == 3
    assert run['counts'] == {'accepted': 1, 'needs_action': 2}, run
    by_id = {row['line_id']: row for row in run['rows']}
    missing = by_id[batch.identities[rows[1]['invoice_reference']]]
    assert missing['primary_bucket'] == 'needs_action'
    checks = {check['code']: check for check in missing['reference_check']['checks']}
    assert checks['price']['status'] == 'difference'
    assert {'copay_amount', 'net_amount', 'beneficiary_enrollment', 'provider_tariff'} <= set(checks)
    assert missing['reference_check']['calculation'] is not None
    assert any('invoice' in str(reason).lower() for reason in missing['action_reasons'])
    no_identity = by_id[batch.identities[rows[2]['invoice_reference']]]
    assert no_identity['invoice_match']['identity']['status'] == 'INSUFFICIENT_EVIDENCE'
    assert no_identity['primary_bucket'] == 'needs_action'
    assert any(item['field'] == 'net' and item['status'] == 'MATCH'
               for item in no_identity['invoice_match']['comparisons'])
    _, exported = primary_files(case, batch, run)
    assert exported == {identity: by_id[identity]['primary_bucket'] for identity in by_id}
    assert_originals(case)


def test_missing_signed_policy_is_an_action_item_after_reference_and_document_checks(trial_case):
    case = trial_case
    batch = case.import_batch()
    run = case.run(batch)
    assert run['counts'] == {'accepted': 0, 'needs_action': 1}, run
    row = run['rows'][0]
    assert row['invoice_match']['identity']['status'] == 'MATCH'
    assert row['reference_check']['calculation'] is not None
    assert any('policy' in str(reason).lower() for reason in row['action_reasons'])
    with Session(case.api.engine) as db:
        assert db.scalar(select(func.count()).select_from(AuditSnapshot)) == 0
    _, exported = primary_files(case, batch, run)
    assert set(exported.values()) == {'needs_action'}


def test_repeat_trial_preserves_financial_snapshot_and_exclusive_line_membership(trial_case):
    case = trial_case
    batch = case.import_batch()
    case.approve(batch)
    first = case.run(batch)
    second = case.run(batch)
    assert first['counts'] == second['counts'] == {'accepted': 1, 'needs_action': 0}
    assert first['rows'][0]['snapshot_id'] == second['rows'][0]['snapshot_id']
    with Session(case.api.engine) as db:
        assert db.scalar(select(func.count()).select_from(AuditSnapshot)) == 1
    assert primary_files(case, batch, first)[1] == primary_files(case, batch, second)[1]
    assert_originals(case)


def test_trial_requires_opt_in_and_backend_permissions(trial_case, monkeypatch):
    case = trial_case
    batch = case.import_batch()
    path = '/api/v1/audits/batches/' + batch.batch_id + '/trial-run'
    assert case.api.client.post(path).status_code == 401
    assert case.api.client.post(path, headers=case.api.headers['none']).status_code == 403
    monkeypatch.delenv('MCIAS_DOCUMENT_READER_MODE')
    denied = case.api.client.post(path, headers=case.api.headers['root'])
    assert denied.status_code in (409, 503), denied.text
    assert not case.api.client.get('/api/v1/result-files', headers=case.api.headers['root']).json()['items']


def test_trial_does_not_return_another_institutions_claims(trial_case):
    case = trial_case
    batch = case.import_batch()
    with Session(case.api.engine) as db:
        role = db.scalar(select(Role).where(Role.code == 'super_admin'))
        db.add(UserRole(user_id=case.api.ids['other'], role_id=role.id))
        db.add(MFAFactor(user_id=case.api.ids['other'], enabled=True,
                         encrypted_secret=b'SYN-fixture-no-login-secret'))
        db.commit()
    response = case.api.client.post('/api/v1/audits/batches/' + batch.batch_id + '/trial-run',
                                    headers=case.api.headers['other'])
    assert response.status_code in (403, 404), response.text
    assert 'SYN-INS-EMPLOYEE' not in response.text
    with Session(case.api.engine) as db:
        assert not db.scalar(select(AuditLog.id).where(AuditLog.action == 'claim_trial.completed'))
