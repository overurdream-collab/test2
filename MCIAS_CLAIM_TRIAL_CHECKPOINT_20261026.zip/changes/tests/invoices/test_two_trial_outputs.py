"""Two exclusive primary files retain every reason and preserve old history.

Pure decision-table cases below verify projection only, not financial accuracy.
API cases use real existing XLSX/PDF ingestion; the complete signed financial
cycle is covered separately by the trial integration tests.
"""
from copy import deepcopy
from decimal import Decimal
from io import BytesIO
import json
from zipfile import ZipFile

from openpyxl import load_workbook
import pytest
from sqlalchemy import select
from sqlalchemy.orm import Session

from mcias.reporting_g7 import ReportBlocked
from mcias.models import MFAFactor, Role, UserRole
from mcias.services import result_service as service


def projection(bucket='accepted', *, line_id='SYN-LINE-1'):
    invoice={'attachment_id':'SYN-ATTACHMENT','document_id':'SYN-DOCUMENT','sha256':'b'*64}
    row={'line_id':line_id,'bucket':bucket,'reason':'verified_match' if bucket=='accepted' else 'missing_invoice',
         'currency':'LYD','claimed_net':'900.00','audit_snapshot_id':'SYN-SNAPSHOT-'+line_id,
         'invoices':[invoice]}
    dataset={'schema':'mcias-four-results-v1','batch_id':'SYN-BATCH','organization_id':'SYN-ORG',
             'source_sha256':'a'*64,'rows':[row]}
    match={'status':'CONSISTENT_FIELDS','identity':{'status':'MATCH'},'checks_complete':True,'input_fingerprint':'e'*64,
           'claim_source':{'sha256':'a'*64}}
    trial={'batch_id':'SYN-BATCH','organization_id':'SYN-ORG','source_sha256':'a'*64,
           'fingerprint':'c'*64,'rows':[{'line_id':line_id,'snapshot_id':row['audit_snapshot_id'],
           'bucket':bucket,'action_reasons':[],'invoice_match':match,'invoice_evidence':[invoice],
           'audited_checks':[{'code':'price','status':'pass'}]}]}
    return dataset,trial


def test_primary_projection_keeps_each_internal_outcome_without_double_counting():
    dataset,trial=projection()
    for index,bucket in enumerate(('rejected','held','review'),2):
        extra,outcome=projection(bucket,line_id='SYN-LINE-'+str(index))
        dataset['rows']+=extra['rows'];trial['rows']+=outcome['rows']
    original_buckets=[row['bucket'] for row in dataset['rows']]
    service.apply_primary(dataset,trial)
    assert [row['bucket'] for row in dataset['rows']]==original_buckets
    assert dataset['primary_summary']['counts']=={'accepted':1,'needs_action':3}
    assert dataset['primary_summary']['unique_line_count']==4
    totals=dataset['primary_summary']['claimed_net_by_currency']['LYD']
    assert sum(Decimal(value) for value in totals.values())==Decimal('3600')
    assert all(row['primary_bucket']=='needs_action' for row in dataset['rows'][1:])


def test_old_accepted_snapshot_without_new_trial_does_not_become_primary_accepted():
    dataset,_=projection()
    service.apply_primary(dataset,None)
    assert dataset['rows'][0]['primary_bucket']=='needs_action'
    assert 'invoice_comparison_missing' in dataset['rows'][0]['reasons']


@pytest.mark.parametrize('change', ['identity','incomplete','changed_invoice','changed_snapshot','stale_line','wrong_source'])
def test_primary_acceptance_requires_current_complete_source_and_financial_evidence(change):
    dataset,trial=projection();row=trial['rows'][0]
    if change=='identity':row['invoice_match']['identity']['status']='INSUFFICIENT_EVIDENCE'
    elif change=='incomplete':row['invoice_match']['checks_complete']=False
    elif change=='changed_invoice':row['invoice_evidence']=[]
    elif change=='changed_snapshot':row['snapshot_id']='SYN-OTHER-SNAPSHOT'
    elif change=='stale_line':trial['stale_line_ids']=['SYN-LINE-1']
    else:trial['source_sha256']='d'*64
    service.apply_primary(dataset,trial)
    assert dataset['rows'][0]['primary_bucket']=='needs_action'
    assert dataset['rows'][0]['reasons']


def test_many_action_reasons_still_produce_one_line_and_one_amount():
    dataset,trial=projection()
    trial['rows'][0]['action_reasons']=['missing_invoice','missing_invoice','invoice_identity_unresolved']
    service.apply_primary(dataset,trial)
    assert dataset['primary_summary']['total_lines']==1
    assert dataset['primary_summary']['counts']=={'accepted':0,'needs_action':1}
    assert dataset['rows'][0]['reasons']==['invoice_identity_unresolved','missing_invoice']
    assert Decimal(dataset['primary_summary']['claimed_net_by_currency']['LYD']['needs_action'])==Decimal('900')


def test_duplicate_trial_lines_are_rejected_instead_of_choosing_one():
    dataset,trial=projection();trial['rows'].append(deepcopy(trial['rows'][0]))
    with pytest.raises(ReportBlocked,match='membership'):
        service.apply_primary(dataset,trial)


def test_primary_files_are_exclusive_complete_and_historical_four_files_remain(invoice_case):
    case=invoice_case;api=case.api;headers=api.headers['root'];base='/api/v1/result-files'
    old=api.client.post(base+'/batches/'+case.batch_id,headers=headers)
    assert old.status_code==201,old.text
    old_id=old.json()['id'];old_fingerprint=old.json()['fingerprint']
    response=api.client.post(base+'/batches/'+case.batch_id+'/primary',headers=headers)
    assert response.status_code==201,response.text
    body=response.json()
    assert body['primary_summary']['counts']=={'accepted':0,'needs_action':4}
    assert body['primary_summary']['total_lines']==4
    assert body['financially_final'] is False and body['id']!=old_id
    again=api.client.post(base+'/batches/'+case.batch_id+'/primary',headers=headers)
    assert again.status_code==201 and again.json()['id']==body['id']
    result=api.client.get(base+'/'+body['id']+'/primary-download',headers=headers)
    assert result.status_code==200,result.text
    seen=[]
    with ZipFile(BytesIO(result.content)) as archive:
        assert set(archive.namelist())=={'accepted.xlsx','needs_action.xlsx'}
        for name in archive.namelist():
            book=load_workbook(BytesIO(archive.read(name)),read_only=True)
            rows=list(book.active.values)
            if name=='accepted.xlsx':assert len(rows)==1
            else:assert len(rows)==5 and book.active.title=='يحتاج إجراء'
            seen.extend(row[0] for row in rows[1:]);book.close()
    assert len(seen)==len(set(seen))==4
    lines=api.client.get(base+'/'+body['id']+'/primary-lines',headers=headers)
    assert lines.status_code==200,lines.text
    assert all(row['primary_bucket']=='needs_action' and row['reasons'] for row in lines.json()['items'])
    assert all('source_values' not in row and 'invoice_match' not in row for row in lines.json()['items'])
    old_download=api.client.get(base+'/'+old_id+'/download',headers=headers)
    assert old_download.status_code==200
    with ZipFile(BytesIO(old_download.content)) as archive:
        assert set(archive.namelist())=={bucket+'.xlsx' for bucket in service.BUCKETS}
    assert api.client.get(base+'/'+old_id+'/primary-download',headers=headers).status_code==409
    old_again=api.client.post(base+'/batches/'+case.batch_id,headers=headers)
    assert old_again.status_code==201 and old_again.json()['fingerprint']==old_fingerprint
    with Session(api.engine) as db:
        role=db.scalar(select(Role).where(Role.code=='super_admin'))
        db.add(UserRole(user_id=api.ids['other'],role_id=role.id))
        db.add(MFAFactor(user_id=api.ids['other'],enabled=True,
            encrypted_secret=b'SYN-unused-enrollment-fixture'))
        db.commit()
    assert api.client.get(base+'/'+body['id']+'/primary-lines',headers=api.headers['other']).status_code==404


def test_primary_partition_rejects_missing_duplicate_and_unknown_membership():
    row={'line_id':'SYN-1','bucket':'held','primary_bucket':'needs_action','currency':'LYD','claimed_net':'900'}
    for rows,expected in (([row,row],['SYN-1']),([row],['SYN-1','SYN-2'])):
        with pytest.raises(ReportBlocked):service.primary_partition(rows,expected)
    with pytest.raises(ReportBlocked):service.primary_partition([{**row,'primary_bucket':'unknown'}],['SYN-1'])
