"""Actual-source identity fallbacks; invoice number never proves a beneficiary.

Names and reference records below are synthetic. These tests exercise G2/G4,
native PDF extraction and authorization, without OCR/model stubs or approval.
"""
from datetime import date
from io import BytesIO
from types import SimpleNamespace

from openpyxl import Workbook
import pytest
from reportlab.pdfgen import canvas
from sqlalchemy import select
from sqlalchemy.orm import Session

from mcias.models import Permission, User
from mcias.models_claims import ClaimEntry
from tests.workspace_v2.test_access_and_registry import grants
from tests.workspace_v2.test_mapping_and_results import mapping, upload_batch


NAME = 'SYN Example Person'
TOKEN = 'SYN-INS-IDENTITY-1'


def invoice_source(rows):
    """Omit missing labels rather than manufacturing a placeholder identity."""
    output = BytesIO()
    pdf = canvas.Canvas(output, invariant=1)
    for row in rows:
        pdf.drawString(35, 800, 'SYNTHETIC IDENTITY INVOICE - NOT A REAL INVOICE')
        for index, (field, value) in enumerate(row.items()):
            pdf.drawString(35, 760 - index * 24, f'{field}: {value}')
        pdf.showPage()
    pdf.save()
    return output.getvalue()


@pytest.fixture
def identity_case(workspace, monkeypatch, request):
    api = workspace
    options = getattr(request, 'param', {}) or {}
    monkeypatch.setenv('MCIAS_DOCUMENT_READER_MODE', 'native_preview')
    with Session(api.engine) as db:
        for code in ('medical_fields.text.read', 'medical_fields.beneficiary_token.read',
                     'medical_fields.beneficiary_name.read'):
            if db.scalar(select(Permission.id).where(Permission.code == code)) is None:
                db.add(Permission(code=code))
        db.commit()
    day = date.today()
    names = ['رقم الفاتورة', 'الرقم التأميني', 'مقدم الخدمة', 'الخدمة', 'تاريخ الخدمة',
             'المطلوب', 'إجمالي التحمل', 'الصافي', 'اسم المستفيد']
    values = ['SYN-IDENTITY-INVOICE-1', TOKEN, 'SYN-IDENTITY-PROVIDER', 'SYN-VISIT',
              day.isoformat(), '100', '20', '80', NAME]
    book = Workbook()
    sheet = book.active
    sheet.title = 'تفاصيل المطالبات'
    sheet.append(names)
    sheet.append(values)
    output = BytesIO()
    book.save(output)
    batch, _ = upload_batch(api, output.getvalue(), 'SYN-identity-claims.xlsx')
    body = mapping()
    body['date_format'] = 'ISO'
    body['columns'].update(gross_amount='المطلوب', copay_amount='إجمالي التحمل')
    if options.get('claim_name', True):
        body['columns']['beneficiary_name'] = 'اسم المستفيد'
    response = api.client.put(f'/api/v1/claims/batches/{batch}/mapping', json=body,
                              headers=api.headers['root'])
    assert response.status_code == 200, response.text
    response = api.client.post(f'/api/v1/claims/batches/{batch}/resume', headers=api.headers['root'])
    assert response.status_code == 200, response.text
    with Session(api.engine) as db:
        claim = db.scalar(select(ClaimEntry).where(ClaimEntry.batch_id == batch))
        identity = claim.id
    case = SimpleNamespace(api=api, claim_id=identity,
        base=f'/api/v1/claims/entries/{identity}/invoice-matches',
        row={'invoice_reference': 'SYN-IDENTITY-INVOICE-1', 'beneficiary': TOKEN,
             'beneficiary_name': NAME, 'provider': 'SYN-IDENTITY-PROVIDER',
             'service': 'SYN-VISIT', 'service_date': day.isoformat(), 'gross': '100.00',
             'copay': '20.00', 'net': '80.00', 'currency': 'LYD'})

    def beneficiary(token=TOKEN, name=NAME):
        payload = {'title': name, 'effective_from': date(day.year, 1, 1).isoformat(),
            'values': {'record_code': 'SYN-BEN-' + token, 'beneficiary_token': token, 'category_code': 'B'}}
        response = api.client.post('/api/v1/registry/beneficiaries.names/records', json=payload,
                                   headers=api.headers['root'])
        assert response.status_code == 201, response.text
        return response.json()

    def upload(*rows):
        raw = invoice_source(rows or [case.row])
        response = api.client.post('/api/v1/ingestion/uploads?filename=SYN-identity-invoice.pdf',
            content=raw, headers={**api.headers['root'], 'Content-Type': 'application/octet-stream'})
        assert response.status_code == 200, response.text
        document_id = response.json()['document_id']
        response = api.client.post(
            f'/api/v1/claims/entries/{identity}/attachments/{document_id}?kind=invoice',
            headers=api.headers['root'])
        assert response.status_code == 201, response.text
        return document_id

    def preview(headers=None):
        response = api.client.get(case.base, headers=headers or api.headers['root'])
        assert response.status_code == 200, response.text
        return response.json()

    case.beneficiary, case.upload, case.preview = beneficiary, upload, preview
    if options.get('input_record', True):
        case.reference = beneficiary()
    return case


def without(row, *keys):
    return {key: value for key, value in row.items() if key not in keys}


def test_name_only_requires_unique_input_link_to_claim_insurance_number(identity_case):
    case = identity_case
    case.upload(without(case.row, 'beneficiary'))
    result = case.preview()
    assert result['identity']['status'] == 'MATCH', result
    assert result['identity']['basis'] == 'unique_name'
    assert result['identity']['reference_status'] == 'MATCH'
    assert result['status'] == 'CONSISTENT_FIELDS'
    assert result['checks_complete'] is True
    assert len(result['input_fingerprint']) == 64
    assert result['financially_final'] is False and result['financial_effect'] == 'NONE'


def test_insurance_id_only_does_not_require_a_name_on_the_invoice(identity_case):
    case = identity_case
    case.upload(without(case.row, 'beneficiary_name'))
    result = case.preview()
    assert result['identity']['status'] == 'MATCH', result
    assert result['identity']['basis'] == 'insurance_id'
    assert result['status'] == 'CONSISTENT_FIELDS'
    assert result['checks_complete'] is True


@pytest.mark.parametrize('identity_case', [{'input_record': False}], indirect=True)
def test_id_link_and_missing_reference_are_reported_separately(identity_case):
    case = identity_case
    case.upload(without(case.row, 'beneficiary_name'))
    result = case.preview()
    assert result['identity']['status'] == 'MATCH'
    assert result['identity']['reference_status'] == 'MISSING'
    assert result['financially_final'] is False


def test_invoice_number_without_name_or_insurance_number_cannot_match_identity(identity_case):
    case = identity_case
    case.upload(without(case.row, 'beneficiary', 'beneficiary_name'))
    result = case.preview()
    assert result['identity']['status'] == 'INSUFFICIENT_EVIDENCE', result
    assert result['status'] == 'INSUFFICIENT_EVIDENCE'
    assert result['checks_complete'] is False
    # Available financial fields are still compared; missing identity does not
    # prevent the rest of the record from being inspected.
    assert any(row['field'] == 'net' and row['status'] == 'MATCH' for row in result['comparisons'])


def test_matching_insurance_number_does_not_hide_a_conflicting_name(identity_case):
    case = identity_case
    case.upload({**case.row, 'beneficiary_name': 'SYN Different Person'})
    result = case.preview()
    assert result['identity']['status'] == 'DIFFERENT', result
    assert result['status'] != 'CONSISTENT_FIELDS'
    assert result['financial_effect'] == 'NONE'


def test_duplicate_input_name_cannot_choose_one_insurance_number_arbitrarily(identity_case):
    case = identity_case
    case.beneficiary(token='SYN-INS-IDENTITY-2')
    case.upload(without(case.row, 'beneficiary'))
    result = case.preview()
    assert result['identity']['status'] == 'INSUFFICIENT_EVIDENCE', result
    assert result['identity']['reference_status'] == 'AMBIGUOUS'
    assert result['status'] == 'INSUFFICIENT_EVIDENCE'


@pytest.mark.parametrize('identity_case', [{'claim_name': False}], indirect=True)
def test_name_only_is_not_inferred_from_an_unmapped_excel_column(identity_case):
    case = identity_case
    case.upload(without(case.row, 'beneficiary'))
    result = case.preview()
    assert result['identity']['status'] == 'INSUFFICIENT_EVIDENCE', result
    assert result['status'] == 'INSUFFICIENT_EVIDENCE'


def test_name_comparison_requires_its_specific_sensitive_field_permission(identity_case):
    case = identity_case
    case.upload()
    codes = ['claims.read', 'claims.review', 'ingestion.read', 'medical_fields.text.read',
             'medical_fields.beneficiary_token.read']
    response = grants(case.api, codes)
    assert response.status_code == 200, response.text
    response = case.api.client.get(case.base, headers=case.api.headers['admin'])
    assert response.status_code == 403, response.text
    assert NAME not in response.text
    assert grants(case.api, [*codes, 'medical_fields.beneficiary_name.read']).status_code == 200
    assert case.preview(headers=case.api.headers['admin'])['identity']['status'] == 'MATCH'


def test_same_invoice_service_pages_are_disambiguated_by_beneficiary(identity_case):
    case = identity_case
    document_id = case.upload(
        {**case.row, 'beneficiary': 'SYN-OTHER-ID', 'beneficiary_name': 'SYN Other Person'},
        case.row)
    result = case.preview()
    assert result['status'] == 'CONSISTENT_FIELDS', result
    assert result['identity']['status'] == 'MATCH'
    assert result['selected_candidate'] == {'document_id': document_id, 'page': 2}
    assert all(row['document_source']['page'] == 2 for row in result['comparisons'])


def test_name_reference_change_invalidates_the_comparison_fingerprint(identity_case):
    from mcias.services.invoice_matching_service import current_input_fingerprint

    case = identity_case
    case.upload(without(case.row, 'beneficiary'))
    before = case.preview()
    assert before['identity']['status'] == 'MATCH'
    with Session(case.api.engine) as db:
        actor = db.get(User, case.api.ids['root'])
        assert current_input_fingerprint(db, actor, case.claim_id) == before['input_fingerprint']
    # A second person with the same name makes name-only linkage ambiguous.
    # The immutable PDF and Excel remain identical, but the effective identity
    # reference set changed and the old comparison can no longer certify it.
    case.beneficiary(token='SYN-INS-NEW-SAME-NAME')
    with Session(case.api.engine) as db:
        actor = db.get(User, case.api.ids['root'])
        assert current_input_fingerprint(db, actor, case.claim_id) != before['input_fingerprint']
    after = case.preview()
    assert after['identity']['status'] == 'INSUFFICIENT_EVIDENCE'
    assert after['status'] == 'INSUFFICIENT_EVIDENCE'
    assert after['checks_complete'] is False
