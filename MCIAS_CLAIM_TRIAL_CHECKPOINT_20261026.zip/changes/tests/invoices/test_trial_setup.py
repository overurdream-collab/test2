"""Explicit synthetic invoice trial registers a catalog, never staff grants."""
from copy import deepcopy
import json

import pytest
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from mcias.models import (AuditLog, GroupPermission, Permission, RolePermission,
                          User, UserGroup, UserPermission, UserRole)
from mcias.seed.invoice_trial import TRIAL_PERMISSIONS, ensure_catalog
from mcias.services.authorization_service import check_permission_unified


def trial_env():
    return {'MCIAS_LAPTOP_TEST_MODE': 'synthetic_localhost',
            'MCIAS_ENVIRONMENT': 'development',
            'MCIAS_DATABASE_URL': 'postgresql+psycopg://laptop_runtime:SYN-local@localhost/mcias_laptop_e2e',
            'MCIAS_MFA_ENCRYPTION_KEY': '1a' * 32, 'MCIAS_STORAGE_KEY': '2b' * 32,
            'MCIAS_DOCUMENT_READER_MODE': 'native_preview'}


def grant_counts(db):
    return {model.__tablename__: db.scalar(select(func.count()).select_from(model))
            for model in (GroupPermission, UserPermission, UserGroup, RolePermission, UserRole)}


@pytest.mark.parametrize('mode', [None, '', 'disabled'])
def test_trial_opt_out_preserves_catalog_and_grants(workspace, mode):
    env = trial_env()
    if mode is None:
        env.pop('MCIAS_DOCUMENT_READER_MODE')
    else:
        env['MCIAS_DOCUMENT_READER_MODE'] = mode
    with Session(workspace.engine) as db:
        root = db.get(User, workspace.ids['root'])
        before = db.scalar(select(func.count()).select_from(Permission))
        grants = grant_counts(db)
        assert ensure_catalog(db, root, env) == {'enabled': False, 'permissions_created': 0}
        assert db.scalar(select(func.count()).select_from(Permission)) == before
        assert grant_counts(db) == grants


@pytest.mark.parametrize('change', [
    {'MCIAS_ENVIRONMENT': 'production'},
    {'MCIAS_LAPTOP_TEST_MODE': ''},
    {'MCIAS_DATABASE_URL': 'postgresql+psycopg://laptop_runtime:SYN@localhost/customer'},
    {'MCIAS_DATABASE_URL': 'postgresql+psycopg://laptop_owner:SYN@localhost/mcias_laptop_e2e'},
    {'MCIAS_DOCUMENT_READER_MODE': 'local_preview'},
])
def test_trial_rejects_unsafe_or_unsupported_activation(workspace, change):
    env = {**trial_env(), **change}
    with Session(workspace.engine) as db:
        root = db.get(User, workspace.ids['root'])
        before = db.scalar(select(func.count()).select_from(Permission))
        with pytest.raises(ValueError):
            ensure_catalog(db, root, env)
        assert db.scalar(select(func.count()).select_from(Permission)) == before


@pytest.mark.parametrize('account', ['admin', 'no_mfa', 'flag_only', 'other'])
def test_trial_catalog_requires_existing_mfa_technical_admin(workspace, account):
    with Session(workspace.engine) as db:
        actor = db.get(User, workspace.ids[account])
        before = db.scalar(select(func.count()).select_from(Permission))
        with pytest.raises(ValueError):
            ensure_catalog(db, actor, trial_env())
        assert db.scalar(select(func.count()).select_from(Permission)) == before


def test_trial_catalog_is_idempotent_and_preserves_frozen_staff(workspace):
    with Session(workspace.engine) as db:
        root = db.get(User, workspace.ids['root'])
        before = grant_counts(db)
        first = ensure_catalog(db, root, trial_env())
        assert first == {'enabled': True, 'permissions_created': 3}
        db.commit()
        assert ensure_catalog(db, root, trial_env()) == {'enabled': True, 'permissions_created': 0}
        assert grant_counts(db) == before
        for code, _, _ in TRIAL_PERMISSIONS:
            assert check_permission_unified(db, root, code)
            for account in ('admin', 'viewer', 'none'):
                assert not check_permission_unified(db, db.get(User, workspace.ids[account]), code)
        events = list(db.scalars(select(AuditLog).where(
            AuditLog.action == 'synthetic_invoice_trial.catalog')))
        assert len(events) == 1
        assert events[0].actor_id == root.id and events[0].organization_id == root.organization_id
        assert events[0].details == {'synthetic': True, 'mode': 'native_preview',
            'registered_codes': [code for code, _, _ in TRIAL_PERMISSIONS], 'user_grants_created': 0}
        assert not {'password', 'totp', 'beneficiary_name', 'invoice_reference'} & set(events[0].details)


def test_trial_preserves_existing_permission_definition(workspace):
    with Session(workspace.engine) as db:
        code = TRIAL_PERMISSIONS[0][0]
        row = Permission(code=code, description_ar='SYN approved description',
                         description_en='SYN preserved definition', category='SYN-existing')
        db.add(row); db.commit()
        identity = row.id
        result = ensure_catalog(db, db.get(User, workspace.ids['root']), trial_env())
        assert result['permissions_created'] == 2
        db.flush(); db.expire_all()
        saved = db.get(Permission, identity)
        assert saved.description_ar == 'SYN approved description'
        assert saved.description_en == 'SYN preserved definition' and saved.category == 'SYN-existing'


def test_trial_flush_and_audit_roll_back_together(workspace):
    with Session(workspace.engine) as db:
        before = db.scalar(select(func.count()).select_from(Permission))
        ensure_catalog(db, db.get(User, workspace.ids['root']), trial_env())
        assert db.scalar(select(func.count()).select_from(Permission)) == before + 3
        db.rollback()
        assert db.scalar(select(func.count()).select_from(Permission)) == before
        assert not db.scalar(select(AuditLog.id).where(AuditLog.action == 'synthetic_invoice_trial.catalog'))


def test_trial_check_detects_actual_disabled_mode_even_with_existing_catalog(workspace):
    from mcias.seed.invoice_trial import check_controls
    with Session(workspace.engine) as db:
        ensure_catalog(db, db.get(User, workspace.ids['root']), trial_env())
        controls = check_controls(db, {**trial_env(), 'MCIAS_DOCUMENT_READER_MODE': 'disabled'})
        assert controls[0]['status'] == 'BLOCKED'
        assert controls[1]['status'] == 'PASS'


def test_trial_check_requires_catalog_before_reporting_ready(workspace):
    from mcias.seed.invoice_trial import check_controls
    with Session(workspace.engine) as db:
        assert check_controls(db, trial_env())[1]['status'] == 'BLOCKED'
        ensure_catalog(db, db.get(User, workspace.ids['root']), trial_env())
        assert all(row['status'] == 'PASS' for row in check_controls(db, trial_env()))
