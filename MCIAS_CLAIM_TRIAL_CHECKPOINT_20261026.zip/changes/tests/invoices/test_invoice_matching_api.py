"""Source-bound comparison is advisory, never a financial decision.

Exercise original XLSX/PDF ingestion, G4 links, real authorization and native
PDF reading. No model inference or OCR is involved in this proof.
"""
from copy import deepcopy
from decimal import Decimal
from io import BytesIO
import json

import pytest
from reportlab.pdfgen import canvas
from sqlalchemy import func, select, update
from sqlalchemy.orm import Session

from mcias.models import AuditLog, MFAFactor, Role, SourceFile, UserRole
from mcias.models_audit import AuditSnapshot
from mcias.models_claims import ClaimAttachment, ClaimEntry
from mcias.models_ingestion import ExtractedSourceRecord, IngestionDocument, IngestionJob
from mcias.services.registry_service import store
from tests.workspace_v2.test_access_and_registry import grants


def preview(case, claim_id=None, headers=None):
    return case.api.client.get(
        f'/api/v1/claims/entries/{claim_id or case.claim_id}/invoice-matches',
        headers=headers or case.api.headers['root'])


def fields(body):
    return {item['field']: item for item in body['comparisons']}


def pdf_lines(lines):
    output = BytesIO()
    document = canvas.Canvas(output, invariant=1)
    for index, line in enumerate(lines):
        document.drawString(35, 800 - index * 22, line)
    document.save()
    return output.getvalue()


def test_exact_native_invoice_match_keeps_decimal_bases_and_source_locations(invoice_case):
    response = preview(invoice_case)
    assert response.status_code == 200, response.text
    body = response.json()
    assert body['status'] == 'CONSISTENT_FIELDS', body
    assert body['review_required'] is True and body['financially_final'] is False
    assert body['financial_effect'] == 'NONE'
    compared = fields(body)
    assert {'invoice_reference', 'beneficiary', 'provider', 'service', 'service_date',
            'gross', 'copay', 'net', 'currency'} <= set(compared)
    assert all(item['status'] == 'MATCH' for item in compared.values())
    assert Decimal(compared['gross']['document_value']) == Decimal('100')
    assert Decimal(compared['copay']['document_value']) == Decimal('20')
    assert Decimal(compared['net']['document_value']) == Decimal('80')
    # Gross 100 and claim NET 80 must not be treated as a price discrepancy.
    assert Decimal(compared['net']['claim_value']) == Decimal('80')
    assert compared['net']['claim_source']['column'] == 'الصافي'
    assert compared['gross']['claim_source']['column'] == 'المطلوب'
    assert body['claim_source']['locator']['row'] is not None
    for item in compared.values():
        source = item['document_source']
        assert source['page'] == 1 and len(source['bbox_points']) == 4
        assert source['source']['document_id'] == invoice_case.invoice.document_id
        assert source['source']['sha256'] == invoice_case.invoice.sha256
        assert source['quote']
    assert 'quantity' not in compared and 'unit_price' not in compared
    assert response.headers['cache-control'] == 'no-store'


@pytest.mark.parametrize('invoice_case', [
    {'overrides': {'beneficiary': 'SYN-DIFFERENT-BENEFICIARY'}},
    {'overrides': {'provider': 'SYN-DIFFERENT-PROVIDER'}},
    {'overrides': {'service': 'SYN-DIFFERENT-SERVICE'}},
    {'overrides': {'service_date': '2026-06-09'}},
    {'overrides': {'currency': 'USD'}},
    {'overrides': {'invoice_reference': 'SYN-DIFFERENT-INVOICE'}},
    {'overrides': {'gross': '110.00', 'net': '90.00'}},
], indirect=True)
def test_explicit_source_differences_remain_advisory(invoice_case):
    response = preview(invoice_case)
    assert response.status_code == 200, response.text
    body = response.json()
    # A mismatching invoice/service identity is not sufficient to establish that
    # this document is the right source. Keep its discrepancy visible while
    # allowing the safer unresolved-identity classification.
    identity_differs = any(item['field'] in ('invoice_reference', 'service')
                           and item['status'] == 'DIFFERENT'
                           for item in body['comparisons'])
    expected = 'INSUFFICIENT_EVIDENCE' if identity_differs else 'DIFFERENT'
    assert body['status'] == expected, body
    assert any(item['status'] == 'DIFFERENT' for item in body['comparisons'])
    assert body['review_required'] and not body['financially_final']
    assert body['financial_effect'] == 'NONE'


def test_single_candidate_is_deterministic_but_not_a_financial_snapshot(invoice_case):
    case = invoice_case
    with Session(case.api.engine) as db:
        before = db.get(ClaimEntry, case.claim_id).claimed_amount
        snapshots = db.scalar(select(func.count()).select_from(AuditSnapshot))
        links = db.scalar(select(func.count()).select_from(ClaimAttachment))
        classifications = db.scalar(select(func.count()).select_from(AuditLog).where(
            AuditLog.action == 'claim_invoice.linked'))
    first = preview(case)
    second = preview(case)
    assert first.status_code == second.status_code == 200
    assert first.json() == second.json()
    with Session(case.api.engine) as db:
        assert db.get(ClaimEntry, case.claim_id).claimed_amount == before
        assert db.scalar(select(func.count()).select_from(AuditSnapshot)) == snapshots
        assert db.scalar(select(func.count()).select_from(ClaimAttachment)) == links
        assert db.scalar(select(func.count()).select_from(AuditLog).where(
            AuditLog.action == 'claim_invoice.linked')) == classifications
        for document_id, original in case.source_documents.items():
            document = db.get(IngestionDocument, document_id)
            source = db.get(SourceFile, document.source_id)
            assert store().get(source.storage_key, source.sha256) == original


def test_missing_invoice_is_insufficient_evidence_not_a_violation(invoice_case):
    response = preview(invoice_case, invoice_case.other_claim_id)
    assert response.status_code == 200, response.text
    body = response.json()
    assert body['status'] == 'INSUFFICIENT_EVIDENCE'
    assert body['selected_candidate'] is None and not body['documents']
    assert body['review_required'] and body['financial_effect'] == 'NONE'


@pytest.mark.parametrize('invoice_case', [{'attach': False}], indirect=True)
def test_multipage_bundle_resolves_service_without_counting_other_pages(invoice_case):
    case = invoice_case
    unrelated = {**case.row, 'service': 'SYN-OTHER-SERVICE'}
    source = case.upload([unrelated, case.row])
    response = preview(case)
    assert response.status_code == 200, response.text
    body = response.json()
    assert body['status'] == 'CONSISTENT_FIELDS', body
    assert body['selected_candidate'] == {'document_id': source.document_id, 'page': 2}
    assert len(body['documents'][0]['pages']) == 2
    assert all(item['document_source']['page'] == 2 for item in body['comparisons'])


@pytest.mark.parametrize('invoice_case', [{'attach': False}], indirect=True)
def test_duplicate_invoice_pages_never_choose_an_arbitrary_match(invoice_case):
    case = invoice_case
    case.upload([case.row, deepcopy(case.row)])
    response = preview(case)
    assert response.status_code == 200, response.text
    body = response.json()
    assert body['status'] == 'INSUFFICIENT_EVIDENCE', body
    assert body['selected_candidate'] is None and body['review_required']
    assert len(body['documents'][0]['pages']) == 2


@pytest.mark.parametrize('invoice_case', [{'overrides': {'gross': '100.00', 'copay': '20.00', 'net': '100.00'}}], indirect=True)
def test_inconsistent_invoice_arithmetic_does_not_receive_a_consistent_result(invoice_case):
    response = preview(invoice_case)
    assert response.status_code == 200, response.text
    body = response.json()
    assert body['status'] != 'CONSISTENT_FIELDS'
    assert body['issues']
    assert body['review_required'] and body['financial_effect'] == 'NONE'


@pytest.mark.parametrize('invoice_case', [{'overrides': {'service_date': '2026-02-30'}}], indirect=True)
def test_invalid_date_is_insufficient_not_a_proven_violation(invoice_case):
    response = preview(invoice_case)
    assert response.status_code == 200, response.text
    body = response.json()
    assert body['status'] == 'INSUFFICIENT_EVIDENCE', body
    assert fields(body)['service_date']['status'] == 'INVALID'


@pytest.mark.parametrize('invoice_case', [{'attach': False}], indirect=True)
def test_duplicate_conflicting_labels_leave_field_unresolved(invoice_case):
    case = invoice_case
    lines = [f'{key}: {value}' for key, value in case.row.items()]
    lines.append('beneficiary: SYN-OTHER-BENEFICIARY')
    case.upload(raw=pdf_lines(lines))
    response = preview(case)
    assert response.status_code == 200, response.text
    body = response.json()
    assert body['status'] == 'INSUFFICIENT_EVIDENCE', body
    assert body['review_required'] and body['financial_effect'] == 'NONE'


@pytest.mark.parametrize('invoice_case', [{'attach': False}], indirect=True)
def test_supporting_document_is_not_silently_promoted_to_an_invoice(invoice_case):
    case = invoice_case
    case.upload(kind='supporting')
    response = preview(case)
    assert response.status_code == 200, response.text
    assert response.json()['status'] == 'INSUFFICIENT_EVIDENCE'
    assert not response.json()['documents']


def test_backend_requires_login_review_and_sensitive_field_permissions(invoice_case):
    case = invoice_case
    assert case.api.client.get(case.base).status_code == 401
    assert preview(case, headers=case.api.headers['none']).status_code == 403
    assert grants(case.api, ['claims.read', 'claims.review', 'ingestion.read']).status_code == 200
    assert preview(case, headers=case.api.headers['admin']).status_code == 403
    assert grants(case.api, ['claims.read', 'claims.review', 'ingestion.read', 'medical_fields.text.read']).status_code == 200
    assert preview(case, headers=case.api.headers['admin']).status_code == 403
    allowed = ['claims.read', 'claims.review', 'ingestion.read', 'medical_fields.text.read',
               'medical_fields.beneficiary_token.read']
    assert grants(case.api, allowed).status_code == 200
    assert preview(case, headers=case.api.headers['admin']).status_code == 200
    assert grants(case.api, allowed[:-1]).status_code == 200
    assert preview(case, headers=case.api.headers['admin']).status_code == 403


def test_other_institution_privileged_actor_cannot_see_invoice(invoice_case):
    case = invoice_case
    with Session(case.api.engine) as db:
        role = db.scalar(select(Role).where(Role.code == 'super_admin'))
        db.add(UserRole(user_id=case.api.ids['other'], role_id=role.id))
        db.add(MFAFactor(user_id=case.api.ids['other'], enabled=True,
            encrypted_secret=b'SYN-not-a-real-TOTP-secret'))
        db.commit()
    response = preview(case, headers=case.api.headers['other'])
    assert response.status_code == 404, response.text
    assert 'SYN-BENEFICIARY' not in response.text


def test_preview_requires_explicit_local_native_mode(invoice_case, monkeypatch):
    monkeypatch.delenv('MCIAS_DOCUMENT_READER_MODE')
    response = preview(invoice_case)
    assert response.status_code == 503, response.text
    assert invoice_case.row['beneficiary'] not in response.text


def test_tampered_claim_values_are_rejected_against_original(invoice_case):
    case = invoice_case
    with Session(case.api.engine) as db:
        claim = db.get(ClaimEntry, case.claim_id)
        changed = {**claim.source_values, 'الصافي': '79'}
        db.execute(update(ClaimEntry).where(ClaimEntry.id == claim.id).values(source_values=changed))
        db.commit()
    response = preview(case)
    assert response.status_code == 409, response.text


def test_tampered_invoice_extraction_is_rejected_against_original(invoice_case):
    case = invoice_case
    with Session(case.api.engine) as db:
        record = db.scalar(select(ExtractedSourceRecord).join(IngestionJob,
            IngestionJob.id == ExtractedSourceRecord.job_id).where(
            IngestionJob.document_id == case.invoice.document_id))
        record.values = {'text': 'SYN tampered extraction text'}
        db.commit()
    response = preview(case)
    assert response.status_code == 409, response.text


def test_tampered_encrypted_invoice_original_is_rejected(invoice_case):
    case = invoice_case
    with Session(case.api.engine) as db:
        document = db.get(IngestionDocument, case.invoice.document_id)
        source = db.get(SourceFile, document.source_id)
        path = store().root / source.storage_key
        path.write_bytes(b'SYN invalid encrypted source')
    response = preview(case)
    assert response.status_code == 409, response.text
    assert 'SYN invalid encrypted source' not in response.text


@pytest.mark.parametrize('invoice_case', [{'attach': False}], indirect=True)
def test_unsupported_native_text_remains_unresolved(invoice_case):
    case = invoice_case
    case.upload(raw=pdf_lines(['SYN unsupported invoice layout', 'Total 80.00 LYD']))
    response = preview(case)
    assert response.status_code == 200, response.text
    body = response.json()
    assert body['status'] == 'INSUFFICIENT_EVIDENCE'
    assert body['review_required']
    assert body['financial_effect'] == 'NONE'


@pytest.mark.parametrize('invoice_case', [{'attach': False}], indirect=True)
def test_duplicate_saved_page_locators_cannot_hide_an_unverified_original_page(invoice_case):
    case = invoice_case
    source = case.upload([case.row, {**case.row, 'service': 'SYN-OTHER-SERVICE'}])
    with Session(case.api.engine) as db:
        records = list(db.scalars(select(ExtractedSourceRecord).join(IngestionJob,
            IngestionJob.id == ExtractedSourceRecord.job_id).where(
            IngestionJob.document_id == source.document_id)))
        assert len(records) == 2
        records.sort(key=lambda record: record.locator['index'])
        records[1].locator = deepcopy(records[0].locator)
        records[1].values = deepcopy(records[0].values)
        db.commit()
    # Row counts are unchanged, but page two has been replaced with another
    # copy of page one in the saved extraction. Only full locator-set validation
    # against the original detects this substitution.
    response = preview(case)
    assert response.status_code == 409, response.text
    assert case.row['beneficiary'] not in response.text
