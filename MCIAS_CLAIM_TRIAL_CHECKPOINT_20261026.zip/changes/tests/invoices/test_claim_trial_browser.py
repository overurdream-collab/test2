"""Existing audit button -> real trial API -> two-file download in Chromium.

The browser is bridged to the actual TestClient and synthetic source store;
there is no model/OCR substitute and no fake audit result. This is component
integration evidence, not a live Windows or institutional acceptance test.
"""
import importlib.util
from io import BytesIO
from urllib.parse import urlsplit
from zipfile import ZipFile

from openpyxl import load_workbook
import pytest

from tests.ai.test_ai_review_browser import browser_case
from tests.invoices.test_claim_trial import assert_originals, trial_case  # noqa: F401
from tests.workspace_v2.test_linked_references import linked  # noqa: F401


pytestmark = pytest.mark.skipif(not importlib.util.find_spec('playwright'),
                                reason='Playwright browser dependency is unavailable')


def test_existing_start_button_runs_one_claim_and_downloads_two_exclusive_outputs(trial_case, tmp_path):
    case = trial_case
    batch = case.import_batch()
    case.approve(batch)
    path = '/api/v1/audits/batches/' + batch.batch_id + '/trial-run'
    with browser_case(case) as (page, exchanges, held, fulfill, errors):
        assert page.evaluate('window.aiTest.context.claim_trial_enabled') is True
        page.evaluate('''async () => {
          const {auditWorkspace} = await import('/workspace-assets/audit_workspace.js');
          window.trialNavigation = [];
          window.trialContext = {...window.aiTest,
            navigate: path => window.trialNavigation.push(path), scope: 'institution'};
          auditWorkspace(window.trialContext);
        }''')
        select = page.locator('[name=audit-batch]')
        select.locator('option[value="' + batch.batch_id + '"]').wait_for(state='attached')
        select.select_option(batch.batch_id)
        start = page.get_by_role('button', name='Start audit', exact=True)
        start.wait_for()
        with page.expect_response(lambda response:
                urlsplit(response.url).path == path and response.request.method == 'POST', timeout=60_000) as completed:
            start.click()
        response = completed.value
        assert response.status == 201
        run = response.json()
        assert run['counts'] == {'accepted': 1, 'needs_action': 0}
        assert run['rows'][0]['invoice_match']['identity']['status'] == 'MATCH'
        assert run['financially_final'] is False
        page.get_by_role('button', name='View two outputs', exact=True).click()
        assert page.evaluate('window.trialNavigation.at(-1)') == '/institution/result-reports'
        # Exercise the existing route renderer with the same authenticated API,
        # as the main router does after navigation.
        page.evaluate('''async () => {
          const {resultReports} = await import('/workspace-assets/audit_workspace.js');
          window.trialContext.root.replaceChildren();
          resultReports(window.trialContext);
        }''')
        download = page.locator('[data-primary-download]')
        download.wait_for()
        with page.expect_download() as completed_download:
            download.click()
        saved = tmp_path / 'synthetic-primary-results.zip'
        completed_download.value.save_as(saved)
        exported = {}
        with ZipFile(BytesIO(saved.read_bytes())) as archive:
            assert set(archive.namelist()) == {'accepted.xlsx', 'needs_action.xlsx'}
            for filename in archive.namelist():
                book = load_workbook(BytesIO(archive.read(filename)), read_only=True)
                for row in list(book.active.values)[1:]:
                    assert row[0] not in exported
                    exported[row[0]] = filename.removesuffix('.xlsx')
                book.close()
        assert exported == {next(iter(batch.identities.values())): 'accepted'}
        posts = [exchange for exchange in exchanges if exchange['method'] == 'POST']
        assert [exchange['path'] for exchange in posts] == [path], posts
        assert any(exchange['path'].endswith('/primary-download')
                   and exchange['status'] == 200 for exchange in exchanges)
        assert not page.get_by_role('button', name='Approve', exact=True).count()
        assert not page.get_by_role('button', name='Reject', exact=True).count()
        assert not errors, errors
        assert not [exchange for exchange in exchanges if exchange['status'] >= 500], exchanges
    assert_originals(case)
