"""Native invoice matching with real original uploads and existing RBAC fixtures.

All data are synthetic. No model or parser is substituted in these API tests.
Permission entries below are local to each isolated test database.
"""
from copy import deepcopy
from hashlib import sha256
from types import SimpleNamespace

import pytest
from sqlalchemy import select
from sqlalchemy.orm import Session

from mcias.models import Permission
from mcias.models_claims import ClaimEntry
from mcias.seed.synthetic_invoices import invoice_pdf
from tests.api.conftest import api_factory, synthetic_password_hash  # noqa: F401
from tests.features.conftest import features_api  # noqa: F401
from tests.workspace_v2.test_access_and_registry import workspace  # noqa: F401
from tests.workspace_v2.test_mapping_and_results import arabic_workbook, mapping, upload_batch


@pytest.fixture
def invoice_case(workspace, monkeypatch, request):
    api = workspace
    monkeypatch.setenv('MCIAS_DOCUMENT_READER_MODE', 'native_preview')
    with Session(api.engine) as db:
        for code in ('medical_fields.text.read', 'medical_fields.beneficiary_token.read'):
            if db.scalar(select(Permission.id).where(Permission.code == code)) is None:
                db.add(Permission(code=code))
        db.commit()

    raw = arabic_workbook()
    batch_id, document_id = upload_batch(api, raw, 'SYN-native-match-claims.xlsx')
    body = mapping()
    body['columns'].update(gross_amount='المطلوب', copay_amount='إجمالي التحمل')
    path = '/api/v1/claims/batches/' + batch_id
    response = api.client.put(path + '/mapping', json=body, headers=api.headers['root'])
    assert response.status_code == 200, response.text
    response = api.client.post(path + '/resume', headers=api.headers['root'])
    assert response.status_code == 200 and response.json()['imported_count'] == 4, response.text
    with Session(api.engine) as db:
        claims = list(db.scalars(select(ClaimEntry).where(ClaimEntry.batch_id == batch_id)
                                .order_by(ClaimEntry.service_code)))
        target = claims[0]
        row = {'invoice_reference': target.claim_reference,
               'beneficiary': target.beneficiary_token, 'provider': target.provider_code,
               'service': target.service_code, 'service_date': target.service_date.isoformat(),
               'gross': '100.00', 'copay': '20.00', 'net': '80.00', 'currency': target.currency}
        identities = [claim.id for claim in claims]
    case = SimpleNamespace(api=api, claim_id=identities[0], other_claim_id=identities[1],
                           batch_id=batch_id, claim_document_id=document_id,
                           claim_raw=raw, row=row, mapping=body,
                           source_documents={document_id: raw})
    case.base = f'/api/v1/claims/entries/{case.claim_id}/invoice-matches'

    def upload(rows=None, *, raw=None, filename='SYN-native-invoice.pdf', kind='invoice', claim_id=None):
        raw = raw if raw is not None else invoice_pdf(rows or [deepcopy(case.row)])
        response = api.client.post('/api/v1/ingestion/uploads?filename=' + filename,
            content=raw, headers={**api.headers['root'], 'Content-Type': 'application/octet-stream'})
        assert response.status_code == 200, response.text
        document = response.json()['document_id']
        assert response.json()['status'] in ('extracted', 'duplicate', 'review_required'), response.text
        response = api.client.post(
            f'/api/v1/claims/entries/{claim_id or case.claim_id}/attachments/{document}?kind={kind}',
            headers=api.headers['root'])
        assert response.status_code == 201, response.text
        case.source_documents[document] = raw
        return SimpleNamespace(document_id=document, attachment_id=response.json()['id'],
                               raw=raw, sha256=sha256(raw).hexdigest())

    case.upload = upload
    options = deepcopy(getattr(request, 'param', {}) or {})
    if options.pop('attach', True):
        overrides = options.pop('overrides', {})
        row = {**row, **overrides}
        rows = options.pop('rows', None) or [row]
        case.invoice = upload(rows, **options)
    else:
        case.invoice = None
    return case
