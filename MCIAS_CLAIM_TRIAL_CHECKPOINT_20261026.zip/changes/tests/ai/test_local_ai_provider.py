"""Provider contract/safety checks. These never claim actual model inference."""
from contextlib import nullcontext
import json

import pytest

from mcias.services import local_ai_provider as provider


@pytest.fixture
def settings(monkeypatch, tmp_path):
    path = tmp_path / "local.gguf"
    path.write_bytes(b"synthetic-invalid-weight-file")
    monkeypatch.setenv("MCIAS_AI_MODEL_FILE", str(path))
    monkeypatch.delenv("MCIAS_AI_MODEL_SHA256", raising=False)
    monkeypatch.delenv("MCIAS_AI_TIMEOUT_SECONDS", raising=False)
    return path


def error_code(expected, operation):
    with pytest.raises(provider.LocalAIError) as error:
        operation()
    assert error.value.code == expected
    assert str(error.value) == expected


def test_unconfigured_runtime_is_explicit_not_empty_success(monkeypatch):
    monkeypatch.delenv("MCIAS_AI_MODEL_FILE", raising=False)
    error_code("AI_NOT_CONFIGURED", lambda: provider.generate("system", "{}"))


@pytest.mark.parametrize("value", ["0", "301", "not-a-number"])
def test_deadline_configuration_cannot_disable_bound(settings, monkeypatch, value):
    monkeypatch.setenv("MCIAS_AI_TIMEOUT_SECONDS", value)
    error_code("AI_CONFIGURATION_INVALID", lambda: provider.generate("system", "{}"))


def test_other_model_digest_cannot_claim_approved_identity(settings, monkeypatch):
    monkeypatch.setenv("MCIAS_AI_MODEL_SHA256", "a" * 64)
    error_code("AI_MODEL_UNSUPPORTED", lambda: provider.generate("system", "{}"))


def test_relative_model_path_is_rejected(monkeypatch):
    monkeypatch.setenv("MCIAS_AI_MODEL_FILE", "untrusted.gguf")
    error_code("AI_CONFIGURATION_INVALID", lambda: provider.generate("system", "{}"))


def test_bad_weights_rejected_in_real_spawn_before_optional_runtime_import(settings):
    error_code("AI_MODEL_HASH_MISMATCH", lambda: provider.generate("system", "{}"))


def test_input_limit_applies_before_spawning(monkeypatch):
    monkeypatch.delenv("MCIAS_AI_MODEL_FILE", raising=False)
    error_code("AI_INPUT_INVALID", lambda: provider.generate("s", "x" * provider.MAX_INPUT_BYTES))


def test_non_string_source_is_not_serialized_into_prompt(settings):
    error_code("AI_INPUT_INVALID", lambda: provider.generate("s", {"private": "source"}))


def test_concurrent_local_call_is_busy_instead_of_second_heavy_worker():
    with provider._model_slot():
        error_code("AI_BUSY", lambda: provider._model_slot().__enter__())


class FakeConnection:
    def __init__(self, message=None, ready=True, receive_error=None):
        self.message = message
        self.ready = ready
        self.receive_error = receive_error
        self.closed = False

    def poll(self, timeout):
        self.timeout = timeout
        return self.ready

    def recv(self):
        if self.receive_error:
            raise self.receive_error
        return self.message

    def close(self):
        self.closed = True


class FakeWorker:
    def __init__(self):
        self.alive = True
        self.terminated = False
        self.joined = False

    def start(self):
        pass

    def is_alive(self):
        return self.alive

    def terminate(self):
        self.terminated = True
        self.alive = False

    def join(self, timeout):
        self.joined = True


def fake_child(monkeypatch, receiver):
    sender = FakeConnection()
    worker = FakeWorker()
    class Context:
        def Pipe(self, duplex):
            assert duplex is False
            return receiver, sender

        def Process(self, **kwargs):
            assert kwargs["target"] is provider._worker
            assert kwargs["daemon"] is True
            return worker
    monkeypatch.setattr(provider.mp, "get_context", lambda name: Context())
    return worker, sender


def test_timeout_terminates_and_closes_child_without_success(settings, monkeypatch):
    receiver = FakeConnection(ready=False)
    worker, sender = fake_child(monkeypatch, receiver)
    error_code("AI_TIMEOUT", lambda: provider.generate("system", "{}"))
    assert worker.terminated and worker.joined and receiver.closed and sender.closed


def test_child_crash_is_explicit_and_cleans_resources(settings, monkeypatch):
    receiver = FakeConnection(receive_error=EOFError())
    worker, sender = fake_child(monkeypatch, receiver)
    error_code("AI_WORKER_FAILED", lambda: provider.generate("system", "{}"))
    assert worker.terminated and worker.joined and receiver.closed and sender.closed


def test_mock_child_contract_returns_raw_only_after_strict_validation(settings, monkeypatch):
    raw = '{"signals":[]}'
    result = {"raw_text": raw, "provider_metadata": {"model_sha256": provider.MODEL_SHA256,
        "finish_reason": "stop"}, "private_evidence": {"system_prompt": "system", "payload": "{}"}}
    receiver = FakeConnection({"ok": True, "result": result})
    worker, _ = fake_child(monkeypatch, receiver)
    assert provider.generate("system", "{}") == result
    assert worker.joined and receiver.closed


@pytest.mark.parametrize("raw", ['{}', '{"signals":[],"payment":0}', '{"signals":[{}]}',
    '{"signals":NaN}', '{"signals":[{"line_item_id":"L1","source_id":"S1","exact_quote":"text",'
    '"reported_quantity":"1","explanation":"review","financially_final":true}]}'])
def test_invalid_structured_response_is_rejected(raw):
    error_code("AI_OUTPUT_INVALID", lambda: provider._validate_output(raw, "stop"))


def test_truncated_generation_is_not_a_valid_empty_result():
    error_code("AI_OUTPUT_TRUNCATED", lambda: provider._validate_output('{"signals":[]}', "length"))


def test_worker_error_code_cannot_leak_source_text(settings, monkeypatch):
    receiver = FakeConnection({"ok": False, "code": "private patient source content"})
    fake_child(monkeypatch, receiver)
    error_code("AI_WORKER_FAILED", lambda: provider.generate("system", "{}"))
