"""Advisory drawer in Chromium, using actual A1 APIs and synthetic sources.

The ordinary ``ai_case`` fixture explicitly replaces only the model provider.
These tests exercise browser DOM, real authorization, source extraction and
attestation persistence; they make no claim about real-model accuracy.
"""
from contextlib import contextmanager
import importlib.util
import json
from pathlib import Path
import shutil
from urllib.parse import urlsplit

import pytest

from tests.workspace_v2.test_access_and_registry import grants


pytestmark = pytest.mark.skipif(
    not importlib.util.find_spec('playwright'),
    reason='Playwright browser dependency is unavailable',
)


_SHELL = '''<!doctype html><html lang="en" dir="ltr"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<link rel="stylesheet" href="/workspace-assets/workspace.css"></head><body>
<main id="test-root"></main><div id="toast" hidden></div>
<dialog id="drawer" aria-labelledby="drawer-title"></dialog></body></html>'''


@contextmanager
def browser_case(case, *, user='root', hold=None):
    """Reuse the repository's browser→TestClient bridge, with no live server."""
    from playwright.sync_api import sync_playwright

    with sync_playwright() as playwright:
        executable = shutil.which('chromium')
        if not executable and not Path(playwright.chromium.executable_path).exists():
            pytest.skip('Chromium binary is unavailable')
        browser = playwright.chromium.launch(
            executable_path=executable, headless=True, args=['--no-sandbox'])
        page = browser.new_page(viewport={'width': 1440, 'height': 1000})
        errors, exchanges, held = [], [], []
        page.on('pageerror', lambda error: errors.append(str(error)))

        def fulfill(route):
            request = route.request
            url = urlsplit(request.url)
            path = url.path + ('?' + url.query if url.query else '')
            headers = {key: value for key, value in request.headers.items()
                       if key.lower() in ('authorization', 'content-type', 'accept')}
            response = case.api.client.request(request.method, path,
                content=request.post_data_buffer, headers=headers)
            body = request.post_data
            exchanges.append({'method': request.method, 'path': url.path,
                'status': response.status_code,
                'body': json.loads(body) if body and headers.get('content-type') == 'application/json' else None})
            route.fulfill(status=response.status_code,
                headers={key: value for key, value in response.headers.items()
                         if key.lower() not in ('content-length', 'content-encoding')},
                body=response.content)

        def local_request(route):
            if urlsplit(route.request.url).path == '/__ai_browser__':
                route.fulfill(status=200, content_type='text/html', body=_SHELL)
            elif hold and hold(route.request):
                held.append(route)
            else:
                fulfill(route)

        page.route('**/*', local_request)
        page.goto('http://mcias.test/__ai_browser__')
        token = case.api.headers[user]['Authorization'].removeprefix('Bearer ')
        page.evaluate('''async ({token}) => {
          const {ApiClient} = await import('/workspace-assets/api.js');
          const {preferences} = await import('/workspace-assets/ui.js');
          preferences.lang = 'en';
          const api = new ApiClient(); api.setToken(token);
          const context = await api.request('/api/v1/workspace/context');
          window.aiTest = {api, context, root: document.querySelector('#test-root')};
          window.openReview = async (id) => {
            const {openAIReview} = await import('/workspace-assets/ai_review.js');
            void openAIReview(window.aiTest, id);
          };
        }''', {'token': token})
        try:
            yield page, exchanges, held, fulfill, errors
        finally:
            browser.close()


def open_review(page, case):
    page.evaluate('(id) => window.openReview(id)', case.claim_id)
    page.locator('[data-ai-review]').wait_for()


def select_source(page, role, filename):
    choice = page.locator(f'[name=ai-{role}-source]')
    choice.wait_for()
    option = choice.locator('option').filter(has_text=filename)
    assert option.count() == 1
    choice.select_option(option.get_attribute('value'))


def fill_attestation(page, case):
    select_source(page, 'invoice', 'SYN-AI-itemized-invoice.pdf')
    select_source(page, 'service', 'SYN-AI-service-record.csv')
    assert page.locator('[name=ai-invoice-text]').input_value() == case.invoice_text
    assert page.locator('[name=ai-service-text]').input_value() == case.service_text
    for role in ('invoice', 'service'):
        assert page.locator(f'[name=ai-{role}-text]').evaluate('(input) => input.readOnly')
    # Quantity/unit must be consciously transcribed from the invoice, never
    # initialized from the claim or inferred by the browser.
    assert page.locator('[name=ai-billed-quantity]').input_value() == ''
    assert page.locator('[name=ai-unit]').input_value() == ''
    assert page.locator('[name=ai-service-code]').input_value() == 'LAB-A'
    for role, payload_key in (('invoice', 'invoice'), ('service', 'service_record')):
        span = case.payload[payload_key]
        page.locator(f'[name=ai-{role}-start]').fill(str(span['start']))
        page.locator(f'[name=ai-{role}-end]').fill(str(span['end']))
        text = case.invoice_text if role == 'invoice' else case.service_text
        assert page.locator(f'[data-ai-quote={role}]').text_content() == text[span['start']:span['end']]
    page.locator('[name=ai-unit]').fill(case.payload['unit'])
    page.locator('[name=ai-billed-quantity]').fill(case.payload['billed_quantity'])
    page.locator('[name=ai-reason]').fill(case.payload['reason'])


def test_real_source_attestation_pending_run_and_history_in_browser(ai_case):
    """The drawer posts exact source spans and shows only advisory outcomes."""
    case = ai_case
    with browser_case(case, hold=lambda request:
            request.method == 'POST' and urlsplit(request.url).path == case.base + '/runs') as bridge:
        page, exchanges, held, fulfill, errors = bridge
        # Exercise the real audit table integration before opening its drawer.
        page.evaluate('''async () => {
          const {auditWorkspace} = await import('/workspace-assets/audit_workspace.js');
          auditWorkspace({...window.aiTest, navigate: () => {}, scope: 'institution'});
        }''')
        page.locator('[name=audit-batch]').select_option(case.batch_id)
        row = page.locator('tr').filter(has_text=case.claim_id)
        row.get_by_role('button', name='Advisory AI review', exact=True).click()
        page.locator('[name=ai-invoice-source]').wait_for()
        fill_attestation(page, case)
        assert page.locator('#drawer').get_by_role('button', name='Approve', exact=True).count() == 0
        assert page.locator('#drawer').get_by_role('button', name='Reject', exact=True).count() == 0
        page.get_by_role('button', name='Save source attestation', exact=True).click()
        page.wait_for_function('''() => document.querySelector('[data-ai-attestation]')?.textContent.includes('1')''')
        saved = [entry for entry in exchanges if entry['path'] == case.base + '/attestations']
        assert len(saved) == 1 and saved[0]['status'] == 201
        assert saved[0]['body'] == case.payload
        assert not case.provider_calls
        run_button = page.get_by_role('button', name='Run advisory review', exact=True)
        run_button.click()
        page.wait_for_function('''() => document.querySelector('[data-ai-run-result]')?.textContent.match(/await|running|pending/i)''')
        assert run_button.is_disabled()
        assert len(held) == 1
        assert not case.provider_calls
        # Resolve the network response using the real API, which invokes the
        # fixture's explicitly labeled contract-test provider exactly once.
        fulfill(held.pop())
        page.locator('[data-ai-run-result]').get_by_text(case.service_text, exact=True).wait_for()
        assert len(case.provider_calls) == 1
        assert 'SYN-CONTRACT-TEST-DOUBLE-NOT-REAL-INFERENCE' in page.locator('[data-ai-run-result]').text_content()
        run_posts = [entry for entry in exchanges if entry['path'] == case.base + '/runs' and entry['method'] == 'POST']
        assert len(run_posts) == 1 and run_posts[0]['status'] == 201
        page.get_by_role('button', name='Refresh history', exact=True).click()
        history_result = page.locator('[data-ai-history]').get_by_role(
            'button', name='View result and evidence', exact=True)
        history_result.wait_for()
        history_result.click()
        page.locator('[data-ai-run-result]').get_by_text(case.service_text, exact=True).wait_for()
        assert any(entry['method'] == 'GET' and entry['path'].startswith(case.base + '/runs/') for entry in exchanges)
        assert all(entry['path'] in (case.base + '/attestations', case.base + '/runs')
                   for entry in exchanges if entry['method'] != 'GET')
        assert not errors, errors
        assert not any(entry['status'] >= 500 for entry in exchanges), exchanges


def test_unconfigured_synthetic_manifest_blocks_review_in_browser(ai_case, monkeypatch):
    monkeypatch.delenv('MCIAS_AI_SYNTHETIC_MANIFEST')
    with browser_case(ai_case) as (page, exchanges, held, fulfill, errors):
        open_review(page, ai_case)
        page.locator('[data-ai-configuration-blocked]').wait_for()
        assert page.get_by_role('button', name='Run advisory review', exact=True).is_disabled()
        assert not [entry for entry in exchanges if entry['method'] == 'POST']
        assert not ai_case.provider_calls
        assert not errors, errors


def test_source_permission_denial_is_generic_and_reveals_no_source_in_browser(ai_case):
    response = grants(ai_case.api, ['profile.read', 'claims.read', 'claims.review', 'ingestion.read'], user='admin')
    assert response.status_code == 200, response.text
    with browser_case(ai_case, user='admin') as (page, exchanges, held, fulfill, errors):
        open_review(page, ai_case)
        page.locator('#drawer [role=alert]').get_by_text('Permission required', exact=True).first.wait_for()
        assert page.locator('[name=ai-invoice-text]').count() == 0
        assert ai_case.service_text not in page.locator('#drawer').inner_text()
        assert any(entry['path'] == ai_case.base + '/evidence' and entry['status'] == 403 for entry in exchanges)
        assert not ai_case.provider_calls
        assert not errors, errors


def test_closed_drawer_does_not_render_late_evidence(ai_case):
    with browser_case(ai_case, hold=lambda request:
            urlsplit(request.url).path == ai_case.base + '/evidence') as bridge:
        page, exchanges, held, fulfill, errors = bridge
        open_review(page, ai_case)
        page.wait_for_timeout(30)
        assert len(held) == 1
        page.get_by_role('button', name='Close', exact=True).click()
        fulfill(held.pop())
        page.wait_for_timeout(30)
        assert not page.locator('#drawer').evaluate('(dialog) => dialog.open')
        assert page.locator('[name=ai-invoice-text]').count() == 0
        assert ai_case.service_text not in page.locator('#drawer').text_content()
        assert not errors, errors


def test_native_source_selection_uses_unicode_offsets_and_safe_text(ai_case):
    from tests.ai.conftest import service_record

    case = ai_case
    quote = 'performed 1 LAB-A test'
    text = '😀 PREFIX <img src=x onerror="window.aiInjected=true"> / ' + quote
    source = case.upload(service_record(text), 'SYN-AI-unicode-service.csv')
    case.register_manifest()
    with browser_case(case) as (page, exchanges, held, fulfill, errors):
        open_review(page, case)
        fill_attestation(page, case)
        select_source(page, 'service', 'SYN-AI-unicode-service.csv')
        page.locator('[name=ai-service-text]').evaluate('''(input, quote) => {
          const start = input.value.indexOf(quote);
          input.setSelectionRange(start, start + quote.length);
          input.dispatchEvent(new Event('select', {bubbles: true}));
          input.dispatchEvent(new MouseEvent('mouseup', {bubbles: true}));
        }''', quote)
        page.get_by_role('button', name='Use selected text', exact=True).nth(1).click()
        start = source.text.index(quote)
        assert page.locator('[name=ai-service-start]').input_value() == str(start)
        assert page.locator('[name=ai-service-end]').input_value() == str(start + len(quote))
        assert page.locator('[data-ai-quote=service]').text_content() == quote
        assert page.locator('#drawer img[src=x]').count() == 0
        assert page.evaluate('window.aiInjected === undefined')
        page.get_by_role('button', name='Save source attestation', exact=True).click()
        page.wait_for_function('''() => document.querySelector('[data-ai-attestation]')?.textContent.includes('1')''')
        saved = [entry for entry in exchanges if entry['path'] == case.base + '/attestations']
        assert len(saved) == 1 and saved[0]['status'] == 201
        assert saved[0]['body']['service_record'] == {
            'attachment_id': source.attachment_id, 'record_id': source.record_id,
            'field': 'text', 'start': start, 'end': start + len(quote)}
        assert not case.provider_calls
        assert not errors, errors
