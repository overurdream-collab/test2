"""A1 persistence on a dedicated migrated PostgreSQL DB, with a provider stub.

This proves database/API integration, not real model inference or clinical
accuracy. The ordinary API factory supplies real sessions and migrations.
"""
import logging.config
import os

import pytest
from sqlalchemy import func, select
from sqlalchemy.engine import make_url
from sqlalchemy.orm import Session

from mcias.app import app, get_rate_limit_db
from mcias.models import AuditLog, SourceFile
from mcias.models_audit import AuditSnapshot
from mcias.models_claims import ClaimEntry
from mcias.models_ingestion import IngestionDocument
from mcias.services.registry_service import store
from tests.ai.conftest import ai_case as build_ai_case
from tests.workspace_v2.test_access_and_registry import workspace as build_workspace


@pytest.mark.skipif(not os.getenv('MCIAS_AI_TEST_DATABASE_URL'),
                    reason='Dedicated PostgreSQL A1 test database required')
def test_a1_review_persists_on_postgres_without_financial_mutation(
        api_factory, monkeypatch, tmp_path):
    url = os.environ['MCIAS_AI_TEST_DATABASE_URL']
    if make_url(url).get_backend_name() != 'postgresql':
        pytest.fail('A1 persistence proof requires an isolated PostgreSQL test database')
    # Alembic's CLI fileConfig replaces pytest capture handlers and disables
    # application loggers. Isolate that CLI-only setup, not the real migrations.
    with monkeypatch.context() as migration_logging:
        migration_logging.setattr(logging.config, 'fileConfig', lambda *args, **kwargs: None)
        api = api_factory(url=url)
    # Migrations already seed the feature catalog; do not invoke features_api,
    # which intentionally inserts that catalog for ordinary SQLite fixtures.
    build_workspace.__wrapped__(api, monkeypatch, tmp_path)
    case = build_ai_case.__wrapped__(api, monkeypatch, tmp_path)
    monkeypatch.setitem(app.dependency_overrides, get_rate_limit_db, api.database)

    with Session(api.engine) as db:
        before_amount = db.get(ClaimEntry, case.claim_id).claimed_amount
        before_snapshots = db.scalar(select(func.count()).select_from(AuditSnapshot))

    attested = case.attest()
    assert attested.status_code == 201, attested.text
    attestation = attested.json()
    response = case.run(attestation)
    assert response.status_code == 201, response.text
    run = response.json()
    assert run['status'] == 'completed' and run['financially_final'] is False
    assert run['result']['review_required'] is True
    assert run['result']['provider']['provider'] == 'SYN-CONTRACT-TEST-DOUBLE-NOT-REAL-INFERENCE'
    assert len(run['result']['findings']) == 1
    assert run['result']['findings'][0]['source_reported_quantity'] == '1'
    assert run['result']['findings'][0]['billed_quantity'] == '2'

    cached = case.run(attestation)
    assert cached.status_code == 200, cached.text
    assert cached.json()['id'] == run['id'] and len(case.provider_calls) == 1
    history = api.client.get(case.base + '/runs/' + run['id'], headers=api.headers['root'])
    assert history.status_code == 200 and history.json()['stale'] is False

    with Session(api.engine) as db:
        assert db.get(ClaimEntry, case.claim_id).claimed_amount == before_amount
        assert db.scalar(select(func.count()).select_from(AuditSnapshot)) == before_snapshots
        events = list(db.scalars(select(AuditLog).where(
            AuditLog.resource_type == 'claim_ai_review', AuditLog.resource_id == run['id'])))
        assert sorted(event.action for event in events) == ['ai_review.finished', 'ai_review.started']
        assert all(event.hash and len(event.hash) == 64 for event in events)
        assert all(len(event.resource_id) == 36 for event in events)
        assert db.scalar(select(func.count()).select_from(AuditLog).where(
            AuditLog.action == 'ai_input.attested', AuditLog.resource_id == attestation['id'])) == 1
        for document_id, original in case.source_documents.items():
            document = db.get(IngestionDocument, document_id)
            source = db.get(SourceFile, document.source_id)
            assert store().get(source.storage_key, source.sha256) == original
