"""Real API/source/security integration with an explicit inference test double.

These tests do not establish real model execution or clinical accuracy. Uploads,
source hashes, encrypted storage, sessions and authorization use existing code.
"""
from copy import deepcopy
from hashlib import sha256
from io import BytesIO
import csv
import json

import pytest
from reportlab.pdfgen import canvas
from sqlalchemy import func, select, update
from sqlalchemy.orm import Session

from mcias.models import AuditLog, MFAFactor, Role, SourceFile, UserRole
from mcias.models_audit import AuditSnapshot
from mcias.models_claims import ClaimEntry
from mcias.models_ingestion import ExtractedSourceRecord, IngestionDocument
from mcias.services import local_ai_provider as provider
from mcias.services.registry_service import store
from tests.workspace_v2.test_access_and_registry import grants


def selection(source):
    return {'attachment_id': source.attachment_id, 'record_id': source.record_id,
            'field': 'text', 'start': 0, 'end': len(source.text)}


def itemized_pdf(quantity):
    output = BytesIO()
    pdf = canvas.Canvas(output, invariant=1)
    pdf.drawString(30, 800, 'SYNTHETIC INVOICE - NOT A REAL INVOICE')
    line = 'SERVICE_CODE: LAB-A; UNIT: test'
    if quantity is not None:
        line += '; QUANTITY: ' + quantity
    pdf.drawString(30, 760, line)
    pdf.save()
    return output.getvalue()


def record_csv(text):
    output = __import__('io').StringIO(newline='')
    writer = csv.writer(output)
    writer.writerow(['text']); writer.writerow([text])
    return output.getvalue().encode('utf-8')


def created_attestation(case, payload=None, headers=None):
    response = case.api.client.post(case.base + '/attestations',
        json=payload or case.payload, headers=headers or case.api.headers['root'])
    assert response.status_code == 201, response.text
    body = response.json()
    assert body['id'] and len(body['fingerprint']) == 64
    return body


def create_run(case, attestation, headers=None):
    return case.api.client.post(case.base + '/runs', json={
        'attestation_id': attestation['id'],
        'expected_fingerprint': attestation['fingerprint'],
    }, headers=headers or case.api.headers['root'])


def test_review_uses_actual_sources_and_never_writes_financial_results(ai_case):
    case = ai_case; api = case.api
    with Session(api.engine) as db:
        before_amount = db.get(ClaimEntry, case.claim_id).claimed_amount
        before_snapshots = db.scalar(select(func.count()).select_from(AuditSnapshot))
    attestation = created_attestation(case)
    response = create_run(case, attestation)
    assert response.status_code == 201, response.text
    run = response.json()
    assert run['stage'] == 'advisory' and run['financially_final'] is False
    assert run['claim_id'] == case.claim_id and run['attestation_id'] == attestation['id']
    assert run['result']['assessment'] == 'signal_detected'
    assert run['result']['review_required'] is True
    assert run['result']['actual_model_calls'] == 1
    assert run['result']['findings']
    assert len(case.provider_calls) == 1
    read = api.client.get(case.base + '/runs/' + run['id'], headers=api.headers['root'])
    assert read.status_code == 200, read.text
    assert read.json()['id'] == run['id'] and read.json()['financially_final'] is False
    def keys(value):
        if isinstance(value,dict):
            return set(value).union(*(keys(v) for v in value.values()))
        if isinstance(value,list):
            return set().union(*(keys(v) for v in value))
        return set()
    # Provenance hashes are public metadata; complete prompts/raw output stay encrypted.
    assert not {'system_prompt','rendered_prompt','raw_text','raw_output','private_evidence'} & keys(read.json())
    with Session(api.engine) as db:
        assert db.get(ClaimEntry, case.claim_id).claimed_amount == before_amount
        assert db.scalar(select(func.count()).select_from(AuditSnapshot)) == before_snapshots
        for document_id, original in case.source_documents.items():
            document = db.get(IngestionDocument, document_id)
            source = db.get(SourceFile, document.source_id)
            assert source.sha256 == sha256(original).hexdigest()
            assert store().get(source.storage_key, source.sha256) == original


def test_review_payload_is_encrypted_and_audit_metadata_has_no_private_text(ai_case):
    case = ai_case; attestation = created_attestation(case)
    response = create_run(case, attestation)
    assert response.status_code == 201, response.text
    run = response.json()
    with Session(case.api.engine) as db:
        events = list(db.scalars(select(AuditLog).where(AuditLog.resource_type == 'claim_ai_review',
            AuditLog.resource_id == run['id'])))
        assert {event.action for event in events} == {'ai_review.started', 'ai_review.finished'}
        assert all(len(event.resource_id) == 36 for event in events)
        serialized = json.dumps([event.details for event in events], ensure_ascii=False)
        assert case.payload['reason'] not in serialized
        assert 'تم إجراء' not in serialized
        assert 'exact_quote' not in serialized and 'system_prompt' not in serialized
        attested = list(db.scalars(select(AuditLog).where(AuditLog.action == 'ai_input.attested',
            AuditLog.resource_id == attestation['id'])))
        assert len(attested) == 1
        attestation_metadata = json.dumps(attested[0].details, ensure_ascii=False)
        assert case.payload['reason'] not in attestation_metadata
        assert 'LAB-A' not in attestation_metadata and 'تم إجراء' not in attestation_metadata
        assert 'billed_quantity' not in attestation_metadata
        artifact_found = False
        for event in events:
            for value in event.details.values():
                if not isinstance(value, str) or len(value) != 36:
                    continue
                source = db.get(SourceFile, value)
                if source is None:
                    continue
                private = store().get(source.storage_key, source.sha256)
                # At-rest content is ciphertext, even though test data is synthetic.
                encrypted = (store().root / source.storage_key).read_bytes()
                assert private != encrypted and b'"signals"' not in encrypted
                if b'signals' in private:
                    artifact_found = True
        assert artifact_found, 'No encrypted model-result artifact was linked from audit metadata'


def test_completed_review_is_idempotent_and_history_remains_readable(ai_case):
    attestation = created_attestation(ai_case)
    first = create_run(ai_case, attestation)
    assert first.status_code == 201, first.text
    again = create_run(ai_case, attestation)
    assert again.status_code == 200, again.text
    assert again.json()['id'] == first.json()['id']
    assert len(ai_case.provider_calls) == 1
    history = ai_case.api.client.get(ai_case.base + '/runs', headers=ai_case.api.headers['root'])
    assert history.status_code == 200
    assert [row['id'] for row in history.json()['items']] == [first.json()['id']]


def test_run_rejects_a_fingerprint_that_does_not_match_the_attestation(ai_case):
    attestation = created_attestation(ai_case)
    response = ai_case.api.client.post(ai_case.base + '/runs', json={
        'attestation_id': attestation['id'], 'expected_fingerprint': '0' * 64,
    }, headers=ai_case.api.headers['root'])
    assert response.status_code == 409, response.text
    assert not ai_case.provider_calls


def test_authentication_and_permissions_are_backend_enforced(ai_case):
    api = ai_case.api
    assert api.client.get(ai_case.base + '/evidence').status_code == 401
    assert api.client.get(ai_case.base + '/evidence', headers=api.headers['none']).status_code == 403
    assert api.client.post(ai_case.base + '/attestations', json=ai_case.payload,
        headers=api.headers['none']).status_code == 403
    assert api.client.post(ai_case.base + '/runs', json={
        'attestation_id': ai_case.claim_id, 'expected_fingerprint': '0' * 64},
        headers=api.headers['none']).status_code == 403
    assert not ai_case.provider_calls


def test_source_text_permission_is_required_in_addition_to_claim_review(ai_case):
    api = ai_case.api
    response = grants(api, ['claims.read', 'claims.review', 'ingestion.read'], user='admin')
    assert response.status_code == 200, response.text
    assert api.client.get(ai_case.base + '/evidence', headers=api.headers['admin']).status_code == 403
    assert api.client.post(ai_case.base + '/attestations', json=ai_case.payload,
        headers=api.headers['admin']).status_code == 403
    assert not ai_case.provider_calls


def test_even_privileged_other_tenant_cannot_read_claim_or_review(ai_case):
    api = ai_case.api
    with Session(api.engine) as db:
        role = db.scalar(select(Role).where(Role.code == 'super_admin'))
        db.add(UserRole(user_id=api.ids['other'], role_id=role.id))
        db.add(MFAFactor(user_id=api.ids['other'], enabled=True,
            encrypted_secret=b'SYN-unused-session-fixture-not-a-login-secret'))
        db.commit()
    assert api.client.get(ai_case.base + '/evidence', headers=api.headers['other']).status_code == 404
    attestation = created_attestation(ai_case)
    run = create_run(ai_case, attestation).json()
    assert api.client.get(ai_case.base + '/runs/' + run['id'],
        headers=api.headers['other']).status_code == 404


@pytest.mark.parametrize('change', ['wrong_record', 'same_document', 'other_claim_attachment'])
def test_attestation_cannot_change_source_association(ai_case, change):
    payload = deepcopy(ai_case.payload)
    if change == 'wrong_record':
        payload['invoice']['record_id'] = ai_case.service_record_id
    elif change == 'same_document':
        payload['service_record'] = deepcopy(payload['invoice'])
    else:
        source = ai_case.upload(record_csv('SYN other claim: performed LAB-A one test.'),
            'SYN-other-claim-record.csv', claim_id=ai_case.other_claim_id)
        ai_case.register_manifest()
        payload['service_record'] = selection(source)
    response = ai_case.api.client.post(ai_case.base + '/attestations', json=payload,
        headers=ai_case.api.headers['root'])
    assert response.status_code in (404, 409), response.text
    assert not ai_case.provider_calls


@pytest.mark.parametrize('quantity', ['20', None])
def test_invoice_quantity_must_be_present_and_exact_not_inferred_from_claim(ai_case, quantity):
    source = ai_case.upload(itemized_pdf(quantity), 'SYN-quantity-evidence.pdf', kind='invoice')
    ai_case.register_manifest()
    payload = deepcopy(ai_case.payload); payload['invoice'] = selection(source)
    assert payload['billed_quantity'] == '2'
    response = ai_case.api.client.post(ai_case.base + '/attestations', json=payload,
        headers=ai_case.api.headers['root'])
    assert response.status_code == 409, response.text
    assert not ai_case.provider_calls


def test_changed_extraction_after_attestation_is_rejected_before_model_call(ai_case):
    attestation = created_attestation(ai_case)
    with Session(ai_case.api.engine) as db:
        db.execute(update(ExtractedSourceRecord).where(ExtractedSourceRecord.id == ai_case.service_record_id)
            .values(values={'text': 'SYN altered extraction that is not in the original source'}))
        db.commit()
    response = create_run(ai_case, attestation)
    assert response.status_code in (409, 503), response.text
    assert not ai_case.provider_calls


def test_changed_encrypted_original_is_rejected_before_model_call(ai_case):
    attestation = created_attestation(ai_case)
    with Session(ai_case.api.engine) as db:
        document = db.get(IngestionDocument, ai_case.service_document_id)
        source = db.get(SourceFile, document.source_id)
        path = store().root / source.storage_key
        blob = path.read_bytes(); path.write_bytes(blob[:-1] + bytes([blob[-1] ^ 1]))
    response = create_run(ai_case, attestation)
    assert response.status_code in (409, 503), response.text
    assert not ai_case.provider_calls


def test_stale_attestation_editor_and_old_version_run_are_rejected(ai_case):
    first = created_attestation(ai_case)
    payload = deepcopy(ai_case.payload); payload['reason'] += ' revised operator source confirmation'
    stale = ai_case.api.client.post(ai_case.base + '/attestations', json=payload,
        headers=ai_case.api.headers['root'])
    assert stale.status_code == 409, stale.text
    payload['expected_previous_id'] = first['id']
    second = created_attestation(ai_case, payload)
    assert second['id'] != first['id'] and second['version'] == first['version'] + 1
    stale_run = create_run(ai_case, first)
    assert stale_run.status_code == 409, stale_run.text
    assert not ai_case.provider_calls


def test_server_manifest_is_required_and_client_synthetic_flag_is_not_trusted(ai_case, monkeypatch):
    monkeypatch.delenv('MCIAS_AI_SYNTHETIC_MANIFEST', raising=False)
    denied = ai_case.api.client.post(ai_case.base + '/attestations', json=ai_case.payload,
        headers=ai_case.api.headers['root'])
    assert denied.status_code == 503, denied.text
    forged = {**deepcopy(ai_case.payload), 'synthetic': True}
    assert ai_case.api.client.post(ai_case.base + '/attestations', json=forged,
        headers=ai_case.api.headers['root']).status_code == 422
    assert not ai_case.provider_calls


def test_manifest_revocation_after_attestation_prevents_new_inference(ai_case):
    attestation = created_attestation(ai_case)
    manifest = json.loads(ai_case.source_manifest_path.read_text())
    manifest['organizations'][ai_case.api.organization_id]['source_sha256'] = []
    ai_case.source_manifest_path.write_text(json.dumps(manifest))
    response = create_run(ai_case, attestation)
    assert response.status_code == 409, response.text
    assert not ai_case.provider_calls


def test_provider_timeout_is_preserved_as_failed_and_retry_creates_new_run(ai_case, monkeypatch):
    attestation = created_attestation(ai_case)
    original = provider.generate
    def timeout(system, payload):
        raise provider.LocalAIError('AI_TIMEOUT')
    monkeypatch.setattr(provider, 'generate', timeout)
    failed = create_run(ai_case, attestation)
    assert failed.status_code == 201, failed.text
    assert failed.json()['status'] == 'failed'
    assert failed.json()['result']['error_code'] == 'AI_TIMEOUT'
    assert failed.json()['financially_final'] is False
    monkeypatch.setattr(provider, 'generate', original)
    retry = create_run(ai_case, attestation)
    assert retry.status_code == 201, retry.text
    assert retry.json()['id'] != failed.json()['id']
    first = ai_case.api.client.get(ai_case.base + '/runs/' + failed.json()['id'],
        headers=ai_case.api.headers['root'])
    assert first.status_code == 200 and first.json()['status'] == 'failed'


def test_ambiguous_versions_request_source_review_without_inference(ai_case):
    previous = created_attestation(ai_case)
    text = ('SUPERSEDED DRAFT: LAB-A ONE test was completed. '
            'FINAL record corrects the draft: LAB-A TWO tests were completed.')
    source = ai_case.upload(record_csv(text), 'SYN-mixed-versions.csv')
    ai_case.register_manifest()
    payload = deepcopy(ai_case.payload); payload['service_record'] = selection(source)
    # A narrowly selected clause cannot hide the enclosing source's version
    # ambiguity from the independent readiness gate.
    quote = 'LAB-A ONE test was completed.'
    payload['service_record']['start'] = source.text.index(quote)
    payload['service_record']['end'] = payload['service_record']['start'] + len(quote)
    payload['expected_previous_id'] = previous['id']
    attestation = created_attestation(ai_case, payload)
    response = create_run(ai_case, attestation)
    assert response.status_code == 201, response.text
    result = response.json()
    assert result['status'] == 'review_required'
    assert result['result']['assessment'] == 'source_review_required'
    assert result['result']['source_review_required'] is True
    assert result['result']['review_required'] is True
    assert result['result']['actual_model_calls'] == 0
    assert result['financially_final'] is False
    assert not ai_case.provider_calls


def test_revoked_permission_during_inference_cannot_disclose_result(ai_case, monkeypatch):
    api = ai_case.api
    codes = ['claims.read', 'claims.review', 'ingestion.read', 'medical_fields.text.read']
    assert grants(api, codes, user='admin').status_code == 200
    attestation = created_attestation(ai_case)
    original = provider.generate
    def revoke_then_return(system, payload):
        response = original(system, payload)
        revoked = grants(api, [], user='admin')
        assert revoked.status_code == 200, revoked.text
        return response
    monkeypatch.setattr(provider, 'generate', revoke_then_return)
    response = create_run(ai_case, attestation, api.headers['admin'])
    assert response.status_code == 403, response.text
    assert api.client.get(ai_case.base + '/runs', headers=api.headers['admin']).status_code == 403
    assert len(ai_case.provider_calls) == 1
    history = api.client.get(ai_case.base + '/runs', headers=api.headers['root'])
    assert history.status_code == 200 and history.json()['items'][0]['status'] == 'blocked'
    saved = api.client.get(ai_case.base + '/runs/' + history.json()['items'][0]['id'], headers=api.headers['root'])
    assert saved.status_code == 200
    assert saved.json()['result']['findings'] == []
    assert saved.json()['result']['error_code'] == 'ai_authorization_changed'


def test_invoice_number_cannot_substitute_for_labelled_quantity(ai_case):
    quote = 'INVOICE_NUMBER: 2; SERVICE_CODE: LAB-A; UNIT: test; QUANTITY: 20'
    output = BytesIO(); pdf = canvas.Canvas(output, invariant=1)
    pdf.drawString(30, 760, quote); pdf.save()
    source = ai_case.upload(output.getvalue(), 'SYN-unrelated-invoice-number.pdf', 'invoice')
    ai_case.register_manifest()
    payload = deepcopy(ai_case.payload); payload['invoice'] = selection(source)
    response = ai_case.attest(payload)
    assert response.status_code == 409, response.text
    assert not ai_case.provider_calls


def test_same_facts_in_a_new_attestation_do_not_reuse_an_old_bound_run(ai_case):
    first = created_attestation(ai_case)
    old_run = create_run(ai_case, first)
    assert old_run.status_code == 201, old_run.text
    payload = deepcopy(ai_case.payload); payload['expected_previous_id'] = first['id']
    payload['reason'] = 'SYN new operator confirmation of unchanged original source facts'
    second = created_attestation(ai_case, payload)
    new_run = create_run(ai_case, second)
    assert new_run.status_code == 201, new_run.text
    assert new_run.json()['id'] != old_run.json()['id']
    assert new_run.json()['attestation_id'] == second['id']
    assert len(ai_case.provider_calls) == 2
    history = ai_case.api.client.get(ai_case.base + '/runs/' + old_run.json()['id'], headers=ai_case.api.headers['root'])
    assert history.status_code == 200 and history.json()['stale'] is True


def test_revoked_source_registration_marks_history_stale_without_rewriting_it(ai_case):
    attestation = created_attestation(ai_case)
    run = create_run(ai_case, attestation)
    assert run.status_code == 201, run.text
    manifest = json.loads(ai_case.source_manifest_path.read_text())
    manifest['organizations'][ai_case.api.organization_id]['source_sha256'] = []
    ai_case.source_manifest_path.write_text(json.dumps(manifest))
    history = ai_case.api.client.get(ai_case.base + '/runs/' + run.json()['id'], headers=ai_case.api.headers['root'])
    assert history.status_code == 200 and history.json()['stale'] is True
    assert history.json()['financially_final'] is False
    blocked = create_run(ai_case, attestation)
    assert blocked.status_code == 409 and len(ai_case.provider_calls) == 1
