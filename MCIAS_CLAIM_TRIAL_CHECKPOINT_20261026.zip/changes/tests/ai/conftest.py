"""Synthetic A1 API fixtures with real source ingestion and authorization.

Only the model provider is replaced in ordinary API tests. These tests do not
claim real-model accuracy or bypass source parsing/provenance verification.
"""
from copy import deepcopy
import csv
from hashlib import sha256
from io import BytesIO, StringIO
import json
from types import SimpleNamespace

from openpyxl import Workbook
import pytest
from reportlab.pdfgen import canvas
from sqlalchemy import select
from sqlalchemy.orm import Session

from tests.api.conftest import api_factory, synthetic_password_hash  # noqa: F401
from tests.features.conftest import features_api  # noqa: F401
from tests.workspace_v2.test_access_and_registry import workspace  # noqa: F401
from tests.workspace_v2.test_mapping_and_results import mapping, upload_batch
from mcias.models import Permission
from mcias.models_claims import ClaimEntry
from mcias.models_ingestion import ExtractedSourceRecord, IngestionDocument, IngestionJob


SERVICE_TEXT = 'تم إجراء 1 فحص من الخدمة LAB-A للمستفيد الاصطناعي بتاريخ الخدمة.'
INVOICE_QUOTE = 'SERVICE_CODE: LAB-A; UNIT: test; QUANTITY: 2'


def claim_workbook():
    book = Workbook()
    sheet = book.active
    sheet.title = 'مطالبات اصطناعية للربط'
    sheet.append(['رقم الفاتورة', 'الرقم التأميني', 'مقدم الخدمة', 'الخدمة',
                  'تاريخ الخدمة', 'المطلوب', 'إجمالي التحمل', 'الصافي'])
    for index in (1, 2):
        sheet.append([f'SYN-AI-INVOICE-{index}', f'SYN-AI-BENEFICIARY-{index}',
                      'SYN-AI-PROVIDER', 'LAB-A', '01/10/2026', '200', '0', '200'])
    output = BytesIO()
    book.save(output)
    return output.getvalue()


def itemized_invoice(quote=INVOICE_QUOTE, reference='SYN-AI-INVOICE-1'):
    output = BytesIO()
    pdf = canvas.Canvas(output, invariant=1)
    pdf.setFont('Helvetica', 11)
    for index, text in enumerate((
        'SYNTHETIC INVOICE - NOT A REAL MEDICAL INVOICE',
        'INVOICE_REFERENCE: ' + reference,
        quote,
        'LINE_TOTAL: 200.00; CURRENCY: USD',
    )):
        pdf.drawString(30, 790 - index * 24, text)
    pdf.save()
    return output.getvalue()


def service_record(text=SERVICE_TEXT):
    output = StringIO(newline='')
    writer = csv.writer(output)
    writer.writerow(['text'])
    writer.writerow([text])
    return output.getvalue().encode('utf-8')


@pytest.fixture
def ai_case(workspace, monkeypatch, tmp_path):
    api = workspace
    monkeypatch.setenv('MCIAS_ENVIRONMENT', 'development')
    monkeypatch.setenv('MCIAS_LAPTOP_TEST_MODE', 'synthetic_localhost')
    # This is the existing tenant field guard's dynamic code, populated only in
    # this isolated DB. No production permission catalog or grants are changed.
    with Session(api.engine) as db:
        if db.scalar(select(Permission.id).where(Permission.code == 'medical_fields.text.read')) is None:
            db.add(Permission(code='medical_fields.text.read'))
            db.commit()

    raw = claim_workbook()
    batch_id, document_id = upload_batch(api, raw, 'SYN-AI-claims.xlsx')
    body = mapping()
    body['currency'] = 'USD'
    path = '/api/v1/claims/batches/' + batch_id
    response = api.client.put(path + '/mapping', json=body, headers=api.headers['root'])
    assert response.status_code == 200, response.text
    response = api.client.post(path + '/resume', headers=api.headers['root'])
    assert response.status_code == 200 and response.json()['imported_count'] == 2, response.text
    with Session(api.engine) as db:
        claims = list(db.scalars(select(ClaimEntry).where(ClaimEntry.batch_id == batch_id)
                                .order_by(ClaimEntry.claim_reference)))
    claim_id, other_claim_id = (row.id for row in claims)
    case = SimpleNamespace(api=api, claim_id=claim_id, other_claim_id=other_claim_id,
                           batch_id=batch_id, claim_document_id=document_id, claim_raw=raw,
                           source_documents={document_id: raw}, provider_calls=[])
    case.base = f'/api/v1/claims/entries/{claim_id}/ai-review'

    def upload(content, filename, kind='supporting', claim_id=None):
        uploaded = api.client.post('/api/v1/ingestion/uploads?filename=' + filename,
            content=content, headers={**api.headers['root'], 'Content-Type': 'application/octet-stream'})
        assert uploaded.status_code == 200, uploaded.text
        document = uploaded.json()['document_id']
        assert uploaded.json()['status'] in ('extracted', 'duplicate'), uploaded.text
        linked = api.client.post(f'/api/v1/claims/entries/{claim_id or case.claim_id}/attachments/{document}?kind={kind}',
                                headers=api.headers['root'])
        assert linked.status_code == 201, linked.text
        with Session(api.engine) as db:
            records = list(db.scalars(select(ExtractedSourceRecord).join(IngestionJob,
                IngestionJob.id == ExtractedSourceRecord.job_id).where(IngestionJob.document_id == document)))
            assert len(records) == 1
            record = records[0]
            text = record.values['text']
            record_id = record.id
        case.source_documents[document] = content
        return SimpleNamespace(document_id=document, attachment_id=linked.json()['id'],
                               record_id=record_id, text=text, raw=content)

    case.upload = upload
    invoice = upload(itemized_invoice(), 'SYN-AI-itemized-invoice.pdf', 'invoice')
    medical = upload(service_record(), 'SYN-AI-service-record.csv')
    case.invoice_document_id, case.service_document_id = invoice.document_id, medical.document_id
    case.invoice_attachment_id, case.service_attachment_id = invoice.attachment_id, medical.attachment_id
    case.invoice_record_id, case.service_record_id = invoice.record_id, medical.record_id
    case.invoice_text, case.service_text = invoice.text, medical.text
    start = invoice.text.index(INVOICE_QUOTE)
    case.payload = {
        'invoice': {'attachment_id': invoice.attachment_id, 'record_id': invoice.record_id,
                    'field': 'text', 'start': start, 'end': start + len(INVOICE_QUOTE)},
        'service_record': {'attachment_id': medical.attachment_id, 'record_id': medical.record_id,
                           'field': 'text', 'start': 0, 'end': len(medical.text)},
        'service_code': 'LAB-A', 'unit': 'test', 'billed_quantity': '2',
        'reason': 'SYN-private-evidence-reason-operator-checked-original',
        'expected_previous_id': None,
    }

    case.source_manifest_path = tmp_path / 'a1-synthetic-source-manifest.json'
    def register_manifest():
        hashes = []
        with Session(api.engine) as db:
            for identity in case.source_documents:
                hashes.append(db.get(IngestionDocument, identity).sha256)
        manifest = {'schema': 'mcias-a1-synthetic-sources-v1',
                    'organizations': {api.organization_id: {'source_sha256': sorted(set(hashes))}}}
        case.source_manifest_path.write_text(json.dumps(manifest))
        case.source_manifest_path.chmod(0o600)
    case.register_manifest = register_manifest
    register_manifest()
    monkeypatch.setenv('MCIAS_AI_SYNTHETIC_MANIFEST', str(case.source_manifest_path.resolve()))

    def provider(system, payload):
        case.provider_calls.append({'system': system, 'payload': payload})
        request = json.loads(payload)
        line = request['invoice_lines'][0]
        source = request['source_texts'][0]
        answer = {'signals': [{'line_item_id': line['line_item_id'], 'source_id': source['source_id'],
            'exact_quote': source['text'].strip(), 'reported_quantity': '1',
            'explanation': 'SYN contract-test provider: source quantity differs from billed quantity.'}]}
        return {'raw_text': json.dumps(answer, ensure_ascii=False),
                'provider_metadata': {'provider': 'SYN-CONTRACT-TEST-DOUBLE-NOT-REAL-INFERENCE',
                    'model_id': 'SYN-contract-test-model', 'weights_sha256': '0' * 64,
                    'system_prompt_sha256': sha256(system.encode()).hexdigest(),
                    'payload_sha256': sha256(payload.encode()).hexdigest(),
                    'elapsed_seconds': 0.001, 'usage': {'prompt_tokens': 1, 'completion_tokens': 1}},
                'private_evidence': {'system_prompt': system, 'payload': payload}}
    from mcias.services import local_ai_provider
    case.provider_stub = provider
    monkeypatch.setattr(local_ai_provider, 'generate', provider)

    def attest(payload=None, headers=None):
        return api.client.post(case.base + '/attestations', json=deepcopy(payload or case.payload),
                               headers=headers or api.headers['root'])
    def run(attestation=None, headers=None):
        if attestation is None:
            response = attest()
            assert response.status_code == 201, response.text
            attestation = response.json()
        return api.client.post(case.base + '/runs', json={
            'attestation_id': attestation['id'], 'expected_fingerprint': attestation['fingerprint']},
            headers=headers or api.headers['root'])
    case.attest, case.run = attest, run
    return case
