"""A literal identifier is not evidence of a performed service count."""
import json

import pytest

from mcias.services.ai_invoice_reader import _model_review


def review(quote, *, code="SYN-1", reported="1", billed="2"):
    reference = {"document_id": "record", "sha256": "a" * 64, "locator": "row:2"}
    bundle = {"tenant_id": "synthetic-org", "invoice": {"items": [
        {"id": "L1", "kind": "service", "code": code, "quantity": billed,
         "unit": "session", "source": {**reference, "document_id": "invoice"}}
    ]}, "documents": [{"tenant_id": "synthetic-org", "kind": "service_record",
        "attested": True, "source": reference, "text": quote}]}

    def model(_instruction, _payload):
        return json.dumps({"signals": [{"line_item_id": "L1", "source_id": "record",
            "exact_quote": quote, "reported_quantity": reported,
            "explanation": "Synthetic test of a reported quantity contradiction."}]})

    return _model_review(bundle, model, {"record": reference})


@pytest.mark.parametrize("quote", [
    "SYN-1 completed two sessions.",
    "SYN-1 completed two sessions on 2026-10-01; visit REF/1.",
    "SYN-1 completed two sessions; identifier 1/2026, value 1.50.",
    "SYN-1 completed two sessions under reference SYN-11 today.",
])
def test_identifier_or_date_cannot_validate_a_false_quantity(quote):
    findings, status, rejected = review(quote)
    assert findings == []
    assert status == "INFERRED_VALIDATED" and rejected == 1


@pytest.mark.parametrize("quote", [
    "SYN-1 completed one session today.",
    "SYN-1 completed 1 session today.",
    "تم إجراء SYN-1 بكمية 1 جلسة اليوم.",
])
def test_an_independent_explicit_count_still_supports_advisory_review(quote):
    findings, status, rejected = review(quote)
    assert status == "INFERRED_VALIDATED" and rejected == 0
    assert len(findings) == 1
    assert findings[0]["source_reported_quantity"] == "1"
    assert findings[0]["billed_quantity"] == "2"
    assert findings[0]["finding_status"] == "REVIEW"
    assert "suspected_amount" not in findings[0]
