"""Bounded native-text invoice candidates, adapted from PR #39 (f8e3acdc).

Reuse: source anchors and word-to-line grouping from the isolated document reader
pilot.  This adapter deliberately supports only the labelled format already used
by ``mcias.seed.synthetic_invoices.invoice_pdf`` (one invoice per page), plus
explicit ``quantity`` and ``unit_price`` labels.  It is not an OCR engine or a
general medical invoice parser.  Native PDF coordinates are points, not pixels.
Candidates remain unverified and cannot authorize financial actions.
"""
from __future__ import annotations

import re


REQUIRED_FIELDS = (
    "invoice_reference", "provider", "service", "service_date",
    "gross", "copay", "net", "currency",
)
OPTIONAL_FIELDS = ("beneficiary", "beneficiary_name", "quantity", "unit_price")
SUPPORTED_FIELDS = frozenset(REQUIRED_FIELDS + OPTIONAL_FIELDS)


def _lines(words):
    """Preserve PDF text-line identities rather than merging neighbouring columns."""
    grouped = {}
    for word in words:
        identity = (word["block"], word["line"])
        grouped.setdefault(identity, []).append(word)
    lines = list(grouped.values())
    for line in lines:
        line.sort(key=lambda word: (word["bbox"][0], word["word"]))
    return sorted(lines, key=lambda line: (min(w["bbox"][1] for w in line),
                                           min(w["bbox"][0] for w in line)))


def _anchor(words, label_words, document_id, sha256, page):
    box = [min(w["bbox"][0] for w in words), min(w["bbox"][1] for w in words),
           max(w["bbox"][2] for w in words), max(w["bbox"][3] for w in words)]
    return {
        "value": " ".join(w["text"] for w in words),
        "page": page,
        "bbox_points": box,
        "quote": " ".join(w["text"] for w in label_words + words),
        "source": {
            "document_id": document_id, "sha256": sha256,
            "locator": "pdf:page:" + str(page) + ":bbox_points:" +
                       ",".join(format(n, ".6f") for n in box),
        },
        "status": "UNATTESTED_DOCUMENT_CANDIDATE",
    }


def detect_candidates(words, document_id: str, sha256: str, page: int = 1):
    """Extract explicit, full-line labels; absent or repeated facts stay unresolved.

    Identifiers, dates, and money are not inferred here. Semantic comparison and
    Decimal validation belong to the caller. Unknown text, including commands,
    never supplies a field. No label aliases or language transformations are
    guessed without a separately approved document mapping.
    """
    found = {}
    issues = []
    for line in _lines(words):
        first = line[0]["text"]
        # PDF libraries may emit ``label:`` or ``label`` + ``:`` separately.
        match = re.fullmatch(r"([A-Za-z_]+):", first)
        if match:
            label, start = match.group(1).lower(), 1
        elif (len(line) > 1 and re.fullmatch(r"[A-Za-z_]+", first)
              and line[1]["text"] == ":"):
            label, start = first.lower(), 2
        else:
            continue
        if label not in SUPPORTED_FIELDS:
            continue
        found.setdefault(label, [])
        value_words = line[start:]
        if not value_words:
            issues.append("EMPTY_LABEL_" + label)
            found[label].append(None)
            continue
        if any(re.fullmatch(r"(?:" + "|".join(SUPPORTED_FIELDS) + r"):",
                            word["text"], re.I) for word in value_words):
            issues.append("MULTIPLE_LABELS_ON_LINE")
            found[label].append(None)
            continue
        if sum(len(w["text"]) for w in value_words) > 1000:
            issues.append("FIELD_TEXT_LIMIT_" + label)
            found[label].append(None)
            continue
        found[label].append(_anchor(value_words, line[:start], document_id, sha256, page))
    fields = {}
    for name, choices in found.items():
        if len(choices) != 1:
            issues.append("DUPLICATE_LABEL_" + name)
        elif choices[0] is not None:
            fields[name] = choices[0]
    for name in REQUIRED_FIELDS:
        if name not in fields:
            issues.append("MISSING_FIELD_" + name)
    # Either beneficiary identifier may establish identity in the caller. The
    # invoice number is never a substitute for both missing identifiers.
    if not fields.get("beneficiary") and not fields.get("beneficiary_name"):
        issues.append("MISSING_BENEFICIARY_IDENTITY")
    return {"fields": fields, "issues": sorted(set(issues))}
