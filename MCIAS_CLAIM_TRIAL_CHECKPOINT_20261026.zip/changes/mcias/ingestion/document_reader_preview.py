"""Isolated native-PDF preview reused from PR #39 at f8e3acdc43509c314ff2446cb3a1dd0c8434b6ba.

Retains its bounded child process, authenticated source hashes and positioned
word anchors. This version removes OCR, rendering and subprocess execution;
supports at most ten pages of the existing labelled synthetic invoice format;
and reports native PDF-point coordinates. Scanned, rotated, oversized or
ambiguous pages remain unresolved. It neither modifies G2 extraction records nor
matches claims or makes financial decisions. Authorization and opt-in belong to
the API caller, not this pure parser.
"""
from __future__ import annotations

import hashlib
import math
import multiprocessing as mp
import queue
import re

from mcias.ingestion.document_reader_candidates import detect_candidates


MAX_PDF_SIZE = 20 * 1024 * 1024
MAX_PAGES = 10
MAX_WORDS = 2000
MAX_PAGE_DIMENSION = 14400


class ReaderPreviewUnavailable(ValueError):
    """The supplied original cannot be authenticated or safely previewed."""


def _held(document_id, sha256, issue=None, *, page_count=0):
    return {
        "document_id": document_id, "sha256": sha256,
        "method": "PDF_TEXT_LAYER", "status": "HUMAN_REVIEW",
        "financial_decision": "NOT_AUTHORIZED", "pages": [],
        "issues": [issue] if issue else [], "page_count": page_count,
        "candidate_quality": "LIMITED_LABELLED_TEMPLATE_UNVALIDATED",
    }


def _validate(data, document_id, sha256):
    if not isinstance(data, bytes) or not data or len(data) > MAX_PDF_SIZE:
        raise ReaderPreviewUnavailable("PDF_SIZE_LIMIT_OR_EMPTY")
    if not isinstance(document_id, str) or not document_id or len(document_id) > 250:
        raise ReaderPreviewUnavailable("INVALID_DOCUMENT_ID")
    if (not isinstance(sha256, str) or not re.fullmatch(r"[0-9a-f]{64}", sha256)
            or hashlib.sha256(data).hexdigest() != sha256):
        raise ReaderPreviewUnavailable("SOURCE_SHA256_MISMATCH")
    if not data.startswith(b"%PDF-"):
        raise ReaderPreviewUnavailable("NOT_A_SUPPORTED_PDF")


def preview_pdf(data: bytes, document_id: str, sha256: str):
    """Produce untrusted candidates from text already present in the original PDF.

    Production callers use ``isolated_preview_pdf``. Every page of an accepted
    document is returned, including empty/scanned pages. Over-limit documents
    return their total page count and no partially parsed candidate pages.
    """
    _validate(data, document_id, sha256)
    try:
        import fitz
    except ImportError:
        return _held(document_id, sha256, "PDF_READER_NOT_INSTALLED")
    result = _held(document_id, sha256)
    try:
        with fitz.open(stream=data, filetype="pdf") as document:
            result["page_count"] = len(document)
            # MuPDF may auto-open an encrypted file with an empty user password
            # and then report is_encrypted=False. The trailer still records its
            # encryption dictionary; do not silently treat it as plain input.
            if document.is_encrypted or document.xref_get_key(-1, "Encrypt")[0] != "null":
                result["issues"].append("ENCRYPTED_PDF")
                return result
            if not 1 <= len(document) <= MAX_PAGES:
                result["issues"].append("PDF_PAGE_LIMIT")
                return result
            for index, page in enumerate(document, 1):
                output = {"page": index, "fields": {}, "issues": []}
                result["pages"].append(output)
                width, height = page.rect.width, page.rect.height
                if (not all(math.isfinite(n) for n in (width, height))
                        or min(width, height) <= 0
                        or max(width, height) > MAX_PAGE_DIMENSION):
                    output["issues"].append("INVALID_PAGE_GEOMETRY")
                    continue
                output["page_size_points"] = [width, height]
                if page.rotation:
                    output["issues"].append("UNSUPPORTED_PAGE_ROTATION")
                    continue
                try:
                    native = page.get_text("words")
                except (ValueError, RuntimeError, OSError):
                    output["issues"].append("PAGE_TEXT_EXTRACTION_FAILED")
                    continue
                if len(native) > MAX_WORDS:
                    output["issues"].append("TOO_MANY_PDF_WORDS")
                    continue
                if not native:
                    output["issues"].append("OCR_DEFERRED_NO_TEXT_LAYER")
                    continue
                words = []
                for x0, y0, x1, y1, token, block, line, word in native:
                    box = [float(x0), float(y0), float(x1), float(y1)]
                    if (not all(math.isfinite(n) for n in box)
                            or not (0 <= x0 < x1 <= width + 0.01
                                    and 0 <= y0 < y1 <= height + 0.01)):
                        output["issues"].append("TEXT_BOX_OUTSIDE_PAGE")
                        break
                    if not isinstance(token, str) or not token.strip():
                        continue
                    if len(token) > 1000:
                        output["issues"].append("PDF_TOKEN_LIMIT")
                        break
                    words.append({"text": token, "bbox": box, "block": block,
                                  "line": line, "word": word})
                if output["issues"]:
                    continue
                detected = detect_candidates(words, document_id, sha256, index)
                output.update(detected)
            if any(page["issues"] for page in result["pages"]):
                result["issues"].append("UNRESOLVED_PAGES")
    except (ValueError, RuntimeError, OSError):
        return _held(document_id, sha256, "PDF_PARSE_FAILED")
    return result


def _preview_worker(data, document_id, sha256, output):
    try:
        try:
            import resource
            resource.setrlimit(resource.RLIMIT_AS, (1024 * 1024 * 1024,) * 2)
            resource.setrlimit(resource.RLIMIT_CPU, (25, 26))
        except (ImportError, OSError, ValueError):
            pass
        output.put(preview_pdf(data, document_id, sha256))
    except Exception:
        # Never place raw document contents or parser exceptions in metadata/logs.
        output.put(_held(document_id, sha256, "READER_WORKER_FAILED"))


def isolated_preview_pdf(data: bytes, document_id: str, sha256: str, timeout=30):
    """Keep untrusted PDF parsing out of the request process, as in G2/PR #39."""
    _validate(data, document_id, sha256)
    if isinstance(timeout, bool) or not isinstance(timeout, (int, float)) or not 0 < timeout <= 30:
        raise ReaderPreviewUnavailable("INVALID_READER_TIMEOUT")
    context = mp.get_context("spawn")
    output = context.Queue(maxsize=1)
    worker = context.Process(target=_preview_worker,
                             args=(data, document_id, sha256, output), daemon=True)
    worker.start()
    try:
        try:
            return output.get(timeout=timeout)
        except queue.Empty:
            return _held(document_id, sha256, "READER_WORKER_TIMEOUT")
    finally:
        if worker.is_alive():
            worker.terminate()
        worker.join(timeout=3)
        if worker.is_alive():
            worker.kill()
            worker.join(timeout=3)
        output.close()
