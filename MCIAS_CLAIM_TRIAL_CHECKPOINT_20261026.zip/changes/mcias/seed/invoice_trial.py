"""Explicit localhost trial catalog registration; never a user permission grant.

Keep these sensitive read codes outside the generic RBAC templates: adding them
to a broad ``*.read`` template could grant medical data to ordinary staff.
"""
from sqlalchemy import select

from mcias.models import AuditLog, Permission
from mcias.services.authorization_service import technical_admin


TRIAL_PERMISSIONS = (
    ('medical_fields.text.read', 'قراءة نص مستند المطالبة', 'Read claim document text'),
    ('medical_fields.beneficiary_token.read', 'قراءة الرقم التأميني للمستفيد', 'Read beneficiary insurance identifier'),
    ('medical_fields.beneficiary_name.read', 'قراءة اسم المستفيد', 'Read beneficiary name'),
)


def check_controls(db, env):
    """Check the API container's actual configuration, not a caller's intent."""
    actual = env.get('MCIAS_DOCUMENT_READER_MODE') == 'native_preview'
    codes = {code for code, _, _ in TRIAL_PERMISSIONS}
    available = set(db.scalars(select(Permission.code).where(Permission.code.in_(codes))))
    return [{'control': 'invoice_trial_enabled', 'status': 'PASS' if actual else 'BLOCKED'},
            {'control': 'invoice_trial_field_catalog', 'status': 'PASS' if available == codes else 'BLOCKED'}]


def ensure_catalog(db, actor, env):
    """Register only the opt-in synthetic trial's missing field-read codes.

    The existing laptop setup validates its owner/runtime database identities
    before calling this function. Flush only; the setup owns commit/rollback.
    No memberships, roles, permissions on groups/users, or private files change.
    """
    mode = env.get('MCIAS_DOCUMENT_READER_MODE', 'disabled')
    if mode in ('', 'disabled'):
        return {'enabled': False, 'permissions_created': 0}
    if mode != 'native_preview':
        raise ValueError('Unsupported invoice trial mode')
    from mcias.seed.laptop import guard
    guard(env)
    if not actor or not actor.organization_id or not technical_admin(db, actor):
        raise ValueError('Existing MFA-enabled technical administrator required')
    created = []
    for code, name_ar, name_en in TRIAL_PERMISSIONS:
        if db.scalar(select(Permission.id).where(Permission.code == code)) is None:
            db.add(Permission(code=code, description_ar=name_ar, description_en=name_en,
                              category='medical_fields', is_system=True))
            created.append(code)
    if created:
        db.flush()
        db.add(AuditLog(actor_id=actor.id, organization_id=actor.organization_id,
            action='synthetic_invoice_trial.catalog', resource_type='permission_catalog',
            category='configuration', details={'synthetic': True, 'mode': 'native_preview',
                'registered_codes': created, 'user_grants_created': 0}))
        db.flush()
    return {'enabled': True, 'permissions_created': len(created)}
