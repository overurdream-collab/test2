"""Generate one source-consistent synthetic claim and native-text invoice.

Reuses the existing linked-reference workbook and its numerical fixture. No
database is opened, policy approved, role granted, or OCR/model called. Files
are written only when the operator explicitly invokes this module's CLI.
"""
from __future__ import annotations

import argparse
from datetime import date, datetime
from hashlib import sha256
from io import BytesIO
import json
import os
from pathlib import Path

from openpyxl import load_workbook
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas

from mcias.seed.linked_references import sample_workbook


CLAIMS_FILE = 'SYN-claim-trial.xlsx'
INVOICE_FILE = 'SYN-claim-trial-invoice.pdf'


def _invoice(facts):
    """The existing fixture layout with quantity and unit price made explicit."""
    output = BytesIO()
    pdf = canvas.Canvas(output, pagesize=A4, invariant=1)
    pdf.setFont('Helvetica-Bold', 16)
    pdf.drawString(35, 800, 'SYNTHETIC INVOICE - NOT A REAL INVOICE')
    pdf.setFont('Helvetica', 11)
    for number, (label, value) in enumerate(facts.items()):
        pdf.drawString(35, 760 - number * 24, f'{label}: {value}')
    pdf.drawString(35, 440, 'Test only. No payment, signature or institutional approval.')
    pdf.save()
    return output.getvalue()


def files(at: date | None = None) -> dict[str, bytes]:
    """Return a workbook, its invoice, explicit mapping and Arabic instructions.

    Money comes from the first existing linked synthetic case, rather than a
    new financial policy. The insurance ID identifies the same seeded employee;
    this invoice intentionally does not assert a separately extracted name.
    """
    at = at or date.today()
    book = load_workbook(BytesIO(sample_workbook(at)))
    sheet = book.active
    if sheet.max_row < 2:
        raise ValueError('Existing synthetic workbook has no claim')
    if sheet.max_row > 2:
        sheet.delete_rows(3, sheet.max_row - 2)
    columns = {cell.value: cell.column for cell in sheet[1]}
    required = ('رقم الفاتورة', 'الرقم التأميني', 'اسم المستفيد', 'الدرجة', 'مقدم الخدمة',
                'الخدمة', 'تاريخ الخدمة', 'السعر', 'المطلوب', 'نسبة التحمل', 'إجمالي التحمل', 'الصافي')
    if not set(required) <= columns.keys():
        raise ValueError('Existing synthetic workbook mapping changed')
    # These canonical identifiers already exist in seed_linked_references.
    # Keeping both sources ASCII here avoids pretending that Arabic PDF layout
    # or OCR has been validated by this first native-text fixture.
    sheet.cell(2, columns['مقدم الخدمة'], 'SYN-LINKED-HOSPITAL')
    sheet.cell(2, columns['الخدمة'], 'SYN-VISIT')
    quantity_column = sheet.max_column + 1
    sheet.cell(1, quantity_column, 'الكمية')
    sheet.cell(2, quantity_column, '1')
    output = BytesIO()
    book.save(output)
    row = {name: str(sheet.cell(2, index).value) for name, index in columns.items()}
    facts = {
        'invoice_reference': row['رقم الفاتورة'], 'beneficiary': row['الرقم التأميني'],
        'provider': row['مقدم الخدمة'], 'service': row['الخدمة'],
        'service_date': datetime.strptime(row['تاريخ الخدمة'], '%d/%m/%Y').date().isoformat(),
        'gross': row['المطلوب'], 'copay': row['إجمالي التحمل'], 'net': row['الصافي'],
        'currency': 'LYD', 'quantity': '1', 'unit_price': row['السعر'],
    }
    mapping = {'columns': {
        'claim_reference': 'رقم الفاتورة', 'beneficiary_token': 'الرقم التأميني',
        'provider_code': 'مقدم الخدمة', 'service_code': 'الخدمة', 'service_date': 'تاريخ الخدمة',
        'claimed_amount': 'الصافي', 'beneficiary_name': 'اسم المستفيد', 'category_code': 'الدرجة',
        'gross_amount': 'المطلوب', 'unit_price': 'السعر', 'copay_amount': 'إجمالي التحمل',
        'copay_percent': 'نسبة التحمل', 'quantity': 'الكمية'},
        'currency': 'LYD', 'date_format': 'DMY'}
    readme = '''# تجربة مطالبة واحدة — بيانات اصطناعية

تتوافق هذه العينة مع المدخلات الاصطناعية المرتبطة الموجودة في إعداد اللابتوب.
المستفيد من الفئة B؛ الخدمة زيارة طبيب داخل الشبكة: 1000 قبل التحمل، 100 تحمل، و900 صافي.
هذه أرقام العينة المرجعية الموجودة، وليست سياسة مالية مؤسسية جديدة أو إثبات دفع.

1. شغّل المشروع الحالي بالخيار `-Action Start -InvoiceTrial` وسجّل الدخول بالسوبر أدمن الاصطناعي.
2. افتح التدقيق والمراجعة وارفع `SYN-claim-trial.xlsx`.
3. أكد ربط الأعمدة: الصافي هو مبلغ المطالبة، والعملة LYD، والتاريخ DD/MM/YYYY.
   يوضح `mapping.json` الربط الكامل، بما فيه الاسم والفئة والكمية والسعر والتحمل.
4. استكمل استيراد البند الوحيد.
5. أضف `SYN-claim-trial-invoice.pdf` بوصفه فاتورة واربطه بالبند نفسه.
6. ابدأ التدقيق، وافتح الفحوص والأسباب، ثم نزّل المخرجين.

الفاتورة نصية، وهوية المستفيد فيها مثبتة بالرقم التأميني المطابق لـExcel والمدخلات.
وجود الاسم العربي في Excel مع غيابه من هذه الفاتورة مقصود لاختبار المطابقة بأحد المعرّفين.
الكمية 1 وسعر الوحدة 1000 مكتوبان صراحةً في المصدرين؛ لا يُستنتجان من الصافي.

في التثبيت المحلي الافتراضي لا توجد سياسة مالية مؤسسية موقعة لهذه المطالبة؛ لذلك قد تظهر
ضمن `يحتاج إجراء` بسبب غياب السياسة، مع استمرار فحوص المدخلات ومطابقة المستند.
القبول المبدئي يتطلب اكتمال الفحوص وسياسة معتمدة بالطريقة القائمة. لا تنشئ هذه الملفات
توقيعًا أو اعتمادًا أو صلاحية مالية. يبقى القرار النهائي بشريًا وفق صلاحيات النظام.

كل بند يظهر مرة واحدة في `accepted.xlsx` أو `needs_action.xlsx`، مع بقاء ملف Excel الأصلي
دون تعديل. تجربة النقص: ارفع المطالبة نفسها في بيئة اختبار جديدة دون ربط PDF؛ يجب أن تُظهر
فحوص السعر والتحمل المتاحة وأن تذكر نقص المرفقات ضمن الإجراءات المطلوبة.

هذه العينة لا تختبر OCR أو الفواتير المصوّرة أو دقة سريرية أو اعتمادًا إنتاجيًا.
'''
    return {CLAIMS_FILE: output.getvalue(), INVOICE_FILE: _invoice(facts),
            'mapping.json': (json.dumps(mapping, ensure_ascii=False, indent=2) + '\n').encode('utf-8'),
            'README_AR.md': readme.encode('utf-8')}


def write_files(output: Path, data: dict[str, bytes]) -> list[Path]:
    """Write new sample files only; do not overwrite or follow symbolic paths."""
    output = output.absolute()
    if '..' in output.parts:
        raise ValueError('Output path must not contain parent traversal')
    for path in (output, *output.parents):
        if path.is_symlink():
            raise ValueError('Output path must not contain symbolic links')
    if output.exists() and not output.is_dir():
        raise ValueError('Output must be a directory')
    for name in data:
        if Path(name).name != name or name in ('.', '..'):
            raise ValueError('Sample filename must be a plain name')
        target = output / name
        if target.exists() or target.is_symlink():
            raise FileExistsError('Refusing to overwrite a sample file: ' + name)
    output.mkdir(parents=True, exist_ok=True)
    written = []
    for name, value in data.items():
        descriptor = os.open(output / name, os.O_WRONLY | os.O_CREAT | os.O_EXCL |
                             getattr(os, 'O_NOFOLLOW', 0), 0o600)
        with os.fdopen(descriptor, 'wb') as handle:
            handle.write(value)
        written.append(output / name)
    return written


def main():
    parser = argparse.ArgumentParser(description='Create synthetic one-claim trial files; no database changes')
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    data = files()
    paths = write_files(args.output, data)
    print(json.dumps({'synthetic': True, 'financial_approval_created': False,
        'files': [{'path': str(path), 'sha256': sha256(data[path.name]).hexdigest()} for path in paths]},
        ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
