"""Source-bound native-PDF comparisons in the existing claim workflow.

Candidate evidence only: no reference rules, settlements, A1 attestations or
financial snapshots are created or changed. OCR and fuzzy identity matching are
deliberately absent. Exact labelled invoice fields are a limited first contract.
"""
from datetime import date
from hashlib import sha256
import json
import os

from cryptography.exceptions import InvalidTag
from sqlalchemy import select

from mcias.claim_batches import confirmed_mapping
from mcias.claim_normalization import normalize, source_decimal
from mcias.ingestion.file_scanner import identify
from mcias.ingestion.isolated_parser import isolated_parse
from mcias.ingestion.provenance import locator_dict
from mcias.ingestion.document_reader_preview import isolated_preview_pdf
from mcias.models import AuditLog, SourceFile
from mcias.models_claims import ClaimAttachment, ClaimBatch, ClaimEntry
from mcias.models_ingestion import ExtractedSourceRecord, IngestionDocument, IngestionJob, QuarantineItem
from mcias.services.authorization_service import check_permission_unified
from mcias.services import registry_service as registry
from mcias.services.registry_service import store


PERMISSIONS = ('claims.read', 'claims.review', 'ingestion.read',
               'medical_fields.text.read', 'medical_fields.beneficiary_token.read')
NUMBERS = frozenset(('gross', 'copay', 'net', 'quantity', 'unit_price'))
FIELDS = ('invoice_reference', 'beneficiary', 'provider', 'service',
          'service_date', 'currency', 'gross', 'copay', 'net')
SOURCE_FIELDS = {'invoice_reference': 'claim_reference', 'beneficiary': 'beneficiary_token',
                 'beneficiary_name': 'beneficiary_name',
                 'provider': 'provider_code', 'service': 'service_code',
                 'service_date': 'service_date', 'currency': 'currency',
                 'net': 'claimed_amount', 'gross': 'gross_amount',
                 'copay': 'copay_amount', 'quantity': 'quantity', 'unit_price': 'unit_price'}


class InvoiceMatchConflict(ValueError):
    pass


class InvoiceMatchUnavailable(RuntimeError):
    pass


def _digest(value):
    return sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                             separators=(',', ':'), default=str).encode()).hexdigest()


def claim_for_actor(db, actor, claim_id):
    claim = db.get(ClaimEntry, claim_id)
    if not claim or claim.organization_id != actor.organization_id:
        raise LookupError('Claim not found')
    if not all(check_permission_unified(db, actor, code) for code in PERMISSIONS):
        from fastapi import HTTPException
        raise HTTPException(403, 'permission denied')
    return claim


def authorize_name_access(db, actor, result):
    """An exposed Excel/PDF name needs its own field permission, also on reread."""
    if (result.get('name_fields_exposed')
            and not check_permission_unified(db, actor, 'medical_fields.beneficiary_name.read')):
        from fastapi import HTTPException
        raise HTTPException(403, 'beneficiary name permission denied')


def _original(db, document):
    source = db.get(SourceFile, document.source_id)
    if not source or source.sha256 != document.sha256:
        raise InvoiceMatchConflict('invoice_source_changed')
    try:
        raw = store().get(source.storage_key, source.sha256)
    except (ValueError, OSError, InvalidTag):
        raise InvoiceMatchConflict('invoice_original_unavailable') from None
    if sha256(raw).hexdigest() != source.sha256:
        raise InvoiceMatchConflict('invoice_source_changed')
    return raw


def _parsed(raw, filename):
    try:
        kind = identify(raw, filename)
        if kind not in ('pdf', 'xlsx', 'csv'):
            raise ValueError('unsupported source')
        return isolated_parse(kind, raw)
    except (ValueError, RuntimeError, OSError):
        raise InvoiceMatchConflict('invoice_source_reparse_failed') from None


def _claim_input(db, actor, claim):
    batch = db.get(ClaimBatch, claim.batch_id)
    if not batch or batch.organization_id != actor.organization_id or batch.status != 'imported':
        raise InvoiceMatchConflict('invoice_claim_batch_not_ready')
    document = db.get(IngestionDocument, batch.ingestion_document_id)
    if (not document or document.organization_id != actor.organization_id
            or document.status != 'extracted' or document.sha256 != batch.source_sha256):
        raise InvoiceMatchConflict('invoice_claim_source_changed')
    raw = _original(db, document)
    extracted = _parsed(raw, document.filename)
    if not extracted.complete or extracted.quarantined:
        raise InvoiceMatchConflict('invoice_claim_extraction_incomplete')
    record = db.get(ExtractedSourceRecord, claim.extracted_record_id)
    job = db.get(IngestionJob, record.job_id) if record else None
    if (not record or not job or job.document_id != document.id
            or job.organization_id != actor.organization_id or job.status != 'extracted'
            or record.locator != claim.source_locator or record.values != claim.source_values
            or record.confidence != 100):
        raise InvoiceMatchConflict('invoice_claim_record_changed')
    matches = [r for r in extracted.records if locator_dict(r.locator) == record.locator]
    if len(matches) != 1 or matches[0].values != record.values or matches[0].confidence != 1:
        raise InvoiceMatchConflict('invoice_claim_record_changed')
    mapping = confirmed_mapping(db, batch)
    try:
        normalized = normalize(record.values, mapping)
    except ValueError:
        raise InvoiceMatchConflict('invoice_claim_mapping_invalid') from None
    if any(normalized[key] != getattr(claim, key) for key in normalized):
        raise InvoiceMatchConflict('invoice_claim_normalized_values_changed')
    columns = mapping['columns'] if mapping else {key: key for key in normalized}
    values = {'invoice_reference': claim.claim_reference, 'beneficiary': claim.beneficiary_token,
              'provider': claim.provider_code, 'service': claim.service_code,
              'service_date': claim.service_date.isoformat(), 'currency': claim.currency,
              'net': str(claim.claimed_amount)}
    for key in ('gross', 'copay', 'quantity', 'unit_price', 'beneficiary_name'):
        column = columns.get(SOURCE_FIELDS[key])
        values[key] = record.values.get(column) if column else None
    return values, columns, {'document_id': document.id, 'sha256': document.sha256,
                            'locator': claim.source_locator}, mapping


def _links(db, actor, claim):
    links = list(db.scalars(select(ClaimAttachment).where(
        ClaimAttachment.claim_id == claim.id,
        ClaimAttachment.organization_id == actor.organization_id).order_by(ClaimAttachment.id).limit(21)))
    if len(links) > 20:
        raise InvoiceMatchConflict('invoice_attachment_limit')
    selected = []
    for link in links:
        event = db.scalar(select(AuditLog).where(AuditLog.organization_id == actor.organization_id,
            AuditLog.action == 'claim_invoice.linked', AuditLog.resource_id == link.id))
        if not event:
            continue
        document = db.get(IngestionDocument, link.ingestion_document_id)
        if (not document or document.organization_id != actor.organization_id
                or document.sha256 != link.document_sha256
                or event.details.get('claim_id') != claim.id
                or event.details.get('document_id') != document.id
                or event.details.get('sha256') != document.sha256):
            raise InvoiceMatchConflict('invoice_attachment_changed')
        if document.id == db.get(ClaimBatch, claim.batch_id).ingestion_document_id:
            raise InvoiceMatchConflict('invoice_cannot_be_claim_source')
        selected.append((link, document))
    if len(selected) > 5:
        raise InvoiceMatchConflict('invoice_document_limit')
    return selected


def _verify_pdf_records(db, actor, document, raw):
    job = db.scalar(select(IngestionJob).where(IngestionJob.document_id == document.id,
        IngestionJob.organization_id == actor.organization_id).order_by(
        IngestionJob.created_at.desc(), IngestionJob.id.desc()).limit(1))
    if (not job or job.status != 'extracted' or not job.manifest.get('complete')
            or db.scalar(select(QuarantineItem.id).where(QuarantineItem.job_id == job.id))):
        raise InvoiceMatchConflict('invoice_extraction_not_ready')
    extracted = _parsed(raw, document.filename)
    records = list(db.scalars(select(ExtractedSourceRecord).where(ExtractedSourceRecord.job_id == job.id)))
    actual = {json.dumps(locator_dict(row.locator), sort_keys=True): row for row in extracted.records}
    if (not extracted.complete or extracted.quarantined or len(records) != len(actual)
            or {json.dumps(row.locator, sort_keys=True) for row in records} != set(actual)
            or any(record.confidence != 100
                   or json.dumps(record.locator, sort_keys=True) not in actual
                   or record.values != actual[json.dumps(record.locator, sort_keys=True)].values
                   or actual[json.dumps(record.locator, sort_keys=True)].confidence != 1 for record in records)):
        raise InvoiceMatchConflict('invoice_extracted_record_changed')


def _canonical(field, value):
    if value is None or not str(value).strip():
        return None
    raw = str(value).strip()
    if field in NUMBERS:
        number = source_decimal(raw)
        if field == 'quantity' and number <= 0:
            raise ValueError('Quantity must be positive')
        return number
    if field == 'service_date':
        if date.fromisoformat(raw).isoformat() != raw:
            raise ValueError('Noncanonical date')
    if field == 'currency' and (len(raw) != 3 or not raw.isascii() or not raw.isupper() or not raw.isalpha()):
        raise ValueError('Invalid currency')
    if field == 'beneficiary_name':
        return _name(raw)
    # No fuzzy names, case folding, dropped punctuation, or numeric ID casts.
    return raw


def _compare(values, columns, locator, fields):
    comparisons = []
    extra = [key for key in ('quantity', 'unit_price') if values[key] is not None or key in fields]
    if values.get('beneficiary_name') is not None or 'beneficiary_name' in fields:
        extra.append('beneficiary_name')
    for field in (*FIELDS, *extra):
        anchor = fields.get(field)
        document_value = anchor.get('value') if anchor else None
        source_value = values[field]
        state = 'MATCH'
        try:
            left, right = _canonical(field, source_value), _canonical(field, document_value)
            if left is None or right is None:
                state = 'MISSING'
            elif left != right:
                state = 'DIFFERENT'
        except (ValueError, TypeError):
            state = 'INVALID'
        column = columns.get(SOURCE_FIELDS[field])
        comparisons.append({'field': field, 'claim_value': source_value,
            'document_value': document_value, 'status': state,
            'claim_source': {'column': column, 'locator': locator} if column else None,
            'document_source': anchor})
    return comparisons


def _name(value):
    # Whitespace introduced by PDF words is normalized; letters, punctuation,
    # case and diacritics remain exact. No fuzzy or clinical inference.
    return ' '.join(str(value).split()) if value is not None else None


def _beneficiaries(db, actor, claim):
    return [row for row in registry.effective_records(db, actor, 'beneficiaries.names', claim.service_date)
            if not row.get('parent_id')]


def _identity(values, fields, beneficiaries):
    """Match document identity to the claim; G3 separately validates eligibility.

    Exact insurance ID can link a source to an Excel claim even when the input
    registry is missing, but it does not make that claim eligible. Name-only
    linking requires a unique effective input record for the same insurance ID.
    """
    token = fields.get('beneficiary', {}).get('value')
    document_name = _name(fields.get('beneficiary_name', {}).get('value'))
    claim_name = _name(values.get('beneficiary_name'))
    expected = [row for row in beneficiaries
                if row['values'].get('beneficiary_token') == values['beneficiary']]
    reference_status = 'MATCH' if len(expected) == 1 else ('AMBIGUOUS' if expected else 'MISSING')
    reference = ({key: expected[0].get(key) for key in ('id', 'version', 'event_id', 'source_sha256')}
                 if len(expected) == 1 else None)
    reference_name = _name(expected[0]['title']) if len(expected) == 1 else None
    result = {'status': 'INSUFFICIENT_EVIDENCE', 'basis': None, 'issues': [],
              'reference_status': reference_status, 'reference': reference}
    if not token and not document_name:
        result['issues'].append('BENEFICIARY_IDENTITY_MISSING')
        return result
    conflicts = []
    if token and token != values['beneficiary']:
        conflicts.append('BENEFICIARY_INSURANCE_ID_DIFFERS')
    if document_name and claim_name and document_name != claim_name:
        conflicts.append('BENEFICIARY_NAME_DIFFERS')
    if document_name and reference_name and document_name != reference_name:
        conflicts.append('BENEFICIARY_NAME_REFERENCE_DIFFERS')
    if claim_name and reference_name and claim_name != reference_name:
        conflicts.append('CLAIM_NAME_REFERENCE_DIFFERS')
    if conflicts:
        result.update(status='DIFFERENT', issues=conflicts)
        return result
    if token:
        if len(expected) > 1:
            result['issues'].append('BENEFICIARY_REFERENCE_AMBIGUOUS')
        elif document_name and not (claim_name or reference_name):
            result['issues'].append('BENEFICIARY_NAME_CANNOT_BE_VERIFIED')
        else:
            result.update(status='MATCH', basis='insurance_id_and_name' if document_name else 'insurance_id')
        return result
    if not claim_name:
        result['issues'].append('CLAIM_BENEFICIARY_NAME_MISSING')
        return result
    matching_names = [row for row in beneficiaries if _name(row['title']) == document_name]
    if len(matching_names) > 1:
        result['reference_status'] = 'AMBIGUOUS'
        result['issues'].append('BENEFICIARY_NAME_AMBIGUOUS')
    elif len(expected) != 1 or len(matching_names) != 1:
        result['issues'].append('BENEFICIARY_NAME_REFERENCE_MISSING')
    elif matching_names[0]['values'].get('beneficiary_token') != values['beneficiary']:
        result.update(status='DIFFERENT', issues=['BENEFICIARY_NAME_POINTS_TO_OTHER_INSURANCE_ID'])
    else:
        result.update(status='MATCH', basis='unique_name')
    return result


def current_input_fingerprint(db, actor, claim_id):
    """Validate scope and bind current source/reference state without PDF parsing."""
    claim = claim_for_actor(db, actor, claim_id)
    batch = db.get(ClaimBatch, claim.batch_id)
    if not batch or batch.organization_id != actor.organization_id:
        raise LookupError('Batch not found')
    mapping = confirmed_mapping(db, batch)
    authorize_name_access(db, actor, {
        'name_fields_exposed': bool(mapping and mapping['columns'].get('beneficiary_name'))})
    return _state(db, actor, claim, mapping)


def preview(db, actor, claim_id):
    claim = claim_for_actor(db, actor, claim_id)
    if os.getenv('MCIAS_DOCUMENT_READER_MODE') != 'native_preview':
        raise InvoiceMatchUnavailable('invoice_native_preview_disabled')
    values, columns, claim_source, mapping = _claim_input(db, actor, claim)
    initial = _state(db, actor, claim, mapping)
    documents, candidates, issues = [], [], []
    for link, document in _links(db, actor, claim):
        raw = _original(db, document)
        row = {'attachment_id': link.id, 'document_id': document.id, 'sha256': document.sha256,
               'status': 'HUMAN_REVIEW', 'issues': [], 'pages': []}
        if not document.filename.lower().endswith('.pdf') or not raw.startswith(b'%PDF-'):
            row['issues'] = ['NATIVE_PDF_REQUIRED_OCR_DEFERRED']
        elif document.status != 'extracted':
            row['issues'] = ['G2_EXTRACTION_NOT_READY_OCR_DEFERRED']
        else:
            parsed = isolated_preview_pdf(raw, document.id, document.sha256)
            row.update({key: parsed[key] for key in ('pages', 'issues')})
            if not row['issues'] and all(not page['issues'] for page in row['pages']):
                _verify_pdf_records(db, actor, document, raw)
            for page in row['pages']:
                if page['fields']:
                    candidates.append((document.id, page))
                if page['issues']:
                    issues.append('INVOICE_PAGE_REQUIRES_REVIEW')
        if row['issues']:
            issues.extend(row['issues'])
        documents.append(row)
    name_fields_exposed = (values.get('beneficiary_name') is not None or any(
        'beneficiary_name' in page['fields'] for _, page in candidates))
    authorize_name_access(db, actor, {'name_fields_exposed': name_fields_exposed})
    beneficiaries = _beneficiaries(db, actor, claim)
    comparisons, selected = [], None
    exact = [(document_id, candidate_page) for document_id, candidate_page in candidates
             if candidate_page['fields'].get('invoice_reference', {}).get('value') == values['invoice_reference']
             and candidate_page['fields'].get('service', {}).get('value') == values['service']]
    identity_matches = [(document_id, candidate_page) for document_id, candidate_page in exact
                        if _identity(values, candidate_page['fields'], beneficiaries)['status'] == 'MATCH']
    identity_result = {'status': 'INSUFFICIENT_EVIDENCE', 'basis': None,
                       'issues': ['NO_UNIQUE_INVOICE_LINE'], 'reference_status': 'MISSING', 'reference': None}
    if len(identity_matches) == 1:
        identity, page = identity_matches[0]
        selected = {'document_id': identity, 'page': page['page']}
    elif len(identity_matches) > 1:
        issues.append('AMBIGUOUS_INVOICE_LINE')
    elif len(exact) == 1:
        # Keep all available comparisons visible even if identity is absent or
        # conflicts. Invoice/service numbers alone never establish identity.
        identity, page = exact[0]
        selected = {'document_id': identity, 'page': page['page']}
    elif len(exact) > 1:
        issues.append('AMBIGUOUS_INVOICE_LINE')
    elif len(candidates) == 1:
        identity, page = candidates[0]
        selected = {'document_id': identity, 'page': page['page']}
        issues.append('INVOICE_LINE_IDENTITY_DIFFERS')
    else:
        issues.append('NO_UNIQUE_INVOICE_LINE')
    if selected:
        identity_result = _identity(values, page['fields'], beneficiaries)
        comparisons = _compare(values, columns, claim.source_locator, page['fields'])
        try:
            amounts = [_canonical(key, page['fields'].get(key, {}).get('value'))
                       for key in ('gross', 'copay', 'net')]
            if None in amounts:
                issues.append('INVOICE_ARITHMETIC_UNAVAILABLE')
            elif amounts[0] - amounts[1] != amounts[2]:
                issues.append('INVOICE_ARITHMETIC_DIFFERS')
        except (ValueError, TypeError):
            issues.append('INVOICE_ARITHMETIC_INVALID')
        if 'quantity' in page['fields'] or 'unit_price' in page['fields']:
            try:
                qty = _canonical('quantity', page['fields'].get('quantity', {}).get('value'))
                price = _canonical('unit_price', page['fields'].get('unit_price', {}).get('value'))
                gross = _canonical('gross', page['fields'].get('gross', {}).get('value'))
                if None in (qty, price, gross):
                    issues.append('INVOICE_UNIT_ARITHMETIC_UNAVAILABLE')
                elif qty * price != gross:
                    issues.append('INVOICE_UNIT_ARITHMETIC_DIFFERS')
            except (ValueError, TypeError):
                issues.append('INVOICE_UNIT_ARITHMETIC_INVALID')
    if not documents:
        issues.append('MISSING_INVOICE')
    # One missing alternative identifier is informational when the other has
    # established a unique identity. Missing prices/amounts remain unresolved.
    for compared in comparisons:
        alternative = (identity_result['status'] == 'MATCH'
                       and compared['field'] in ('beneficiary', 'beneficiary_name')
                       and compared['status'] == 'MISSING')
        compared['required'] = not alternative
    states = {row['status'] for row in comparisons if row.get('required', True)}
    checks_complete = bool(selected and identity_result['status'] == 'MATCH'
                           and not ({'INVALID', 'MISSING'} & states) and not issues)
    if ('INVALID' in states or 'MISSING' in states or not selected or issues
            or identity_result['status'] == 'INSUFFICIENT_EVIDENCE'):
        status = 'INSUFFICIENT_EVIDENCE'
    else:
        status = ('DIFFERENT' if 'DIFFERENT' in states or identity_result['status'] == 'DIFFERENT'
                  else 'CONSISTENT_FIELDS')
    issues.extend(identity_result['issues'])
    # Recheck source/record state after bounded parsing; concurrent changes cannot
    # turn a candidate computed with old inputs into a current result.
    db.expire_all()
    current = claim_for_actor(db, actor, claim_id)
    if _state(db, actor, current, confirmed_mapping(db, db.get(ClaimBatch, current.batch_id))) != initial:
        raise InvoiceMatchConflict('invoice_inputs_changed_during_preview')
    result = {'claim_id': claim_id, 'status': status, 'review_required': True,
              'financially_final': False, 'financial_effect': 'NONE',
              'issues': sorted(set(issues)), 'claim_source': claim_source,
              'documents': documents, 'selected_candidate': selected, 'comparisons': comparisons,
              'identity': identity_result, 'checks_complete': checks_complete,
              'input_fingerprint': initial, 'name_fields_exposed': name_fields_exposed,
              'scope': 'labelled_native_pdf_candidate_comparison',
              'limitations': ['OCR_NOT_PERFORMED', 'UNVALIDATED_FOR_REAL_INVOICES',
                              'NO_RULE_OR_FINANCIAL_APPROVAL', 'ABSENT_QUANTITY_NOT_INFERRED']}
    return result


def _state(db, actor, claim, mapping):
    batch = db.get(ClaimBatch, claim.batch_id)
    document = db.get(IngestionDocument, batch.ingestion_document_id)
    originals = [(document.id, document.sha256, sha256(_original(db, document)).hexdigest())]
    links = _links(db, actor, claim)
    docs = [document] + [doc for _, doc in links]
    originals.extend((doc.id, doc.sha256, sha256(_original(db, doc)).hexdigest()) for _, doc in links)
    jobs = list(db.scalars(select(IngestionJob).where(
        IngestionJob.document_id.in_([doc.id for doc in docs])).order_by(IngestionJob.id)))
    job_ids = [job.id for job in jobs]
    quarantine = list(db.scalars(select(QuarantineItem).where(
        QuarantineItem.job_id.in_(job_ids)).order_by(QuarantineItem.id)))
    records = list(db.scalars(select(ExtractedSourceRecord).where(ExtractedSourceRecord.job_id.in_(job_ids))
                              .order_by(ExtractedSourceRecord.id)))
    return _digest({'claim': {key: getattr(claim, key) for key in ('id', 'batch_id', 'extracted_record_id', 'source_locator',
        'source_values', 'claim_reference', 'beneficiary_token', 'provider_code', 'service_code',
        'service_date', 'claimed_amount', 'currency')}, 'mapping': mapping, 'originals': originals,
        'batch': (batch.id, batch.organization_id, batch.ingestion_document_id, batch.status, batch.source_sha256),
        'documents': [(doc.id, doc.organization_id, doc.filename, doc.status, doc.source_id, doc.sha256) for doc in docs],
        'jobs': [(job.id, job.document_id, job.organization_id, job.status, job.manifest) for job in jobs],
        'quarantine': [(row.id, row.job_id, row.reason, row.locator) for row in quarantine],
        'records': [(row.id, row.job_id, row.locator, row.values, row.confidence) for row in records],
        'links': [(link.id, link.document_sha256) for link, _ in links],
        'beneficiary_references': sorted((row['id'], row['version'], row['event_id'], row['source_sha256'])
                                        for row in _beneficiaries(db, actor, claim))})
