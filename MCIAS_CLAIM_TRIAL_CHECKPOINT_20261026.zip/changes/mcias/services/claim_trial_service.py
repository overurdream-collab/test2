"""One bounded trial over existing ingestion, G3, G5, Palermo-2 and exports.

Missing documents/identity become per-line action items. Available reference
checks and other lines continue. This coordinates existing components and never
creates a financial policy, approval, user grant or alternative audit engine.
"""
import json
import os
from hashlib import sha256

from fastapi import HTTPException
from sqlalchemy import select

from mcias.audit_authorization import verify_registered_policy
from mcias.audit_engine import PolicyBlocked
from mcias.models import AuditLog, SourceFile
from mcias.models_audit import AuditSnapshot
from mcias.models_claims import ClaimBatch, ClaimEntry
from mcias.reporting_g7 import canonical
from mcias.services import invoice_matching_service as matching, net_audit_service as net
from mcias.services.authorization_service import check_permission_unified
from mcias.services.claim_reference_service import inspect_line
from mcias.services.invoice_service import invoices
from mcias.services.registry_service import store
from mcias.services.transaction_lock import lock_record


def enabled():
    return (os.getenv('MCIAS_DOCUMENT_READER_MODE') == 'native_preview'
            and os.getenv('MCIAS_ENVIRONMENT', 'development') == 'development'
            and os.getenv('MCIAS_LAPTOP_TEST_MODE') == 'synthetic_localhost')


def _batch(db, actor, identity):
    batch = db.get(ClaimBatch, identity)
    if not batch or batch.organization_id != actor.organization_id:
        raise LookupError('Batch not found')
    if not all(check_permission_unified(db, actor, code) for code in matching.PERMISSIONS):
        raise HTTPException(403, 'permission denied')
    return batch


def _events(actor, batch_id):
    return select(AuditLog).where(AuditLog.organization_id == actor.organization_id,
        AuditLog.action == 'claim_trial.completed', AuditLog.resource_type == 'claim_batch',
        AuditLog.resource_id == batch_id)


def _missing_match(code):
    return {'status': 'INSUFFICIENT_EVIDENCE', 'identity': {'status': 'INSUFFICIENT_EVIDENCE'},
            'checks_complete': False, 'issues': [code], 'comparisons': [], 'documents': [],
            'financially_final': False, 'financial_effect': 'NONE', 'name_fields_exposed': False}


def execute(db, actor, batch_id):
    batch = _batch(db, actor, batch_id)
    if not enabled():
        raise RuntimeError('Explicit synthetic native-document trial mode required')
    if batch.status != 'imported' or batch.imported_count != batch.record_count or batch.record_count > 100:
        raise ValueError('Complete the import; this trial supports at most 100 service lines')
    claims = list(db.scalars(select(ClaimEntry).where(ClaimEntry.batch_id == batch.id,
        ClaimEntry.organization_id == actor.organization_id).order_by(ClaimEntry.id)))
    if len(claims) != batch.record_count:
        raise ValueError('Batch count mismatch')
    context = net.context_for(db, actor, batch)
    rows, gate = [], {}
    for claim in claims:
        # Inspect official inputs even when the attachment is absent or unreadable.
        reference = inspect_line(context.index, claim, context.mapping)
        reasons = [f"reference:{check['code']}:{check.get('reason', check['status'])}"
                   for check in reference['checks'] if check['status'] != 'pass']
        try:
            match = matching.preview(db, actor, claim.id)
        except HTTPException:
            raise
        except (ValueError, RuntimeError, OSError) as error:
            # Missing/untrusted evidence affects this line; it does not make the
            # next line disappear. Never put raw parser/source exceptions in logs.
            code = str(error) if isinstance(error, matching.InvoiceMatchConflict) else 'INVOICE_COMPARISON_UNAVAILABLE'
            match = _missing_match(code)
        reasons.extend('invoice:' + str(code) for code in match.get('issues', []))
        reasons.extend('invoice_difference:' + row['field'] for row in match.get('comparisons', [])
                       if row['status'] in ('DIFFERENT', 'INVALID'))
        valid_match = (match['status'] == 'CONSISTENT_FIELDS' and match.get('checks_complete') is True
                       and match.get('identity', {}).get('status') == 'MATCH')
        if not valid_match:
            gate[claim.id] = 'invoice_evidence_requires_action'
            reasons.append('invoice_identity_or_fields_require_action')
        rows.append({'line_id': claim.id, 'invoice_match': match, 'reference_check': reference,
            'invoice_evidence': invoices(db, claim), 'action_reasons': reasons,
            'audited_checks': [{'code': check['code'],
                'status': 'COMPLETED' if check['status'] in ('pass', 'difference') else 'REQUIRES_INPUT',
                'result': check['status'], 'reason': check.get('reason')}
                for check in reference['checks']]})

    try:
        financial = net.execute(db, actor, batch_id, evidence_gate=gate)
        outcomes = {row['line_id']: row for row in financial['rows']}
    except (PolicyBlocked, ValueError):
        # A missing/invalid policy is an action item, never an implicit approval.
        outcomes = {}
    by_id = {claim.id: claim for claim in claims}
    for row in rows:
        outcome = outcomes.get(row['line_id'], {'snapshot_id': None, 'bucket': 'held',
                                               'reason': 'financial_policy_or_evidence_requires_action'})
        row.update(snapshot_id=outcome['snapshot_id'], bucket=outcome['bucket'], reason=outcome['reason'])
        if outcome['bucket'] != 'accepted':
            row['action_reasons'].append(outcome['reason'])
        row['financial_execution'] = {'status': 'COMPLETED' if outcome['snapshot_id'] else 'REQUIRES_ACTION',
            'snapshot_id': outcome['snapshot_id'], 'reason': outcome['reason']}
        row['audited_checks'].append({'code': 'financial_audit',
            'status': row['financial_execution']['status'], 'result': outcome['bucket'], 'reason': outcome['reason']})
        match = row['invoice_match']
        if match.get('input_fingerprint'):
            try:
                if matching.current_input_fingerprint(db, actor, row['line_id']) != match['input_fingerprint']:
                    row['action_reasons'].append('invoice_inputs_changed_after_comparison')
            except (ValueError, RuntimeError, OSError, LookupError):
                row['action_reasons'].append('invoice_inputs_changed_after_comparison')
        row['invoice_evidence'] = invoices(db, by_id[row['line_id']])
        row['action_reasons'] = sorted(set(row['action_reasons']))
        row['primary_bucket'] = 'accepted' if outcome['bucket'] == 'accepted' and not row['action_reasons'] else 'needs_action'
        row['financially_final'] = False

    dataset = {'schema': 'mcias-claim-trial-v1', 'batch_id': batch.id,
        'organization_id': actor.organization_id, 'source_sha256': batch.source_sha256,
        'rows': rows, 'total_lines': len(rows),
        'counts': {key: sum(row['primary_bucket'] == key for row in rows) for key in ('accepted', 'needs_action')},
        'audit_scope': 'rules_and_native_document_trial', 'not_run': ['OCR', 'INVESTIGATIVE_AI'],
        'financially_final': False}
    fingerprint = sha256(canonical(dataset)).hexdigest()
    lock_record(db, 'claim_trial', actor.organization_id, batch.id)
    prior = db.scalar(_events(actor, batch.id).where(AuditLog.details['fingerprint'].as_string() == fingerprint))
    if not prior:
        key, digest = store().put(canonical(dataset))
        source = SourceFile(sha256=digest, storage_key=key, original_filename='claim-trial-manifest.json')
        db.add(source); db.flush()
        db.add(AuditLog(actor_id=actor.id, organization_id=actor.organization_id,
            action='claim_trial.completed', resource_type='claim_batch', resource_id=batch.id,
            category='claim_trial', details={'source_id': source.id, 'fingerprint': fingerprint,
                'counts': dataset['counts'], 'total_lines': len(rows), 'financially_final': False}))
        db.flush()
    return {**dataset, 'fingerprint': fingerprint}


def latest_trial(db, actor, batch_id):
    batch = _batch(db, actor, batch_id)
    event = db.scalar(_events(actor, batch_id).order_by(AuditLog.created_at.desc(), AuditLog.id.desc()).limit(1))
    if not event:
        return None
    source = db.get(SourceFile, event.details['source_id'])
    if not source:
        raise ValueError('Trial evidence missing')
    data = json.loads(store().get(source.storage_key, source.sha256))
    if (data['organization_id'] != actor.organization_id or data['batch_id'] != batch_id
            or sha256(canonical(data)).hexdigest() != event.details['fingerprint']):
        raise ValueError('Trial evidence integrity failure')
    stale = []
    for row in data['rows']:
        matching.authorize_name_access(db, actor, row['invoice_match'])
        try:
            claim = matching.claim_for_actor(db, actor, row['line_id'])
            if (data['source_sha256'] != batch.source_sha256
                    or row['invoice_evidence'] != invoices(db, claim)
                    or not row['invoice_match'].get('input_fingerprint')
                    or matching.current_input_fingerprint(db, actor, claim.id) != row['invoice_match']['input_fingerprint']):
                stale.append(claim.id)
            if row.get('snapshot_id'):
                snapshot = db.get(AuditSnapshot, row['snapshot_id'])
                if not snapshot:
                    stale.append(claim.id)
                else:
                    verify_registered_policy(db, organization_id=actor.organization_id,
                                             policy_fingerprint=snapshot.policy_fingerprint)
        except HTTPException:
            raise
        except (LookupError, ValueError, RuntimeError, OSError):
            stale.append(row['line_id'])
    return {**data, 'fingerprint': event.details['fingerprint'], 'stale_line_ids': sorted(set(stale))}
