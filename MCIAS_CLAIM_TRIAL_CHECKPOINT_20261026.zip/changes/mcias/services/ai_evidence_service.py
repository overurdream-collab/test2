"""Operator-attested original-source facts for synthetic A1 integration.

No financial approval is represented here. Sensitive facts and reasons are
encrypted; append-only event metadata contains identifiers and hashes only.
"""
from datetime import datetime, timezone
from decimal import Decimal
from hashlib import sha256
import json
import os
from pathlib import Path
import re
from uuid import uuid4

from cryptography.exceptions import InvalidTag
from fastapi import HTTPException
from sqlalchemy import select

from mcias.models import AuditLog, SourceFile
from mcias.models_claims import ClaimAttachment, ClaimBatch, ClaimEntry
from mcias.models_ingestion import ExtractedSourceRecord, IngestionDocument, IngestionJob
from mcias.ingestion.file_scanner import identify
from mcias.ingestion.isolated_parser import isolated_parse
from mcias.ingestion.provenance import locator_dict
from mcias.services.authorization_service import check_permission_unified
from mcias.services.invoice_service import invoices
from mcias.services.registry_service import store
from mcias.services.transaction_lock import lock_record


class AIEvidenceMissing(LookupError):
    pass


class AIEvidenceConflict(ValueError):
    def __init__(self, code):
        self.code=code
        super().__init__(code)


class AIEvidenceUnavailable(RuntimeError):
    def __init__(self, code):
        self.code=code
        super().__init__(code)


def canonical(value):
    return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()


def _fingerprint(payload):
    return sha256(canonical({k:v for k,v in payload.items() if k not in ('fingerprint','created_at')})).hexdigest()


def claim_for_actor(db,actor,claim_id):
    claim=db.get(ClaimEntry,claim_id)
    if not claim or claim.organization_id!=actor.organization_id:
        raise AIEvidenceMissing('Claim not found')
    for code in ('claims.read','claims.review','ingestion.read','medical_fields.text.read'):
        if not check_permission_unified(db,actor,code):
            raise HTTPException(403,'permission denied')
    return claim


def _field_allowed(db,actor,name):
    return bool(name and name.replace('_','').isalnum()
        and check_permission_unified(db,actor,'medical_fields.'+name+'.read'))


def _manifest(actor):
    location=os.getenv('MCIAS_AI_SYNTHETIC_MANIFEST','')
    if not location:
        raise AIEvidenceUnavailable('ai_synthetic_manifest_not_configured')
    try:
        path=Path(location)
        if (not path.is_absolute() or path.is_symlink() or not path.is_file()
                or path.stat().st_size>1_048_576 or path.stat().st_mode&0o022):
            raise ValueError('Invalid manifest')
        data=json.loads(path.read_text(encoding='utf-8'))
        if data.get('schema')!='mcias-a1-synthetic-sources-v1':
            raise ValueError('Wrong schema')
        allowed=data['organizations'][actor.organization_id]['source_sha256']
        if (not isinstance(allowed,list) or len(allowed)>5000
                or any(not isinstance(s,str) or re.fullmatch(r'[0-9a-f]{64}',s) is None for s in allowed)):
            raise ValueError('Invalid registered sources')
        return set(allowed)
    except (OSError,ValueError,KeyError,TypeError,AttributeError):
        raise AIEvidenceUnavailable('ai_synthetic_manifest_invalid') from None


def _claim_state(db,actor,claim):
    batch=db.get(ClaimBatch,claim.batch_id)
    if not batch or batch.organization_id!=actor.organization_id or batch.status!='imported':
        raise AIEvidenceConflict('ai_claim_batch_not_ready')
    document=db.get(IngestionDocument,batch.ingestion_document_id)
    if not document or document.organization_id!=actor.organization_id or document.sha256!=batch.source_sha256:
        raise AIEvidenceConflict('ai_claim_source_changed')
    source=db.get(SourceFile,document.source_id)
    if not source or source.sha256!=document.sha256:
        raise AIEvidenceConflict('ai_claim_source_changed')
    try:
        store().get(source.storage_key,source.sha256)
    except (ValueError,OSError,InvalidTag):
        raise AIEvidenceConflict('ai_claim_source_changed') from None
    values={'id':claim.id,'batch_id':claim.batch_id,'record_id':claim.extracted_record_id,
        'source_locator':claim.source_locator,'source_values':claim.source_values,
        'claim_reference':claim.claim_reference,'beneficiary_token':claim.beneficiary_token,
        'provider_code':claim.provider_code,'service_code':claim.service_code,
        'service_date':claim.service_date.isoformat(),'claimed_amount':str(claim.claimed_amount),
        'currency':claim.currency,'source_sha256':batch.source_sha256}
    return {'batch_id':batch.id,'claim_source_sha256':batch.source_sha256,
            'claim_fingerprint':sha256(canonical(values)).hexdigest()}


def _document_records(db,actor,claim,attachment,cache):
    if attachment.id in cache:
        return cache[attachment.id]
    if attachment.claim_id!=claim.id or attachment.organization_id!=actor.organization_id:
        raise AIEvidenceMissing('Attachment not found')
    document=db.get(IngestionDocument,attachment.ingestion_document_id)
    if (not document or document.organization_id!=actor.organization_id or document.status!='extracted'
            or document.sha256!=attachment.document_sha256):
        raise AIEvidenceConflict('ai_attachment_source_changed')
    source=db.get(SourceFile,document.source_id)
    if not source or source.sha256!=document.sha256:
        raise AIEvidenceConflict('ai_attachment_source_changed')
    try:
        raw=store().get(source.storage_key,source.sha256)
        kind=identify(raw,document.filename)
        if kind not in ('pdf','csv','xlsx'):
            raise AIEvidenceConflict('ai_text_source_required_ocr_deferred')
        extraction=isolated_parse(kind,raw)
    except AIEvidenceConflict:
        raise
    except (ValueError,OSError,InvalidTag,RuntimeError):
        raise AIEvidenceConflict('ai_original_source_verification_failed') from None
    if not extraction.complete or extraction.quarantined:
        raise AIEvidenceConflict('ai_incomplete_source')
    if len(extraction.records)>100:
        raise AIEvidenceConflict('ai_source_record_limit')
    jobs=list(db.scalars(select(IngestionJob).where(IngestionJob.document_id==document.id,
        IngestionJob.organization_id==actor.organization_id)))
    job_ids=[j.id for j in jobs if j.status=='extracted' and j.manifest.get('complete') is True]
    if not job_ids:
        raise AIEvidenceConflict('ai_extraction_not_ready')
    records=list(db.scalars(select(ExtractedSourceRecord).where(ExtractedSourceRecord.job_id.in_(job_ids))))
    verified=[]
    for record in records:
        matches=[r for r in extraction.records if locator_dict(r.locator)==record.locator]
        if (len(matches)!=1 or matches[0].values!=record.values or record.confidence!=100
                or matches[0].confidence!=1):
            raise AIEvidenceConflict('ai_extracted_record_changed')
        verified.append(record)
    if not verified or len(verified)>100:
        raise AIEvidenceConflict('ai_source_record_limit')
    value=(document,verified)
    cache[attachment.id]=value
    return value


def _select(db,actor,claim,selection,cache):
    attachment=db.get(ClaimAttachment,selection['attachment_id'])
    if not attachment or attachment.claim_id!=claim.id or attachment.organization_id!=actor.organization_id:
        raise AIEvidenceMissing('Attachment not found')
    document,records=_document_records(db,actor,claim,attachment,cache)
    rows=[r for r in records if r.id==selection['record_id']]
    if len(rows)!=1:
        raise AIEvidenceMissing('Source record not found')
    record=rows[0]
    field=selection['field']
    if not _field_allowed(db,actor,field):
        raise HTTPException(403,'source field permission denied')
    text=record.values.get(field)
    start,end=selection['start'],selection['end']
    if (not isinstance(text,str) or len(text)>10000 or not isinstance(start,int) or not isinstance(end,int)
            or start<0 or end<=start or end>len(text) or end-start>2500):
        raise AIEvidenceConflict('ai_source_span_invalid')
    selected=text[start:end]
    if not selected.strip():
        raise AIEvidenceConflict('ai_source_span_empty')
    return {'selection':selection,'document_id':document.id,'sha256':document.sha256,
        'locator':record.locator,'text':selected,'field_text':text}


def _events(db,actor,claim_id):
    return select(AuditLog).where(AuditLog.organization_id==actor.organization_id,
        AuditLog.action=='ai_input.attested',AuditLog.resource_type=='ai_input_attestation',
        AuditLog.details['claim_id'].as_string()==claim_id)


def public_attestation(event):
    return {'id':event.resource_id,'claim_id':event.details['claim_id'],
        'fingerprint':event.details['fingerprint'],'version':event.details['version'],
        'previous_id':event.details.get('previous_id'),'created_at':event.created_at,
        'financially_final':False,'scope':'operator_source_facts_only'}


def latest_attestation(db,actor,claim_id):
    claim_for_actor(db,actor,claim_id)
    event=db.scalar(_events(db,actor,claim_id).order_by(
        AuditLog.details['version'].as_integer().desc(),AuditLog.created_at.desc(),AuditLog.id.desc()).limit(1))
    return public_attestation(event) if event else None


def source_options(db,actor,claim_id):
    claim=claim_for_actor(db,actor,claim_id)
    state=_claim_state(db,actor,claim)
    blocked=None
    try:
        allowed=_manifest(actor)
    except AIEvidenceUnavailable as exc:
        allowed=set();blocked=exc.code
    links=list(db.scalars(select(ClaimAttachment).where(ClaimAttachment.claim_id==claim.id,
        ClaimAttachment.organization_id==actor.organization_id).order_by(ClaimAttachment.created_at,ClaimAttachment.id).limit(21)))
    if len(links)>20:
        raise AIEvidenceConflict('ai_attachment_limit')
    invoice_ids={r['attachment_id'] for r in invoices(db,claim)}
    rows=[];cache={}
    for link in links:
        document,records=_document_records(db,actor,claim,link,cache)
        for record in records:
            fields={key:value for key,value in record.values.items()
                if isinstance(value,str) and len(value)<=10000 and _field_allowed(db,actor,key)}
            if not fields:
                continue
            rows.append({'attachment_id':link.id,'document_id':document.id,'record_id':record.id,
                'filename':document.filename,'sha256':document.sha256,'locator':record.locator,
                'fields':fields,'is_invoice':link.id in invoice_ids,'synthetic_allowed':document.sha256 in allowed})
    return {'claim_id':claim.id,'service_code':claim.service_code,'sources':rows,
        'latest_attestation':latest_attestation(db,actor,claim_id),
        'synthetic_allowed':state['claim_source_sha256'] in allowed,
        'blocked_code':blocked or (None if state['claim_source_sha256'] in allowed else 'ai_synthetic_source_not_registered')}


def _literal_facts(invoice,code,unit,quantity):
    text=invoice['text']
    for token in (code,unit):
        if not token.strip() or re.search(r'(?<![\w-])'+re.escape(token)+r'(?![\w-])',text) is None:
            raise AIEvidenceConflict('ai_invoice_fact_not_in_source')
    normalized=format(Decimal(quantity).normalize(),'f')
    number=re.escape(normalized)
    if '.' not in normalized:
        number+=r'(?:\.0{1,4})?'
    # A page may contain invoice/date/price numbers too. Only a quantity-labelled
    # value can support this first structured-source attestation contract.
    label=r'(?<!\w)(?:quantity|qty|الكمية|العدد|عدد)(?!\w)\s*[:=]?\s*'
    if re.search(label+number+r'(?![\w.,])',text,re.I) is None:
        raise AIEvidenceConflict('ai_invoice_quantity_not_in_source')


def attest(db,actor,claim_id,payload):
    claim=claim_for_actor(db,actor,claim_id)
    lock_record(db,'ai_review',actor.organization_id,claim_id)
    latest=latest_attestation(db,actor,claim_id)
    previous=str(payload.expected_previous_id) if payload.expected_previous_id else None
    if previous!=(latest['id'] if latest else None):
        raise AIEvidenceConflict('ai_attestation_version_conflict')
    selections={key:getattr(payload,key).model_dump(mode='json') for key in ('invoice','service_record')}
    cache={}
    invoice=_select(db,actor,claim,selections['invoice'],cache)
    record=_select(db,actor,claim,selections['service_record'],cache)
    if invoice['document_id']==record['document_id']:
        raise AIEvidenceConflict('ai_independent_service_record_required')
    if selections['invoice']['attachment_id'] not in {x['attachment_id'] for x in invoices(db,claim)}:
        raise AIEvidenceConflict('ai_operator_linked_invoice_required')
    if payload.service_code!=claim.service_code:
        raise AIEvidenceConflict('ai_service_code_mismatch')
    _literal_facts(invoice,payload.service_code,payload.unit,payload.billed_quantity)
    state=_claim_state(db,actor,claim)
    allowed=_manifest(actor)
    if not {state['claim_source_sha256'],invoice['sha256'],record['sha256']}<=allowed:
        raise AIEvidenceConflict('ai_synthetic_source_not_registered')
    identity=str(uuid4())
    invoice.update(service_code=payload.service_code,unit=payload.unit,billed_quantity=payload.billed_quantity)
    data={'schema':'mcias-a1-attested-input-v1','id':identity,'organization_id':actor.organization_id,
        'claim_id':claim_id,**state,'invoice':invoice,'service_record':record,'attested_by':actor.id,
        'reason':payload.reason,'version':latest['version']+1 if latest else 1,'previous_id':previous,
        'created_at':datetime.now(timezone.utc).isoformat(),'scope':'synthetic_operator_source_facts_only'}
    data['fingerprint']=_fingerprint(data)
    key,digest=store().put(canonical(data))
    source=SourceFile(sha256=digest,original_filename='a1-private-source-attestation.json',storage_key=key)
    db.add(source);db.flush()
    event=AuditLog(actor_id=actor.id,organization_id=actor.organization_id,action='ai_input.attested',
        resource_type='ai_input_attestation',resource_id=identity,category='ai_advisory',details={
            'claim_id':claim_id,'source_id':source.id,'source_sha256':digest,
            'fingerprint':data['fingerprint'],'version':data['version'],'previous_id':previous})
    db.add(event);db.flush()
    return public_attestation(event)


def authorize_fields(db,actor,payload):
    claim_for_actor(db,actor,payload['claim_id'])
    for name in ('invoice','service_record'):
        if not _field_allowed(db,actor,payload[name]['selection']['field']):
            raise HTTPException(403,'source field permission denied')


def load_attestation(db,actor,claim_id,attestation_id,require_latest=True):
    claim_for_actor(db,actor,claim_id)
    event=db.scalar(_events(db,actor,claim_id).where(AuditLog.resource_id==attestation_id))
    if not event:
        raise AIEvidenceMissing('Attestation not found')
    if require_latest and latest_attestation(db,actor,claim_id)['id']!=attestation_id:
        raise AIEvidenceConflict('ai_attestation_stale')
    source=db.get(SourceFile,event.details.get('source_id'))
    if not source or source.sha256!=event.details.get('source_sha256'):
        raise AIEvidenceConflict('ai_attestation_integrity_failure')
    try:
        data=json.loads(store().get(source.storage_key,source.sha256))
    except (ValueError,OSError,InvalidTag):
        raise AIEvidenceConflict('ai_attestation_integrity_failure') from None
    if (not isinstance(data,dict) or data.get('id')!=attestation_id or data.get('claim_id')!=claim_id
            or data.get('organization_id')!=actor.organization_id or _fingerprint(data)!=event.details['fingerprint']
            or data.get('fingerprint')!=event.details['fingerprint']):
        raise AIEvidenceConflict('ai_attestation_integrity_failure')
    authorize_fields(db,actor,data)
    return data


def verify_current(db,actor,payload):
    claim=claim_for_actor(db,actor,payload['claim_id'])
    if latest_attestation(db,actor,claim.id)['id']!=payload['id']:
        raise AIEvidenceConflict('ai_attestation_stale')
    state=_claim_state(db,actor,claim)
    if any(payload.get(k)!=v for k,v in state.items()):
        raise AIEvidenceConflict('ai_claim_source_changed')
    cache={}
    invoice=_select(db,actor,claim,payload['invoice']['selection'],cache)
    record=_select(db,actor,claim,payload['service_record']['selection'],cache)
    for key,part in (('invoice',invoice),('service_record',record)):
        if any(payload[key].get(k)!=v for k,v in part.items()):
            raise AIEvidenceConflict('ai_attested_source_changed')
    if invoice['document_id']==record['document_id'] or payload['invoice']['service_code']!=claim.service_code:
        raise AIEvidenceConflict('ai_attested_source_changed')
    _literal_facts(invoice,payload['invoice']['service_code'],payload['invoice']['unit'],
        payload['invoice']['billed_quantity'])
    if payload['invoice']['selection']['attachment_id'] not in {r['attachment_id'] for r in invoices(db,claim)}:
        raise AIEvidenceConflict('ai_operator_linked_invoice_required')
    allowed=_manifest(actor)
    if not {state['claim_source_sha256'],invoice['sha256'],record['sha256']}<=allowed:
        raise AIEvidenceConflict('ai_synthetic_source_not_registered')
    return payload
