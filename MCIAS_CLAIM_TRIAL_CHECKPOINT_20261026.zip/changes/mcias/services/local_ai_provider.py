"""Bounded local inference for the pinned experimental A1 model.

No model download, network request, database access or financial mutation occurs
here. Optional inference libraries are imported only in a spawned child. Raw
response and private request evidence must be persisted encrypted by the caller.
"""
from __future__ import annotations

from contextlib import contextmanager
from hashlib import sha256
import json
import multiprocessing as mp
import os
from pathlib import Path
import re
import stat
import tempfile
import threading
from time import monotonic


MODEL_REPO = "Qwen/Qwen3-4B-GGUF"
MODEL_REVISION = "bc640142c66e1fdd12af0bd68f40445458f3869b"
MODEL_SHA256 = "7485fe6f11af29433bc51cab58009521f205840f5b4ae3a32fa7f92e8534fdf5"
PROVIDER_VERSION = "mcias-local-qwen3-a1-v1"
MAX_INPUT_BYTES = 16_384
MAX_OUTPUT_BYTES = 16_000
MAX_TIMEOUT_SECONDS = 300
CONTEXT_TOKENS = 2048
OUTPUT_TOKENS = 320
RESPONSE_SCHEMA = {
    "type": "object",
    "properties": {"signals": {
        "type": "array", "maxItems": 8,
        "items": {
            "type": "object",
            "properties": {key: {"type": "string"} for key in (
                "line_item_id", "source_id", "exact_quote", "reported_quantity", "explanation")},
            "required": ["line_item_id", "source_id", "exact_quote", "reported_quantity", "explanation"],
            "additionalProperties": False,
        },
    }},
    "required": ["signals"], "additionalProperties": False,
}
_THREAD_SLOT = threading.Lock()


class LocalAIError(RuntimeError):
    """A stable, non-sensitive failure code; never exposes source/model content."""

    def __init__(self, code: str):
        self.code = code
        super().__init__(code)


def _canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def _digest(text):
    return sha256(text.encode("utf-8")).hexdigest()


def _settings():
    configured = os.environ.get("MCIAS_AI_MODEL_FILE", "")
    if not configured:
        raise LocalAIError("AI_NOT_CONFIGURED")
    path = Path(configured)
    if not path.is_absolute():
        raise LocalAIError("AI_CONFIGURATION_INVALID")
    configured_sha = os.environ.get("MCIAS_AI_MODEL_SHA256", MODEL_SHA256)
    if configured_sha != MODEL_SHA256:
        raise LocalAIError("AI_MODEL_UNSUPPORTED")
    try:
        timeout = int(os.environ.get("MCIAS_AI_TIMEOUT_SECONDS", "180"))
    except (ValueError, TypeError):
        raise LocalAIError("AI_CONFIGURATION_INVALID") from None
    if not 1 <= timeout <= MAX_TIMEOUT_SECONDS:
        raise LocalAIError("AI_CONFIGURATION_INVALID")
    try:
        path = path.resolve(strict=True)
        info = path.stat()
        if not stat.S_ISREG(info.st_mode) or not 0 < info.st_size <= 3 * 1024**3:
            raise LocalAIError("AI_MODEL_UNAVAILABLE")
    except (OSError, RuntimeError):
        raise LocalAIError("AI_MODEL_UNAVAILABLE") from None
    return {"model_file": str(path), "model_sha256": MODEL_SHA256, "timeout": timeout}


def _verify_model(path):
    """Executed inside the timed worker, including all model-file I/O."""
    checksum = sha256()
    try:
        with Path(path).open("rb") as source:
            for block in iter(lambda: source.read(4 * 1024 * 1024), b""):
                checksum.update(block)
    except OSError:
        raise LocalAIError("AI_MODEL_UNAVAILABLE") from None
    actual = checksum.hexdigest()
    if actual != MODEL_SHA256:
        raise LocalAIError("AI_MODEL_HASH_MISMATCH")
    return actual


@contextmanager
def _model_slot():
    """One local inference at a time across threads and same-host processes."""
    if not _THREAD_SLOT.acquire(blocking=False):
        raise LocalAIError("AI_BUSY")
    descriptor = None
    locked = False
    try:
        filename = Path(tempfile.gettempdir()) / "mcias-local-ai-inference.lock"
        flags = os.O_CREAT | os.O_RDWR | getattr(os, "O_NOFOLLOW", 0)
        try:
            descriptor = os.open(filename, flags, 0o600)
            if not stat.S_ISREG(os.fstat(descriptor).st_mode):
                raise OSError("invalid lock type")
            if os.name == "nt":
                import msvcrt
                if os.fstat(descriptor).st_size == 0:
                    os.write(descriptor, b"\0")
                os.lseek(descriptor, 0, os.SEEK_SET)
                msvcrt.locking(descriptor, msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
            locked = True
        except (OSError, ImportError):
            raise LocalAIError("AI_BUSY") from None
        yield
    finally:
        if descriptor is not None:
            try:
                if locked:
                    if os.name == "nt":
                        import msvcrt
                        os.lseek(descriptor, 0, os.SEEK_SET)
                        msvcrt.locking(descriptor, msvcrt.LK_UNLCK, 1)
                    else:
                        import fcntl
                        fcntl.flock(descriptor, fcntl.LOCK_UN)
            finally:
                os.close(descriptor)
        _THREAD_SLOT.release()


def _validate_output(raw, finish_reason):
    if finish_reason != "stop":
        raise LocalAIError("AI_OUTPUT_TRUNCATED")
    if not isinstance(raw, str) or not 0 < len(raw.encode("utf-8")) <= MAX_OUTPUT_BYTES:
        raise LocalAIError("AI_OUTPUT_INVALID")
    try:
        parsed = json.loads(raw, parse_constant=lambda _: (_ for _ in ()).throw(ValueError()))
    except (ValueError, TypeError):
        raise LocalAIError("AI_OUTPUT_INVALID") from None
    if not isinstance(parsed, dict) or set(parsed) != {"signals"}:
        raise LocalAIError("AI_OUTPUT_INVALID")
    signals = parsed["signals"]
    lengths = {"line_item_id": 128, "source_id": 128, "exact_quote": 500,
               "reported_quantity": 32, "explanation": 500}
    if not isinstance(signals, list) or len(signals) > 8:
        raise LocalAIError("AI_OUTPUT_INVALID")
    for candidate in signals:
        if (not isinstance(candidate, dict) or set(candidate) != set(lengths)
            or any(not isinstance(candidate[key], str) or not 0 < len(candidate[key]) <= limit
                   for key, limit in lengths.items())):
            raise LocalAIError("AI_OUTPUT_INVALID")


def _worker(settings, system, payload, connection):
    model = None
    started = monotonic()
    try:
        actual_sha = _verify_model(settings["model_file"])
        try:
            import llama_cpp
            from llama_cpp import Llama
            from llama_cpp.llama_chat_format import Jinja2ChatFormatter
        except ImportError:
            raise LocalAIError("AI_RUNTIME_UNAVAILABLE") from None
        model = Llama(model_path=settings["model_file"], n_ctx=CONTEXT_TOKENS,
                      n_threads=2, n_batch=256, n_gpu_layers=0, use_mmap=True,
                      seed=42, verbose=False)
        if model.metadata.get("general.architecture") != "qwen3":
            raise LocalAIError("AI_MODEL_UNSUPPORTED")
        official = model.metadata.get("tokenizer.chat_template")
        if not isinstance(official, str) or not official:
            raise LocalAIError("AI_RUNTIME_FAILED")
        template = "{% set enable_thinking = false %}" + official
        formatter = Jinja2ChatFormatter(template=template, eos_token="<|im_end|>",
            bos_token="", stop_token_ids=[model.token_eos()])
        model.chat_handler = formatter.to_chat_handler()
        messages = [{"role": "system", "content": system},
                    {"role": "user", "content": payload + "\n/no_think"}]
        rendered = formatter(messages=messages).prompt
        if not rendered.endswith("<think>\n\n</think>\n\n"):
            raise LocalAIError("AI_RUNTIME_FAILED")
        prompt_tokens = len(model.tokenize(rendered.encode("utf-8"), add_bos=False, special=True))
        if prompt_tokens + OUTPUT_TOKENS > CONTEXT_TOKENS:
            raise LocalAIError("AI_CONTEXT_LIMIT")
        response = model.create_chat_completion(messages=messages, max_tokens=OUTPUT_TOKENS,
            temperature=0, seed=42, response_format={"type": "json_object", "schema": RESPONSE_SCHEMA})
        choice = response["choices"][0]
        raw = choice["message"]["content"]
        _validate_output(raw, choice.get("finish_reason"))
        usage = response.get("usage", {})
        usage = {key: value for key, value in usage.items()
                 if key in ("prompt_tokens", "completion_tokens", "total_tokens")
                 and isinstance(value, int) and not isinstance(value, bool) and value >= 0}
        result = {"raw_text": raw, "provider_metadata": {
            "provider": "local_llama_cpp", "provider_version": PROVIDER_VERSION,
            "model_id": MODEL_REPO + "@" + MODEL_REVISION, "model_sha256": actual_sha,
            "runtime_version": llama_cpp.__version__, "system_prompt_sha256": _digest(system),
            "payload_sha256": _digest(payload), "rendered_prompt_sha256": _digest(rendered),
            "chat_template_sha256": _digest(template), "schema_sha256": _digest(_canonical(RESPONSE_SCHEMA)),
            "response_sha256": _digest(raw), "usage": usage,
            "elapsed_seconds": round(monotonic() - started, 6),
            "parameters": {"n_ctx": CONTEXT_TOKENS, "n_threads": 2, "n_gpu_layers": 0,
                           "max_tokens": OUTPUT_TOKENS, "temperature": 0, "seed": 42,
                           "thinking": False},
            "finish_reason": "stop", "network_inference": False,
        }, "private_evidence": {"system_prompt": system, "payload": payload,
                                 "rendered_prompt": rendered}}
        connection.send({"ok": True, "result": result})
    except LocalAIError as exc:
        connection.send({"ok": False, "code": exc.code})
    except Exception:
        # Do not send exception text: native/runtime errors may contain inputs.
        connection.send({"ok": False, "code": "AI_RUNTIME_FAILED"})
    finally:
        if model is not None:
            try:
                model.close()
            except Exception:
                pass
        connection.close()


def generate(system: str, payload: str) -> dict:
    """Return raw output/provenance or a stable failure; never treats failure as pass.

    ``private_evidence`` and ``raw_text`` are confidential artifacts. Callers must
    not put them in ordinary logs, audit-event metadata, or public error payloads.
    """
    if (not isinstance(system, str) or not isinstance(payload, str)
        or not system.strip() or not payload.strip()
        or len(system.encode("utf-8")) + len(payload.encode("utf-8")) > MAX_INPUT_BYTES):
        raise LocalAIError("AI_INPUT_INVALID")
    settings = _settings()
    with _model_slot():
        context = mp.get_context("spawn")
        receiver, sender = context.Pipe(duplex=False)
        worker = context.Process(target=_worker, args=(settings, system, payload, sender), daemon=True)
        started = False
        try:
            worker.start()
            started = True
            sender.close()
            if not receiver.poll(settings["timeout"]):
                raise LocalAIError("AI_TIMEOUT")
            try:
                message = receiver.recv()
            except (EOFError, OSError):
                raise LocalAIError("AI_WORKER_FAILED") from None
            if not isinstance(message, dict) or not isinstance(message.get("ok"), bool):
                raise LocalAIError("AI_WORKER_FAILED")
            if message["ok"] is False:
                code = message.get("code")
                if not isinstance(code, str) or re.fullmatch(r"AI_[A-Z_]+", code) is None:
                    code = "AI_WORKER_FAILED"
                raise LocalAIError(code)
            result = message.get("result")
            if not isinstance(result, dict) or not isinstance(result.get("provider_metadata"), dict):
                raise LocalAIError("AI_WORKER_FAILED")
            metadata = result["provider_metadata"]
            if metadata.get("model_sha256") != MODEL_SHA256:
                raise LocalAIError("AI_WORKER_FAILED")
            _validate_output(result.get("raw_text"), metadata.get("finish_reason"))
            return result
        except LocalAIError:
            raise
        except Exception:
            raise LocalAIError("AI_WORKER_FAILED") from None
        finally:
            if started:
                if worker.is_alive():
                    worker.terminate()
                worker.join(timeout=2)
                if worker.is_alive():
                    worker.kill()
                    worker.join(timeout=2)
            receiver.close()
            sender.close()
