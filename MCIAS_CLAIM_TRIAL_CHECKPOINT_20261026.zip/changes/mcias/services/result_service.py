"""Four disjoint preliminary outputs over existing G4/G5 evidence.

This projects existing audit snapshots; it neither audits claims nor invents an
approval. The frozen projection uses the existing encrypted source store and
append-only audit events, keeping the original workbook untouched.
"""
from collections import Counter, defaultdict
from decimal import Decimal
from hashlib import sha256
import json
from uuid import uuid4
from sqlalchemy import select
from mcias.models import AuditLog, SourceFile
from mcias.models_claims import ClaimBatch, ClaimEntry
from mcias.models_audit import AuditSnapshot
from mcias.palermo2 import verify
from mcias.reporting_g7 import amount, number, canonical, ReportBlocked
from mcias.services.registry_service import store
from mcias.services.transaction_lock import lock_record

BUCKETS = ('accepted','rejected','held','review')
LABELS = {'accepted':'مقبول مبدئيًا','rejected':'مرفوض مبدئيًا','held':'معلّق','review':'يحتاج مراجعة'}
PRIMARY_BUCKETS = ('accepted', 'needs_action')
PRIMARY_LABELS = {'accepted': 'مقبول مبدئيًا', 'needs_action': 'يحتاج إجراء'}
PRIMARY_REASONS = {
    'missing_invoice': 'نقص المرفقات — فاتورة الخدمة غير متوفرة',
    'not_audited': 'لم يكتمل التدقيق المالي',
    'missing_or_ambiguous_signed_policy': 'السياسة المالية المعتمدة غير متوفرة أو غير محددة',
    'unresolved_reference_or_evidence': 'يلزم استكمال المرجع أو الدليل',
    'proven_financial_difference': 'فرق مالي مبدئي يحتاج إجراء ومراجعة',
    'unresolved_review_finding': 'توجد ملاحظات تحتاج مراجعة',
    'invoice_comparison_missing': 'لم تكتمل مقارنة الفاتورة بالمطالبة',
    'invoice_comparison_incomplete': 'بيانات الفاتورة غير مكتملة للمقارنة',
    'invoice_identity_unresolved': 'هوية المستفيد في الفاتورة غير محسومة',
    'invoice_comparison_difference': 'توجد اختلافات بين الفاتورة والمطالبة',
    'invoice_evidence_changed_reaudit_required': 'تغيرت أدلة الفاتورة — يلزم إعادة تدقيق',
    'trial_evidence_changed': 'تغيرت مدخلات التجربة — يلزم إعادة التدقيق',
}


def project_line(claim, snapshot):
    item={'line_id':claim.id,'invoice_number':claim.claim_reference,'provider_code':claim.provider_code,
        'service_code':claim.service_code,'service_date':claim.service_date.isoformat(),
        'currency':claim.currency,'claimed_net':number(amount(claim.claimed_amount)),
        'bucket':'held','reason':'not_audited','audited':False,'proposed_net':None,
        'proposed_difference':None,'audit_snapshot_id':snapshot.id if snapshot else None,
        'source_locator':claim.source_locator,'source_record_id':claim.extracted_record_id,
        'source_values':claim.source_values,'financially_final':False}
    if snapshot is None:return item
    if snapshot.organization_id!=claim.organization_id or snapshot.claim_id!=claim.id:
        raise ReportBlocked('Audit evidence scope mismatch')
    item['audited']=True
    findings=snapshot.findings.get('agents',[]) if isinstance(snapshot.findings,dict) else []
    if any(isinstance(f,dict) and f.get('status')=='review' for f in findings):
        return {**item,'bucket':'review','reason':'unresolved_review_finding'}
    calculation=snapshot.calculation
    if not isinstance(calculation,dict) or calculation.get('status')!='calculated':
        return {**item,'reason':'missing_reference_or_evidence'}
    independently=verify(claim,findings,calculation,policy_fingerprint=snapshot.policy_fingerprint,
        policy_id=snapshot.policy_id,reference_check=snapshot.findings.get('reference_check'))
    if independently['status']!='verified' or not isinstance(snapshot.verification,dict) or snapshot.verification.get('status')!='verified':
        return {**item,'bucket':'review','reason':'verification_failed'}
    # Old snapshots do not declare whether copay was already paid. They must
    # not silently become a second copay deduction on the owner's NET input.
    if calculation.get('amount_basis')!='NET':
        return {**item,'bucket':'review','reason':'net_basis_confirmation_required'}
    steps=calculation.get('deductions',[])
    if any(s.get('rule')=='copay' and amount(s.get('deduction'))!=0 for s in steps):
        return {**item,'bucket':'review','reason':'possible_second_copay_deduction'}
    claimed=amount(claim.claimed_amount);payable=amount(calculation['payable'])
    difference=claimed-payable
    return {**item,'bucket':'rejected' if difference>0 else 'accepted',
        'reason':'proven_financial_difference' if difference>0 else 'verified_match',
        'proposed_net':number(payable),'proposed_difference':number(difference)}


def partition(rows, expected_ids):
    ids=[row['line_id'] for row in rows]
    if len(ids)!=len(set(ids)) or set(ids)!=set(expected_ids):
        raise ReportBlocked('Missing or duplicate claim line in output partition')
    if any(row['bucket'] not in BUCKETS for row in rows):
        raise ReportBlocked('Unknown output category')
    counts=Counter(row['bucket'] for row in rows)
    totals=defaultdict(lambda:{key:Decimal(0) for key in BUCKETS})
    for row in rows:totals[row['currency']][row['bucket']]+=amount(row['claimed_net'])
    return {'total_lines':len(rows),'counts':{key:counts[key] for key in BUCKETS},
        'claimed_net_by_currency':{currency:{key:number(value) for key,value in values.items()} for currency,values in sorted(totals.items())},
        'unique_line_count':len(set(ids)),'financially_final':False}


def _events(db,org):
    return select(AuditLog).where(AuditLog.organization_id==org,
        AuditLog.action=='result_set.created',AuditLog.resource_type=='audit_result_set')


def freeze(db,actor,batch_id,primary=False):
    from mcias.services.rbac_service import _atomic
    with _atomic(db):
        lock_record(db,'result_set',actor.organization_id,batch_id)
        batch=db.get(ClaimBatch,batch_id)
        if not batch or batch.organization_id!=actor.organization_id:raise LookupError('Batch not found')
        if batch.status!='imported' or batch.record_count!=batch.imported_count:
            raise ReportBlocked('Complete the batch import before creating outputs')
        claims=list(db.scalars(select(ClaimEntry).where(ClaimEntry.batch_id==batch.id,
            ClaimEntry.organization_id==actor.organization_id).order_by(ClaimEntry.id)))
        if len(claims)!=batch.record_count or len(claims)>10000:
            raise ReportBlocked('Batch count mismatch or output limit exceeded')
        snapshots={}
        for row in db.scalars(select(AuditSnapshot).join(ClaimEntry,ClaimEntry.id==AuditSnapshot.claim_id).where(
            ClaimEntry.batch_id==batch.id,AuditSnapshot.organization_id==actor.organization_id).order_by(AuditSnapshot.created_at,AuditSnapshot.id)):
            snapshots[row.claim_id]=row
        rows=[project_line(claim,snapshots.get(claim.id)) for claim in claims]
        from mcias.services.net_audit_service import latest_run
        run=latest_run(db,actor,batch.id)
        outcomes={r['line_id']:r for r in run['rows']} if run else {}
        for row in rows:
            outcome=outcomes.get(row['line_id'])
            if outcome and outcome['bucket'] in ('held','review'):
                row.update(bucket=outcome['bucket'],reason=outcome['reason'],proposed_net=None,proposed_difference=None)
        from mcias.services.invoice_service import invoices
        for claim,row in zip(claims,rows):
            evidence=invoices(db,claim);row['invoices']=evidence
            if not evidence:
                row.update(bucket='held',reason='missing_invoice',reason_ar='نقص المرفقات — فاتورة الخدمة غير متوفرة',
                    audited=False,proposed_net=None,proposed_difference=None)
            else:
                snapshot=snapshots.get(claim.id)
                calculation=snapshot.calculation if snapshot else None
                if isinstance(calculation,dict) and calculation.get('amount_basis')=='NET' and calculation.get('invoice_evidence')!=evidence:
                    row.update(bucket='review',reason='invoice_evidence_changed_reaudit_required',
                        reason_ar='تغيرت أدلة الفاتورة بعد التدقيق — يلزم إعادة تدقيق معتمدة',
                        proposed_net=None,proposed_difference=None)
        summary=partition(rows,[claim.id for claim in claims])
        dataset={'schema':'mcias-four-results-v1','batch_id':batch.id,'organization_id':actor.organization_id,
            'source_sha256':batch.source_sha256,'stage':'preliminary','rows':rows,'summary':summary}
        if primary:
            from mcias.services.claim_trial_service import latest_trial
            trial = latest_trial(db, actor, batch.id)
            apply_primary(dataset, trial)
        digest=sha256(canonical(dataset)).hexdigest()
        previous=db.scalar(_events(db,actor.organization_id).where(AuditLog.details['fingerprint'].as_string()==digest).limit(1))
        if previous:return public(previous)
        object_id,stored_digest=store().put(canonical(dataset))
        source=SourceFile(sha256=stored_digest,original_filename='frozen-preliminary-results.json',storage_key=object_id)
        db.add(source);db.flush()
        details={'source_id':source.id,'fingerprint':digest,'batch_id':batch.id,'summary':summary}
        if primary:
            details['primary_summary'] = dataset['primary_summary']
        event=AuditLog(actor_id=actor.id,organization_id=actor.organization_id,action='result_set.created',
            resource_type='audit_result_set',resource_id=str(uuid4()),category='reporting',details={
                **details})
        db.add(event);db.flush();return public(event)


def public(event):
    value={'id':event.resource_id,'batch_id':event.details['batch_id'],'fingerprint':event.details['fingerprint'],
        'summary':event.details['summary'],'created_at':event.created_at,'stage':'preliminary','financially_final':False}
    if 'primary_summary' in event.details:
        value['primary_summary'] = event.details['primary_summary']
    return value


def list_results(db,actor,offset=0,limit=25):
    events=list(db.scalars(_events(db,actor.organization_id).order_by(AuditLog.created_at.desc(),AuditLog.id).offset(offset).limit(limit+1)))
    return {'items':[public(e) for e in events[:limit]],'has_more':len(events)>limit,'offset':offset,'limit':limit}


def read(db,actor,result_id):
    event=db.scalar(_events(db,actor.organization_id).where(AuditLog.resource_id==result_id))
    if not event:raise LookupError('Result set not found')
    source=db.get(SourceFile,event.details['source_id'])
    if not source:raise ReportBlocked('Frozen results source missing')
    raw=store().get(source.storage_key,source.sha256)
    dataset=json.loads(raw)
    if sha256(canonical(dataset)).hexdigest()!=event.details['fingerprint'] or dataset['organization_id']!=actor.organization_id:
        raise ReportBlocked('Frozen output integrity failure')
    summary=partition(dataset['rows'],[row['line_id'] for row in dataset['rows']])
    if summary!=dataset['summary'] or summary!=event.details['summary']:
        raise ReportBlocked('Frozen output summary mismatch')
    if dataset.get('schema') == 'mcias-primary-results-v1':
        primary_summary=primary_partition(dataset['rows'], [row['line_id'] for row in dataset['rows']])
        if primary_summary!=dataset.get('primary_summary') or primary_summary!=event.details.get('primary_summary'):
            raise ReportBlocked('Frozen primary output summary mismatch')
    return dataset


def primary_partition(rows, expected_ids):
    """Validate exclusive primary membership without changing internal outcomes."""
    partition(rows, expected_ids)
    if any(row.get('primary_bucket') not in PRIMARY_BUCKETS for row in rows):
        raise ReportBlocked('Unknown primary output category')
    counts=Counter(row['primary_bucket'] for row in rows)
    totals=defaultdict(lambda:{key:Decimal(0) for key in PRIMARY_BUCKETS})
    for row in rows:
        totals[row['currency']][row['primary_bucket']]+=amount(row['claimed_net'])
    return {'total_lines':len(rows),'counts':{key:counts[key] for key in PRIMARY_BUCKETS},
        'claimed_net_by_currency':{currency:{key:number(value) for key,value in values.items()}
                                   for currency,values in sorted(totals.items())},
        'unique_line_count':len(rows),'financially_final':False}


def apply_primary(dataset, trial):
    """Classify a NEW frozen set using completed source-bound trial evidence.

    Old snapshots alone cannot become new accepted results. The existing legacy
    outcome and its amounts remain available even when this view needs action.
    """
    valid_trial=bool(trial and trial.get('batch_id')==dataset['batch_id']
        and trial.get('organization_id')==dataset['organization_id']
        and trial.get('source_sha256')==dataset['source_sha256'])
    outcomes={}
    if valid_trial:
        identities=[row.get('line_id') for row in trial['rows']]
        if len(identities)!=len(set(identities)) or set(identities)!={row['line_id'] for row in dataset['rows']}:
            raise ReportBlocked('Trial line membership mismatch')
        outcomes={row['line_id']:row for row in trial['rows']}
    for row in dataset['rows']:
        outcome=outcomes.get(row['line_id'])
        reasons=[]
        if row['bucket']!='accepted':
            reasons.append(row['reason'])
        match=outcome.get('invoice_match') if outcome else None
        same=bool(outcome and match and row['line_id'] not in trial.get('stale_line_ids',[])
            and match.get('claim_source',{}).get('sha256')==dataset['source_sha256']
            and outcome.get('invoice_evidence')==row.get('invoices')
            and outcome.get('snapshot_id')==row.get('audit_snapshot_id'))
        complete=bool(same and match.get('status')=='CONSISTENT_FIELDS'
            and match.get('identity',{}).get('status')=='MATCH'
            and match.get('checks_complete') is True
            and isinstance(match.get('input_fingerprint'),str)
            and len(match['input_fingerprint'])==64
            and outcome.get('bucket')=='accepted')
        if not outcome or not match:
            reasons.append('invoice_comparison_missing')
        else:
            reasons.extend(outcome.get('action_reasons') or [])
            if not same and match.get('input_fingerprint'):
                reasons.append('trial_evidence_changed')
            if match.get('identity',{}).get('status')!='MATCH':
                reasons.append('invoice_identity_unresolved')
            if match.get('status')=='DIFFERENT':
                reasons.append('invoice_comparison_difference')
            elif match.get('status')!='CONSISTENT_FIELDS' or not match.get('checks_complete'):
                reasons.append('invoice_comparison_incomplete')
        if not complete and not reasons:
            reasons.append('invoice_comparison_incomplete')
        row['primary_bucket']='accepted' if row['bucket']=='accepted' and complete and not reasons else 'needs_action'
        row['reasons']=sorted(set(str(reason) for reason in reasons if reason))
        row['primary_reason_ar']='؛ '.join(PRIMARY_REASONS.get(reason, 'يلزم مراجعة الدليل أو البيانات: '+reason)
                                          for reason in row['reasons']) if row['reasons'] else 'اكتملت الفحوص المطلوبة — مقبول مبدئيًا'
        # Full source-grounded evidence stays encrypted in the frozen dataset.
        # Public line projection exposes check metadata, not identity text.
        row['invoice_match']=match
        row['trial_checks']=outcome.get('audited_checks',[]) if outcome else []
    dataset['schema']='mcias-primary-results-v1'
    dataset['trial_fingerprint']=trial.get('fingerprint') if valid_trial else None
    dataset['primary_summary']=primary_partition(dataset['rows'],[row['line_id'] for row in dataset['rows']])
    return dataset
