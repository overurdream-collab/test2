"""Conservative source-context recovery for an isolated synthetic A1 experiment.

This adapter never establishes source trust, clinical truth, or financial
authority. It can recover the one original sentence containing a literal model
quotation. It does not correct model quantities, IDs, explanations or source
trust. A1's original independent guards still validate the returned candidate.
"""
from __future__ import annotations

from hashlib import sha256
import json
import re


ADAPTER_VERSION = 'source-single-sentence-context-v2-version-readiness'
MAX_QUOTE = 500
SENTENCE_BOUNDARIES = re.compile(r'[.!?؟؛\n]')
VERSION_REVIEW_MARKERS = re.compile(
    r'\b(?:draft|superseded|correction|corrected|revised|revision|obsolete)\b'
    r'|\b(?:previous|earlier|mixed|conflicting)\s+versions?\b'
    r'|(?<!\w)(?:ال)?(?:مسودة|مسوّدة|تصحيح|مصحح)(?!\w)'
    r'|(?<!\w)(?:ال)?(?:نسخة|نسخه)\s+(?:ملغاة|ملغاه|سابقة|سابقه)(?!\w)',
    re.I,
)


def _canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)


def _hash(text):
    return sha256(text.encode('utf-8')).hexdigest() if isinstance(text, str) else None


def _occurrences(text, quote):
    """Include overlapping matches; repeated text cannot create a unique citation."""
    points = []
    cursor = 0
    while True:
        start = text.find(quote, cursor)
        if start < 0:
            return points
        points.append(start)
        if len(points) > 1:
            return points
        cursor = start + 1


def _sentence_containing(text, start, end):
    """Return one literal sentence span; never bridge punctuation or newlines.

    Colons are retained, so a preceding service code remains in its sentence.
    Periods are conservative boundaries, including abbreviation/decimal periods;
    uncertain spans are rejected rather than joined or repaired.
    """
    sentence_start = 0
    for boundary in SENTENCE_BOUNDARIES.finditer(text):
        sentence_end = boundary.end()
        if sentence_start <= start and end <= sentence_end:
            left, right = sentence_start, sentence_end
            while left < right and text[left].isspace():
                left += 1
            while right > left and text[right - 1].isspace():
                right -= 1
            if left <= start and end <= right:
                return left, right, text[left:right]
            return None
        sentence_start = sentence_end
    left, right = sentence_start, len(text)
    while left < right and text[left].isspace():
        left += 1
    while right > left and text[right - 1].isspace():
        right -= 1
    if left <= start and end <= right:
        return left, right, text[left:right]
    return None


def normalize_model_response(raw, user_payload):
    """Return normalized_response plus complete change/rejection provenance.

    ``user_payload`` is the unchanged JSON A1 supplied to the model before any
    /no_think suffix, with invoice_lines[] and source_texts[]. Input JSON or
    envelope errors are returned untouched so original A1 guards report invalid
    output. Invalid individual candidates are removed with a trace; no rejected
    candidate can exploit legacy substring-code matching.
    """
    trace = {'adapter_version': ADAPTER_VERSION, 'raw_response_sha256': _hash(raw),
             'user_payload_sha256': _hash(user_payload), 'changes': [],
             'rejected_candidates': [], 'status': 'UNCHANGED',
             'source_review_required': False, 'source_reviews': [],
             'evidence_readiness': 'NOT_ASSESSED',
             'financial_authority': 'NONE_ADVISORY_ONLY',
             'normalization_scope': 'LITERAL_SOURCE_CONTEXT_RECOVERY_NOT_MODEL_GENERATED_CONTEXT'}
    try:
        response = json.loads(raw)
        payload = json.loads(user_payload)
        if (not isinstance(response, dict) or not isinstance(response.get('signals'), list)
                or not isinstance(payload, dict) or not isinstance(payload.get('invoice_lines'), list)
                or not isinstance(payload.get('source_texts'), list)):
            raise ValueError('invalid response or payload envelope')
    except (TypeError, ValueError):
        trace.update(status='INVALID_ENVELOPE_UNCHANGED', normalized_response=raw,
                     normalized_response_sha256=_hash(raw))
        return trace

    # Conservative readiness only: text mentioning versions/corrections does not
    # establish which span is current. Do not choose a FINAL count from prose.
    # This is deliberately broad and may require review of otherwise valid
    # documents. It never changes quantities or turns an absence into approval.
    review_sources = set()
    for source in payload['source_texts']:
        if not isinstance(source, dict) or not isinstance(source.get('text'), str):
            continue
        sid = source.get('source_id')
        if not isinstance(sid, str):
            continue
        for match in VERSION_REVIEW_MARKERS.finditer(source['text']):
            review_sources.add(sid)
            trace['source_reviews'].append({
                'source_id': sid, 'matched_marker': match.group(0),
                'char_start': match.start(), 'char_end': match.end(),
                'reason': 'EVIDENCE_VERSION_REVIEW_REQUIRED',
            })
    trace['source_review_required'] = bool(review_sources)
    trace['source_fiscal_use_blocked'] = bool(review_sources)
    trace['evidence_readiness'] = ('EVIDENCE_VERSION_REVIEW_REQUIRED' if review_sources
                                   else 'NO_VERSION_MARKER_DETECTED_NOT_FINANCIAL_ACCEPTANCE')

    kept = []
    for index, original in enumerate(response['signals']):
        def reject(reason):
            trace['rejected_candidates'].append({'candidate_index': index, 'reason': reason,
                                                  'original_candidate': original})
        if not isinstance(original, dict):
            reject('CANDIDATE_NOT_OBJECT')
            continue
        line_id = original.get('line_item_id')
        source_id = original.get('source_id')
        quote = original.get('exact_quote')
        if not isinstance(line_id, str) or not isinstance(source_id, str):
            reject('INVALID_SOURCE_OR_LINE_ID')
            continue
        lines = [line for line in payload['invoice_lines']
                 if isinstance(line, dict) and line.get('line_item_id') == line_id]
        if len(lines) != 1 or not isinstance(lines[0].get('service_code'), str) or not lines[0]['service_code']:
            reject('MISSING_OR_AMBIGUOUS_INVOICE_LINE')
            continue
        sources = [source for source in payload['source_texts']
                   if isinstance(source, dict) and source.get('source_id') == source_id]
        if len(sources) != 1 or not isinstance(sources[0].get('text'), str):
            reject('MISSING_OR_AMBIGUOUS_SOURCE')
            continue
        if source_id in review_sources:
            reject('EVIDENCE_VERSION_REVIEW_REQUIRED')
            continue
        if sources[0].get('attested_source') is not True:
            reject('SOURCE_NOT_ATTESTED_BY_CALLER_FIXTURE')
            continue
        if not isinstance(quote, str) or not 8 <= len(quote) <= MAX_QUOTE:
            reject('UNSUPPORTED_QUOTE_LENGTH_OR_TYPE')
            continue
        text = sources[0]['text']
        matches = _occurrences(text, quote)
        if len(matches) != 1:
            reject('QUOTE_NOT_UNIQUE_LITERAL_SUBSTRING')
            continue
        quote_start, quote_end = matches[0], matches[0] + len(quote)
        sentence = _sentence_containing(text, quote_start, quote_end)
        if sentence is None:
            reject('QUOTE_CROSSES_SENTENCE_BOUNDARY')
            continue
        sentence_start, sentence_end, original_sentence = sentence
        if not 8 <= len(original_sentence) <= MAX_QUOTE or len(_occurrences(text, original_sentence)) != 1:
            reject('UNSUPPORTED_OR_AMBIGUOUS_SENTENCE')
            continue
        code = lines[0]['service_code']
        code_pattern = r'(?<![\w-])' + re.escape(code) + r'(?![\w-])'
        if re.search(code_pattern, original_sentence) is None:
            reject('SOURCE_SENTENCE_LACKS_EXACT_INVOICE_SERVICE_CODE')
            continue
        # Preserve a quote already equal to the full literal sentence.
        if quote == original_sentence:
            kept.append(original)
            continue
        candidate = dict(original)
        candidate['exact_quote'] = original_sentence
        kept.append(candidate)
        trace['changes'].append({
            'candidate_index': index, 'source_id': source_id, 'line_item_id': line_id,
            'original_quote': quote, 'expanded_quote': original_sentence,
            'original_quote_char_start': quote_start, 'original_quote_char_end': quote_end,
            'char_start': sentence_start, 'char_end': sentence_end,
            'source_text_sha256': _hash(text),
            'origin': 'ADAPTER_RECOVERED_LITERAL_SOURCE_SENTENCE_NOT_MODEL_GENERATED_TEXT',
        })
    normalized = dict(response)
    normalized['signals'] = kept
    normalized_raw = _canonical(normalized)
    trace.update(normalized_response=normalized_raw, normalized_response_sha256=_hash(normalized_raw),
                 candidate_count=len(response['signals']), retained_candidate_count=len(kept),
                 status='NORMALIZED' if trace['changes'] or trace['rejected_candidates'] else 'UNCHANGED')
    return trace

