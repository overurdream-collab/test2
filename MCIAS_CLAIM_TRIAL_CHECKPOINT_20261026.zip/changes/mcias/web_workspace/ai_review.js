/** Local A1 advisory drawer. Source text is read-only and all writes use server provenance. */
import { L, el, field, button, panel, badge, loading, errorState, openDrawer } from './ui.js';
import { ApiError } from './api.js';

export const canAIReview = context =>
  ['claims.read', 'claims.review', 'ingestion.read'].every(code => context.permissions.includes(code));

const statuses = {
  running: ['جارٍ التشغيل', 'Running'], completed: ['اكتملت المراجعة الاستشارية', 'Advisory review completed'],
  review_required: ['مراجعة المصدر مطلوبة', 'Source review required'],
  failed: ['تعذر إجراء المراجعة', 'Review failed'], blocked: ['المراجعة محجوبة', 'Review blocked'],
};
const assessments = {
  signal_detected: ['رُصدت إشارة تحتاج مراجعة بشرية', 'Signal detected; human review required'],
  no_validated_signal: ['لم تُثبت إشارة؛ لا يعني ذلك قبول المطالبة', 'No validated signal; this does not approve the claim'],
  source_review_required: ['يجب مراجعة المصدر قبل الاستنتاج', 'Source review required before inference'],
  failed: ['تعذر الاستنتاج؛ لا توجد نتيجة اعتماد', 'Inference failed; no approval result'],
};
const chars = text => Array.from(text);
const statusLabel = status => statuses[status] ? L(...statuses[status]) : String(status || '');
const safeError = error => error instanceof ApiError ? error : new ApiError(503);

export function openAIReview(ctx, claim) {
  if (!canAIReview(ctx.context)) return;
  const claimId = typeof claim === 'string' ? claim : claim.id;
  const base = `/api/v1/claims/entries/${encodeURIComponent(claimId)}/ai-review`;
  const { api, context } = ctx;
  const body = el('div');
  body.dataset.aiReview = '';
  body.style.overflowWrap = 'anywhere';
  const sourcesArea = el('div'), historyArea = el('div'), resultArea = el('div');
  historyArea.dataset.aiHistory = '';
  resultArea.dataset.aiRunResult = '';
  resultArea.setAttribute('aria-live', 'polite');
  const intro = panel(L('تدقيق ذكي استشاري — تجربة A1', 'Advisory AI review — A1 experiment'),
    L('للمصادر الاصطناعية المسجلة على الخادم فقط. النتائج تحتاج مراجعة بشرية وليست اعتمادًا ماليًا. تُحفظ المصادر الأصلية دون تعديل.',
      'Registered synthetic sources only. Results require human review and are not financially final. Original sources remain unchanged.'));
  intro.append(el('p', L('بند المطالبة: ', 'Claim line: ') + claimId));
  body.append(intro, sourcesArea, resultArea, historyArea);
  openDrawer(L('تدقيق ذكي استشاري', 'Advisory AI review'), body);
  const drawer = document.getElementById('drawer');
  let alive = true, evidence = null, busy = false, evidenceLoading = false, dirty = false;
  let evidenceVersion = 0, historyVersion = 0, detailVersion = 0, offset = 0;
  let runButton = null, saveButton = null, sourceFields = null, refreshSourcesButton = null;
  const current = () => alive && drawer.open && body.isConnected && drawer.contains(body);
  drawer.addEventListener('close', () => {
    alive = false;
    body.replaceChildren();
  }, { once: true });

  function showError(target, error) {
    if (current() && error.name !== 'AbortError') target.replaceChildren(errorState(safeError(error)));
  }
  function updateActions() {
    if (!current()) return;
    if (sourceFields) sourceFields.disabled = busy;
    if (saveButton) saveButton.disabled = busy || evidenceLoading || !evidence?.synthetic_allowed || !!evidence?.blocked_code;
    if (runButton) runButton.disabled = busy || evidenceLoading || dirty || !evidence?.latest_attestation || !evidence?.synthetic_allowed || !!evidence?.blocked_code;
    if (refreshSourcesButton) refreshSourcesButton.disabled = busy || evidenceLoading;
  }
  function markDirty() {
    dirty = true;
    updateActions();
  }
  function renderRun(run) {
    if (!current()) return;
    resultArea.removeAttribute('aria-busy');
    const card = panel(L('نتيجة استشارية محفوظة', 'Saved advisory result'),
      L('ليست نهائية ماليًا؛ يلزم قرار المراجع البشري ضمن إجراءات التدقيق الحالية.',
        'Not financially final. A human reviewer must use the existing audit process.'));
    card.append(badge(statusLabel(run.status)), el('p', L('معرّف التشغيل: ', 'Run ID: ') + run.id));
    if (run.stale) card.append(el('p', L('نتيجة قديمة: تغيرت المدخلات أو لم تعد أدلتها الحالية متاحة. راجع المصادر وأعد توثيقها.',
      'Stale result: inputs changed or current evidence is unavailable. Review and attest the sources again.'), 'error'));
    if (run.status === 'running') card.append(el('p', L('الخادم يسجل هذا التشغيل قيد التنفيذ. حدّث السجل لقراءة حالته الفعلية.',
      'The server records this run as pending. Refresh history to read its actual state.')));
    const result = run.result;
    if (result) {
      card.append(el('h3', assessments[result.assessment] ? L(...assessments[result.assessment]) : result.assessment));
      card.append(el('p', L('المراجعة البشرية مطلوبة', 'Human review required')));
      if (result.source_review_required) card.append(el('p', L('لا تستنتج كمية من مصدر متعارض أو غير محدد؛ راجع إصدارات المصدر أولًا.',
        'Review source versions before inferring a quantity from conflicting or unspecified evidence.')));
      for (const finding of result.findings || []) {
        const item = panel(L('إشارة استشارية', 'Advisory finding'), finding.explanation);
        const quote = el('blockquote', finding.supporting_quote || '');
        quote.dir = 'auto';
        quote.style.whiteSpace = 'pre-wrap';
        item.append(quote,
          el('p', L('الكمية المذكورة في المصدر: ', 'Source-reported quantity: ') + String(finding.source_reported_quantity ?? '')),
          el('p', L('الكمية المفوترة الموثقة: ', 'Attested billed quantity: ') + String(finding.billed_quantity ?? '')));
        for (const ref of finding.evidence_refs || []) {
          const p = el('p');
          p.append(el('span', L('مرجع الدليل: ', 'Evidence reference: ')), el('code', `${ref.document_id || ''} · ${ref.sha256 || ''} · ${ref.locator || ''}`));
          item.append(p);
        }
        card.append(item);
      }
      if (result.error_code) card.append(el('p', L('رمز حالة المراجعة: ', 'Review status code: ') + result.error_code));
      const metadata = el('details');
      metadata.append(el('summary', L('بيانات التشغيل الفعلية', 'Actual run metadata')));
      const pre = el('pre', JSON.stringify({ model_status: result.model_status, actual_model_calls: result.actual_model_calls,
        provider: result.provider || {}, error_code: result.error_code || null }, null, 2));
      pre.dir = 'ltr';
      pre.style.whiteSpace = 'pre-wrap';
      metadata.append(pre);
      card.append(metadata);
    }
    resultArea.replaceChildren(card);
  }

  async function showRun(id) {
    const version = ++detailVersion;
    resultArea.replaceChildren(loading());
    try {
      const run = await api.request(`${base}/runs/${encodeURIComponent(id)}`);
      if (current() && version === detailVersion) renderRun(run);
    } catch (error) { if (version === detailVersion) showError(resultArea, error); }
  }

  async function refreshHistory() {
    const version = ++historyVersion;
    const card = panel(L('سجل المراجعات الاستشارية', 'Advisory review history'));
    const controls = el('div', null, 'actions');
    controls.append(button(L('تحديث السجل', 'Refresh history'), () => void refreshHistory()));
    const list = el('div');
    list.append(loading());
    card.append(controls, list);
    if (current()) historyArea.replaceChildren(card);
    try {
      const page = await api.request(`${base}/runs?offset=${offset}&limit=20`);
      if (!current() || version !== historyVersion) return;
      list.replaceChildren();
      if (!page.items.length) list.append(el('p', L('لا توجد مراجعات استشارية محفوظة لهذا البند.', 'No saved advisory reviews for this line.')));
      for (const run of page.items) {
        const row = el('div', null, 'panel');
        row.append(badge(statusLabel(run.status)), el('p', `${run.id} · ${run.created_at}`),
          el('p', L('توثيق المدخلات: ', 'Input attestation: ') + run.attestation_id),
          button(L('عرض النتيجة والأدلة', 'View result and evidence'), () => void showRun(run.id)));
        list.append(row);
      }
      if (offset) controls.append(button(L('السابق', 'Previous'), () => { offset = Math.max(0, offset - 20); void refreshHistory(); }));
      if (page.has_more) controls.append(button(L('التالي', 'Next'), () => { offset += 20; void refreshHistory(); }));
    } catch (error) { if (version === historyVersion) showError(list, error); }
  }

  function sourcePicker(kind, title, options, changed) {
    const wrap = panel(title);
    const select = field(`ai-${kind}-source`, L('المستند والسجل الأصلي', 'Original document and record'), { options: [['', L('اختر المصدر', 'Select source')]] });
    const sourceField = field(`ai-${kind}-field`, L('حقل النص الأصلي', 'Original text field'), { options: [['', L('اختر الحقل', 'Select field')]] });
    const original = field(`ai-${kind}-text`, L('النص الأصلي — للقراءة والتحديد فقط', 'Original text — read and select only'), { type: 'textarea', required: false, maxLength: 10000 });
    original.input.readOnly = true;
    original.input.rows = 8;
    original.input.dir = 'auto';
    const start = field(`ai-${kind}-start`, L('بداية المقطع (من صفر)', 'Span start (zero-based)'), { type: 'number', min: 0, max: 10000 });
    const end = field(`ai-${kind}-end`, L('نهاية المقطع (غير مشمولة)', 'Span end (exclusive)'), { type: 'number', min: 1, max: 10000 });
    const quote = el('blockquote');
    quote.dataset.aiQuote = kind;
    quote.dir = 'auto';
    quote.style.whiteSpace = 'pre-wrap';
    const provenance = el('p');
    const selectionStatus = el('p');
    selectionStatus.setAttribute('aria-live', 'polite');
    let rows = [], selected = null;
    function updateQuote() {
      const text = chars(original.input.value), a = Number(start.input.value), b = Number(end.input.value);
      const valid = start.input.value !== '' && end.input.value !== '' && Number.isInteger(a) && Number.isInteger(b) && a >= 0 && b > a && b <= text.length && b - a <= 2500;
      quote.textContent = valid ? text.slice(a, b).join('') : '';
      selectionStatus.textContent = valid ? L('عدد أحرف المقطع: ', 'Span characters: ') + (b - a)
        : L('حدد مقطعًا أصليًا غير فارغ حتى 2500 حرف، أو أدخل حدوده. تُحسب الفهارس بأحرف Unicode.',
          'Select a nonempty original span up to 2,500 characters, or enter its bounds. Indices count Unicode characters.');
      start.input.setCustomValidity(valid ? '' : L('راجع حدود المقطع الأصلي.', 'Check the original span bounds.'));
      return valid && !!quote.textContent.trim();
    }
    function updateField() {
      original.input.value = selected?.fields[sourceField.input.value] || '';
      const length = chars(original.input.value).length;
      start.input.max = length;
      end.input.max = length;
      start.input.value = '';
      end.input.value = '';
      updateQuote();
    }
    function updateSource() {
      selected = rows[Number(select.input.value)] || null;
      if (select.input.value === '') selected = null;
      sourceField.input.replaceChildren();
      for (const name of Object.keys(selected?.fields || {})) {
        const option = el('option', name);
        option.value = name;
        sourceField.input.append(option);
      }
      provenance.textContent = selected ? `${selected.filename} · ${selected.record_id} · SHA-256: ${selected.sha256} · ${JSON.stringify(selected.locator)}` : '';
      updateField();
    }
    function setOptions(next) {
      rows = next;
      select.input.replaceChildren();
      const placeholder = el('option', L('اختر المصدر', 'Select source'));
      placeholder.value = '';
      select.input.append(placeholder);
      rows.forEach((source, index) => {
        const option = el('option', `${source.filename} · ${source.record_id.slice(0, 8)} · ${source.synthetic_allowed ? L('مسجل اصطناعيًا', 'Registered synthetic') : L('غير مسجل', 'Unregistered')}`);
        option.value = String(index);
        select.input.append(option);
      });
      updateSource();
    }
    select.input.addEventListener('change', () => { updateSource(); changed?.(selected); markDirty(); });
    sourceField.input.addEventListener('change', () => { updateField(); markDirty(); });
    for (const input of [start.input, end.input]) input.addEventListener('input', () => { updateQuote(); markDirty(); });
    function captureSelection() {
      const value = original.input.value;
      if (original.input.selectionEnd <= original.input.selectionStart) return;
      start.input.value = chars(value.slice(0, original.input.selectionStart)).length;
      end.input.value = chars(value.slice(0, original.input.selectionEnd)).length;
      updateQuote();
      markDirty();
    }
    original.input.addEventListener('select', captureSelection);
    const useSelection = button(L('استخدام النص المحدد', 'Use selected text'), captureSelection);
    wrap.append(select.wrap, sourceField.wrap, provenance, original.wrap, useSelection, start.wrap, end.wrap, selectionStatus,
      el('p', L('المقطع المختار من المصدر:', 'Selected original quote:')), quote);
    setOptions(options);
    return { wrap, setOptions, selected: () => selected, span: () => {
      if (!selected || !updateQuote()) return null;
      return { attachment_id: selected.attachment_id, record_id: selected.record_id, field: sourceField.input.value,
        start: Number(start.input.value), end: Number(end.input.value) };
    } };
  }

  function supportingUpload(target) {
    if (!['ingestion.upload', 'claims.import'].every(code => context.permissions.includes(code))) return;
    const form = el('form', null, 'form-panel');
    const file = field('ai-supporting-file', L('إضافة سجل خدمة داعم أصلي', 'Add an original supporting service record'), { type: 'file' });
    file.input.accept = '.csv,.xlsx,.pdf';
    const feedback = el('div');
    feedback.setAttribute('aria-live', 'polite');
    const upload = button(L('رفع وربط السجل الداعم', 'Upload and link supporting record'));
    upload.type = 'submit';
    form.append(file.wrap, el('p', L('CSV أو XLSX أو PDF نصي. لا يتوفر OCR. قد يتطلب الملف الجديد تسجيل بصمته على الخادم قبل تشغيل التجربة.',
      'CSV, XLSX or text PDF. OCR is unavailable. A new source may need its hash registered on the server before this experiment can run.')), upload, feedback);
    form.addEventListener('submit', async event => {
      event.preventDefault();
      if (!current() || busy || !form.reportValidity()) return;
      const source = file.input.files[0];
      if (!source) return;
      if (source.size > 20 * 1024 * 1024) {
        feedback.replaceChildren(el('p', L('حجم الملف يتجاوز 20 MiB', 'File exceeds 20 MiB')));
        return;
      }
      busy = true;
      upload.disabled = true;
      updateActions();
      feedback.replaceChildren(loading());
      try {
        const raw = await source.arrayBuffer();
        if (!current()) return;
        const document = await api.request('/api/v1/ingestion/uploads?filename=' + encodeURIComponent(source.name), { method: 'POST', raw: true, body: raw });
        if (!current()) return;
        if (!['extracted', 'duplicate'].includes(document.status)) {
          feedback.replaceChildren(el('p', L('حُفظ الأصل لكن الاستخراج غير مكتمل. راجع المصدر قبل ربطه للمراجعة الذكية.',
            'The original was preserved but extraction is incomplete. Review the source before linking it for AI review.')));
          return;
        }
        await api.request(`/api/v1/claims/entries/${encodeURIComponent(claimId)}/attachments/${encodeURIComponent(document.document_id)}?kind=supporting`, { method: 'POST' });
        if (!current()) return;
        await refreshEvidence();
      } catch (error) { showError(feedback, error); }
      finally {
        if (current()) { busy = false; upload.disabled = false; updateActions(); }
      }
    });
    target.append(form);
  }

  function renderEvidence() {
    const card = panel(L('توثيق حقائق من المصدر الأصلي', 'Attest original-source facts'),
      L('اختر فاتورة PDF مرتبطة وسجل خدمة مستقلًا من مستند آخر. يجب أن يتضمن مقطع الفاتورة رمز الخدمة والوحدة وكمية صريحة بجوار QUANTITY أو qty أو الكمية. لا تُستنتج كمية أو وحدة من المطالبة.',
        'Select a linked PDF invoice and an independent service record from another document. The invoice span must contain the service code, unit and an explicit QUANTITY, qty or الكمية label. Quantity and unit must be read from the original invoice.'));
    refreshSourcesButton = button(L('تحديث المصادر', 'Refresh sources'), () => void refreshEvidence());
    card.append(refreshSourcesButton);
    if (evidence.blocked_code || !evidence.synthetic_allowed) {
      const blocked = panel(L('الإعداد يحجب التجربة', 'Configuration blocks this experiment'),
        L('لم تُهيأ قائمة المصادر الاصطناعية أو لم تُسجل بصمات هذه المصادر. يجب على المسؤول ضبط الخادم؛ لا يمكن تشغيل هذه التجربة حاليًا.',
          'The server synthetic-source manifest is unconfigured or these source hashes are unregistered. An administrator must configure the server before this experiment can run.'));
      blocked.dataset.aiConfigurationBlocked = '';
      blocked.append(el('code', evidence.blocked_code || 'ai_synthetic_source_not_registered'));
      card.append(blocked);
    }
    const attestation = el('div');
    attestation.dataset.aiAttestation = '';
    const latest = evidence.latest_attestation;
    attestation.append(el('p', latest ? `${L('إصدار التوثيق المحفوظ: ', 'Saved attestation version: ')}${latest.version} · ${latest.id}`
      : L('لا يوجد توثيق محفوظ؛ أكمل اختيار المصادر والحقائق أولًا.', 'No saved attestation. Select sources and attest the facts first.')));
    if (latest) attestation.append(el('code', latest.fingerprint));
    card.append(attestation);
    const form = el('form');
    sourceFields = el('fieldset');
    sourceFields.style.minWidth = '0';
    sourceFields.append(el('legend', L('المصادر والحقائق التي يتحقق منها المراجع', 'Reviewer-verified sources and facts')));
    const rows = evidence.sources || [];
    if (!rows.some(source => source.is_invoice && /\.pdf$/i.test(source.filename))) card.append(el('p',
      L('لا توجد فاتورة PDF نصية مرتبطة. استخدم «إضافة فاتورة أو مرفق» في قسم التدقيق لربط الفاتورة، ثم حدّث المصادر.',
        'No linked text PDF invoice is available. Use “Add invoice or attachment” in Audit to link an invoice, then refresh sources.')));
    if (!rows.some(source => !source.is_invoice)) card.append(el('p',
      L('لا يوجد سجل خدمة داعم مستقل. ارفع سجلًا أصليًا من CSV أو XLSX أو PDF نصي أدناه إن كانت لديك صلاحية الرفع.',
        'No independent supporting service record is available. Upload an original CSV, XLSX or text PDF below if you have upload permission.')));
    const code = field('ai-service-code', L('رمز الخدمة من المطالبة', 'Claim service code'), { value: evidence.service_code || '', maxLength: 100 });
    code.input.readOnly = true;
    const unit = field('ai-unit', L('الوحدة كما وردت حرفيًا في مقطع الفاتورة', 'Unit exactly as written in the invoice span'), { maxLength: 80 });
    const quantity = field('ai-billed-quantity', L('الكمية المفوترة الصريحة من مقطع الفاتورة', 'Explicit billed quantity from the invoice span'),
      { pattern: '(?:0|[1-9][0-9]{0,8})(?:\\.[0-9]{1,4})?', maxLength: 16 });
    quantity.input.inputMode = 'decimal';
    const reason = field('ai-reason', L('سبب توثيق حقائق المصدر', 'Reason for attesting source facts'), { type: 'textarea', maxLength: 500 });
    reason.input.minLength = 3;
    const service = sourcePicker('service', L('سجل الخدمة المستقل', 'Independent service record'), rows.filter(source => !source.is_invoice));
    const invoice = sourcePicker('invoice', L('الفاتورة الأصلية المرتبطة', 'Original linked invoice'),
      rows.filter(source => source.is_invoice && /\.pdf$/i.test(source.filename)), selected => {
        service.setOptions(rows.filter(source => !source.is_invoice && source.document_id !== selected?.document_id));
        unit.input.value = '';
        quantity.input.value = '';
      });
    for (const input of [unit.input, quantity.input, reason.input]) input.addEventListener('input', markDirty);
    const feedback = el('div');
    feedback.setAttribute('aria-live', 'polite');
    saveButton = button(L('حفظ توثيق المصدر', 'Save source attestation'), null, 'button primary');
    saveButton.type = 'submit';
    sourceFields.append(invoice.wrap, service.wrap, code.wrap, unit.wrap, quantity.wrap, reason.wrap, saveButton, feedback);
    form.append(sourceFields);
    form.addEventListener('submit', async event => {
      event.preventDefault();
      if (!current() || busy || saveButton.disabled || !form.reportValidity()) return;
      const invoiceSpan = invoice.span(), serviceSpan = service.span();
      if (!invoiceSpan || !serviceSpan || Number(quantity.input.value) <= 0 || !invoice.selected()?.synthetic_allowed || !service.selected()?.synthetic_allowed) {
        feedback.replaceChildren(el('p', L('اختر مقاطع أصلية من مصدرين مستقلين مسجلين وكمية صريحة موجبة. راجع الحقول قبل الحفظ.',
          'Select original spans from two registered independent sources and a positive explicit quantity. Check the fields before saving.')));
        return;
      }
      busy = true;
      updateActions();
      feedback.replaceChildren(loading());
      try {
        const saved = await api.request(`${base}/attestations`, { method: 'POST', body: {
          invoice: invoiceSpan, service_record: serviceSpan, service_code: code.input.value,
          unit: unit.input.value, billed_quantity: quantity.input.value, reason: reason.input.value,
          expected_previous_id: evidence.latest_attestation?.id || null,
        } });
        if (!current()) return;
        evidence.latest_attestation = saved;
        dirty = false;
        await refreshEvidence();
      } catch (error) { showError(feedback, error); }
      finally { if (current()) { busy = false; updateActions(); } }
    });
    card.append(form);
    runButton = button(L('تشغيل المراجعة الاستشارية', 'Run advisory review'), async () => {
      if (!current() || runButton.disabled) return;
      const saved = evidence.latest_attestation;
      busy = true;
      const version = ++detailVersion;
      updateActions();
      resultArea.setAttribute('aria-busy', 'true');
      resultArea.replaceChildren(el('p', L('جارٍ انتظار نتيجة الخادم. لا تزال المراجعة قيد الطلب؛ يمكن تحديث السجل لقراءة الحالة الفعلية.',
        'Waiting for the server result. The review request is pending; refresh history to read its actual state.')));
      try {
        const run = await api.request(`${base}/runs`, { method: 'POST', body: {
          attestation_id: saved.id, expected_fingerprint: saved.fingerprint,
        } });
        if (!current()) return;
        if (version === detailVersion) renderRun(run);
        await refreshHistory();
      } catch (error) { if (version === detailVersion) showError(resultArea, error); }
      finally {
        if (current()) { busy = false; resultArea.removeAttribute('aria-busy'); updateActions(); }
      }
    }, 'button primary');
    card.append(el('p', L('التشغيل يستخدم آخر توثيق محفوظ وبصمته. احفظ أي تغيير قبل التشغيل.',
      'A run uses the latest saved attestation and fingerprint. Save any changes before running.')), runButton);
    supportingUpload(card);
    sourcesArea.replaceChildren(card);
    updateActions();
  }

  async function refreshEvidence() {
    const version = ++evidenceVersion;
    evidenceLoading = true;
    updateActions();
    if (!evidence) sourcesArea.replaceChildren(loading());
    try {
      const next = await api.request(`${base}/evidence`);
      if (!current() || version !== evidenceVersion) return;
      evidence = next;
      dirty = false;
      renderEvidence();
    } catch (error) {
      if (version === evidenceVersion) {
        evidence = null;
        showError(sourcesArea, error);
      }
    } finally {
      if (current() && version === evidenceVersion) { evidenceLoading = false; updateActions(); }
    }
  }

  void Promise.allSettled([refreshEvidence(), refreshHistory()]);
}
