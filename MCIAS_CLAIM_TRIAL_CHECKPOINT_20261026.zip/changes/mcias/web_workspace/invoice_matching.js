/** Read-only invoice/Excel comparison. Candidates never approve or change a claim. */
import { L, el, button, panel, badge, loading, empty, errorState, openDrawer } from './ui.js';
import { ApiError } from './api.js';

export const canInvoiceMatch = context =>
  ['claims.read', 'claims.review', 'ingestion.read', 'medical_fields.text.read', 'medical_fields.beneficiary_token.read']
    .every(code => (context?.permissions || []).includes(code));

const statuses = {
  CONSISTENT_FIELDS: ['الحقول المقارنة متوافقة — المراجعة مطلوبة', 'Compared fields agree — review required'],
  DIFFERENT: ['توجد اختلافات تحتاج مراجعة', 'Differences require review'],
  INSUFFICIENT_EVIDENCE: ['الأدلة غير كافية للمقارنة', 'Insufficient evidence for comparison'],
  MATCH: ['متوافق', 'Match'], DIFFERENT_FIELD: ['مختلف', 'Different'],
  MISSING: ['غير متوفر', 'Missing'], INVALID: ['غير صالح للمقارنة', 'Invalid for comparison'],
  HUMAN_REVIEW: ['المراجعة البشرية مطلوبة', 'Human review required'],
};
const fields = {
  claim_reference: ['رقم الفاتورة', 'Invoice reference'], invoice_reference: ['رقم الفاتورة', 'Invoice reference'],
  beneficiary_token: ['الرقم التأميني', 'Beneficiary insurance number'], beneficiary: ['المستفيد', 'Beneficiary'],
  provider_code: ['مقدم الخدمة', 'Provider'], provider: ['مقدم الخدمة', 'Provider'],
  service_code: ['الخدمة', 'Service'], service: ['الخدمة', 'Service'], service_date: ['تاريخ الخدمة', 'Service date'],
  claimed_amount: ['الصافي المطالب به', 'Claimed net'], net: ['الصافي', 'Net'],
  gross_amount: ['المطلوب قبل التحمل', 'Gross before copay'], gross: ['المطلوب قبل التحمل', 'Gross before copay'],
  copay_amount: ['مبلغ التحمل', 'Copay amount'], copay: ['مبلغ التحمل', 'Copay amount'],
  unit_price: ['سعر الوحدة', 'Unit price'], quantity: ['الكمية', 'Quantity'], currency: ['العملة', 'Currency'],
};
const issues = {
  MISSING_INVOICE: ['فاتورة بند الخدمة غير مرتبطة.', 'No invoice is linked to this service line.'],
  NO_UNIQUE_INVOICE_LINE: ['لم يُحدد بند فاتورة واحد يخص هذه المطالبة.', 'No unique invoice line was identified for this claim.'],
  AMBIGUOUS_INVOICE_LINE: ['يوجد أكثر من بند مرشح؛ يجب تحديد المصدر الصحيح.', 'Multiple candidate lines exist; the correct source needs review.'],
  INVOICE_LINE_IDENTITY_DIFFERS: ['هوية بند الفاتورة تختلف عن المطالبة.', 'The invoice line identity differs from the claim.'],
  INVOICE_PAGE_REQUIRES_REVIEW: ['توجد صفحة فاتورة تحتاج مراجعة.', 'An invoice page requires review.'],
  INVOICE_ARITHMETIC_UNAVAILABLE: ['بيانات حساب إجمالي الفاتورة والتحمل والصافي غير مكتملة.', 'Invoice gross, copay and net calculation data are incomplete.'],
  INVOICE_ARITHMETIC_DIFFERS: ['أرقام إجمالي الفاتورة والتحمل والصافي غير متسقة.', 'Invoice gross, copay and net amounts do not reconcile.'],
  INVOICE_ARITHMETIC_INVALID: ['توجد قيمة غير صالحة لحساب الفاتورة.', 'An invoice amount is invalid for calculation.'],
  INVOICE_UNIT_ARITHMETIC_UNAVAILABLE: ['الكمية أو سعر الوحدة غير متوفر للتحقق.', 'Quantity or unit price is unavailable for verification.'],
  INVOICE_UNIT_ARITHMETIC_DIFFERS: ['حاصل الكمية وسعر الوحدة يختلف عن الإجمالي.', 'Quantity multiplied by unit price differs from gross.'],
  INVOICE_UNIT_ARITHMETIC_INVALID: ['الكمية أو سعر الوحدة غير صالح لحساب الفاتورة.', 'Quantity or unit price is invalid for invoice calculation.'],
  NATIVE_PDF_REQUIRED_OCR_DEFERRED: ['المرفق يحتاج مسار قراءة غير متاح في هذه المعاينة.', 'This attachment requires a reading method unavailable in this preview.'],
  OCR_DEFERRED_NO_TEXT_LAYER: ['الصفحة غير قابلة للقراءة النصية؛ يلزم استكمال دليلها.', 'The page has no readable text layer; its evidence needs completion.'],
  G2_EXTRACTION_NOT_READY_OCR_DEFERRED: ['استخراج المرفق غير مكتمل.', 'Attachment extraction is incomplete.'],
  UNRESOLVED_PAGES: ['بعض صفحات الفاتورة لم تُقرأ بصورة موثوقة.', 'Some invoice pages were not read reliably.'],
  ENCRYPTED_PDF: ['الفاتورة محمية؛ يلزم توفير نسخة يمكن مراجعتها.', 'The invoice is protected; provide a reviewable copy.'],
  PDF_PAGE_LIMIT: ['عدد صفحات المرفق يتجاوز حد المعاينة؛ راجع الفواتير في ملفات أصغر.', 'The attachment exceeds the preview page limit; review invoices in smaller files.'],
  INVALID_PAGE_GEOMETRY: ['أبعاد الصفحة غير مناسبة للمعاينة الموثوقة.', 'Page dimensions do not support a reliable preview.'],
  UNSUPPORTED_PAGE_ROTATION: ['اتجاه الصفحة يحتاج معالجة قبل تحديد مواقع الحقول.', 'The page orientation needs processing before field locations can be verified.'],
  PAGE_TEXT_EXTRACTION_FAILED: ['تعذرت قراءة نص الصفحة؛ يلزم مراجعة الأصل.', 'Page text could not be read; review the original.'],
  PDF_PARSE_FAILED: ['تعذرت قراءة ملف الفاتورة؛ يلزم مراجعة الأصل.', 'The invoice file could not be read; review the original.'],
  TOO_MANY_PDF_WORDS: ['كثافة نص الصفحة تتجاوز حد المعاينة الموثوقة.', 'Page text density exceeds the reliable preview limit.'],
  PDF_TOKEN_LIMIT: ['حجم نص الصفحة يتجاوز حد المعاينة الموثوقة.', 'Page text size exceeds the reliable preview limit.'],
  TEXT_BOX_OUTSIDE_PAGE: ['موضع النص لا يتوافق مع حدود الصفحة؛ يلزم التحقق من الأصل.', 'Text coordinates do not agree with page boundaries; verify the original.'],
  MULTIPLE_LABELS_ON_LINE: ['تنسيق الفاتورة يجمع عدة حقول في سطر واحد؛ يحتاج مراجعة.', 'The invoice layout combines several fields on one line and requires review.'],
};
const label = (key, lookup) => lookup[key] ? L(...lookup[key]) : String(key || '');
const value = item => item === null || item === undefined || item === '' ? '—'
  : typeof item === 'object' ? JSON.stringify(item) : String(item);

function sourceView(source, title) {
  const box = el('div');
  box.append(el('strong', title));
  if (!source) {
    box.append(el('p', L('لا يوجد موضع مصدر موثق لهذا الحقل.', 'No verified source location for this field.')));
    return box;
  }
  if (source.column !== undefined) box.append(el('p', L('العمود: ', 'Column: ') + value(source.column)));
  if (source.locator) box.append(el('code', value(source.locator)));
  if (source.page !== undefined) box.append(el('p', L('الصفحة: ', 'Page: ') + value(source.page)));
  if (source.bbox_points) {
    const position = el('code', value(source.bbox_points));
    position.dir = 'ltr';
    box.append(el('p', L('موضع الحقل بالنقاط: ', 'Field bounds in points: ')), position);
  }
  if (source.quote !== undefined) {
    const quote = el('blockquote', source.quote);
    quote.dir = 'auto';
    quote.style.whiteSpace = 'pre-wrap';
    quote.dataset.invoiceQuote = '';
    box.append(quote);
  }
  if (source.source) box.append(el('code', value(source.source)));
  return box;
}

function issuesView(codes) {
  const list = el('ul');
  for (const code of codes || []) {
    const item = el('li');
    let description = issues[code] ? L(...issues[code]) : null;
    for (const [prefix, ar, en] of [
      ['MISSING_FIELD_', 'لم يتوفر حقل موثق: ', 'Verified field unavailable: '],
      ['EMPTY_LABEL_', 'حقل الفاتورة فارغ: ', 'Invoice field is empty: '],
      ['DUPLICATE_LABEL_', 'ظهر الحقل أكثر من مرة ولم يُحسم مصدره: ', 'Repeated field has no unique source: '],
    ]) if (String(code).startsWith(prefix)) description = L(ar, en) + label(String(code).slice(prefix.length), fields);
    item.append(el('span', description || L('توجد مشكلة في قراءة دليل الفاتورة؛ يلزم مراجعة المصدر.',
      'Invoice evidence could not be read reliably; review the source.')));
    const metadata = el('details');
    metadata.append(el('summary', L('رمز الحالة', 'Status code')), el('code', value(code)));
    item.append(metadata); list.append(item);
  }
  return list;
}

function comparisonView(rows) {
  const wrap = el('div', null, 'table-scroll'), table = el('table');
  table.dataset.invoiceComparisons = '';
  table.append(el('caption', L('مقارنة القيم مع الملف الأصلي', 'Comparison against original claim data')));
  const head = el('tr'), thead = el('thead'), body = el('tbody');
  for (const title of [L('الحقل', 'Field'), L('Excel', 'Excel'), L('الفاتورة', 'Invoice'),
    L('نتيجة المقارنة', 'Comparison result'), L('المصدر والدليل', 'Source and evidence')]) {
    const cell = el('th', title); cell.scope = 'col'; head.append(cell);
  }
  thead.append(head); table.append(thead, body);
  for (const row of rows) {
    const tr = el('tr'), status = row.status === 'DIFFERENT' ? 'DIFFERENT_FIELD' : row.status;
    tr.dataset.invoiceField = row.field;
    tr.append(el('td', label(row.field, fields)), el('td', value(row.claim_value)),
      el('td', value(row.document_value)), el('td', label(status, statuses)));
    const evidence = el('td');
    evidence.append(sourceView(row.claim_source, L('مصدر Excel', 'Excel source')),
      sourceView(row.document_source, L('مصدر الفاتورة', 'Invoice source')));
    tr.append(evidence); body.append(tr);
  }
  wrap.append(table);
  return wrap;
}

export function openInvoiceMatch(ctx, claim) {
  if (!canInvoiceMatch(ctx.context)) return;
  const claimId = typeof claim === 'string' ? claim : claim.id;
  const body = el('div');
  body.dataset.invoiceMatch = '';
  body.style.overflowWrap = 'anywhere';
  body.dir = L('rtl', 'ltr');
  const introduction = panel(L('مقارنة مرشحة — لا اعتماد مالي', 'Candidate comparison — no financial approval'),
    L('تُقارن الحقول المقروءة من الفاتورة مع بند Excel الأصلي. الاتفاق لا يثبت صحة المطالبة أو اكتمال التدقيق. المصادر الأصلية محفوظة دون تعديل.',
      'Readable invoice fields are compared with the original Excel line. Agreement does not prove claim validity or a completed audit. Original sources remain unchanged.'));
  introduction.append(el('p', L('معرّف بند الخدمة: ', 'Service line ID: ') + claimId));
  const result = el('div');
  result.dataset.invoiceMatchResult = '';
  result.setAttribute('aria-live', 'polite');
  body.append(introduction, result);
  openDrawer(L('مطابقة الفاتورة', 'Compare invoice'), body);
  const drawer = document.getElementById('drawer');
  let alive = true, requestVersion = 0;
  const current = () => alive && drawer.open && body.isConnected && drawer.contains(body);
  drawer.addEventListener('close', () => { alive = false; body.replaceChildren(); }, { once: true });

  function render(data) {
    const summary = panel(label(data.status, statuses),
      L('هذه معاينة تحتاج مراجعة بشرية؛ لا تغيّر أي مبلغ أو نتيجة أو مرفق.',
        'This preview requires human review and changes no amount, result or attachment.'));
    summary.append(badge(L('الأثر المالي: لا يوجد', 'Financial effect: none')));
    if (data.claim_source) {
      summary.append(el('p', L('بصمة ملف المطالبات الأصلي: ', 'Original claims source hash: ')),
        el('code', value(data.claim_source.sha256)), sourceView(data.claim_source, L('صف المصدر الأصلي', 'Original source row')));
    }
    if (data.issues?.length) summary.append(issuesView(data.issues));
    result.replaceChildren(summary);
    if (data.selected_candidate) result.append(el('p', `${L('المصدر المرشح: ', 'Candidate source: ')}${data.selected_candidate.document_id} · ${L('الصفحة', 'Page')} ${data.selected_candidate.page}`));
    if (data.comparisons?.length) result.append(comparisonView(data.comparisons));
    const documents = Array.isArray(data.documents) ? data.documents : [];
    if (!documents.length) result.append(empty(L('لا فاتورة قابلة للمقارنة', 'No invoice available for comparison'),
      L('راجع ربط فاتورة بند الخدمة والمرفقات المطلوبة. لا يُفسّر النقص كمخالفة مالية.',
        'Review this service line’s invoice link and required attachments. Missing evidence is not a financial violation.')));
    for (const doc of documents) {
      const details = el('details');
      details.dataset.invoiceDocument = doc.document_id;
      details.append(el('summary', L('مصدر الفاتورة: ', 'Invoice source: ') + doc.document_id),
        el('p', L('معرّف المرفق: ', 'Attachment ID: ') + doc.attachment_id), el('code', value(doc.sha256)));
      if (doc.status) details.append(el('p', label(doc.status, statuses)));
      if (doc.issues?.length) details.append(issuesView(doc.issues));
      for (const page of doc.pages || []) {
        const pageView = panel(L('الصفحة: ', 'Page: ') + page.page);
        if (page.issues?.length) pageView.append(issuesView(page.issues));
        for (const [key, field] of Object.entries(page.fields || {})) {
          const item = el('details');
          item.append(el('summary', label(key, fields) + ': ' + value(field.value)),
            sourceView(field, L('الحقل في الفاتورة الأصلية', 'Field in original invoice')));
          pageView.append(item);
        }
        details.append(pageView);
      }
      result.append(details);
    }
    result.append(button(L('تحديث المقارنة', 'Refresh comparison'), () => void load()));
  }

  async function load() {
    const version = ++requestVersion;
    if (current()) result.replaceChildren(loading());
    try {
      const data = await ctx.api.request(`/api/v1/claims/entries/${encodeURIComponent(claimId)}/invoice-matches`);
      if (current() && version === requestVersion) render(data);
    } catch (error) {
      if (!current() || version !== requestVersion || error.name === 'AbortError') return;
      result.replaceChildren(errorState(error instanceof ApiError ? error : new ApiError(503), () => void load()));
    }
  }
  void load();
}
