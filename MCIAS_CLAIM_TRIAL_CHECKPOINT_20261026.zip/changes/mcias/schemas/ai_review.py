"""Source selections and optimistic-concurrency inputs; no client-authored text."""
from decimal import Decimal
from uuid import UUID
from pydantic import Field, field_validator, model_validator
from mcias.schemas.common import Input


class SourceSpan(Input):
    attachment_id: UUID
    record_id: UUID
    field: str = Field(min_length=1,max_length=100)
    start: int = Field(ge=0,le=2_000_000,strict=True)
    end: int = Field(ge=1,le=2_000_000,strict=True)

    @model_validator(mode='after')
    def bounded_span(self):
        if self.end <= self.start or self.end-self.start > 2500:
            raise ValueError('Select a bounded, nonempty original source span')
        return self


class AIInputAttestation(Input):
    invoice: SourceSpan
    service_record: SourceSpan
    service_code: str = Field(min_length=1,max_length=100)
    unit: str = Field(min_length=1,max_length=80)
    billed_quantity: str = Field(min_length=1,max_length=16,strict=True,
        pattern=r'^(?:0|[1-9][0-9]{0,8})(?:\.[0-9]{1,4})?$')
    reason: str = Field(min_length=3,max_length=500)
    expected_previous_id: UUID|None = None

    @field_validator('billed_quantity')
    @classmethod
    def positive_quantity(cls,value):
        if Decimal(value)<=0:
            raise ValueError('An explicit positive invoice quantity is required')
        return value

    @field_validator('reason','service_code','unit')
    @classmethod
    def nonblank(cls,value):
        if not value.strip():
            raise ValueError('A nonblank value is required')
        return value


class AIRunRequest(Input):
    attestation_id: UUID
    expected_fingerprint: str = Field(pattern=r'^[0-9a-f]{64}$')
