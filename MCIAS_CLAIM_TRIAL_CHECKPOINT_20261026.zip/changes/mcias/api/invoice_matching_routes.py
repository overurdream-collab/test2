"""Opt-in, source-private comparison in the existing claim workspace."""
from uuid import UUID

from fastapi import APIRouter, Depends, Header, HTTPException, Request
from sqlalchemy.exc import DBAPIError

from mcias.api import dependencies as deps
from mcias.api.features_routes import no_store
from mcias.models import AuditLog
from mcias.services import invoice_matching_service as service


router = APIRouter(prefix='/api/v1/claims/entries/{claim_id}/invoice-matches',
                   tags=['Native invoice candidate comparison'], dependencies=[Depends(no_store)])


def _privacy(actor=Depends(deps.require_permission(*service.PERMISSIONS)), db=Depends(deps.get_db)):
    return actor


@router.get('')
def preview(claim_id: UUID, request: Request, authorization: str | None = Header(default=None),
            actor=Depends(_privacy), db=Depends(deps.get_db)):
    try:
        result = service.preview(db, actor, str(claim_id))
        # A PDF may take time to parse: a revoked session/grant must not receive
        # sensitive values merely because it was authorized before parsing.
        db.expire_all()
        actor = deps.require_auth(request, authorization, db)
        deps.require_permission(*service.PERMISSIONS)(actor=actor, db=db)
        service.claim_for_actor(db, actor, str(claim_id))
        service.authorize_name_access(db, actor, result)
        db.add(AuditLog(actor_id=actor.id, organization_id=actor.organization_id,
            action='invoice_match.preview', resource_type='claim_entry', resource_id=str(claim_id),
            category='invoice_evidence', details={'status': result['status'],
                'documents': len(result['documents']), 'source_sha256': result['claim_source']['sha256'],
                'financial_effect': 'NONE'}))
        db.commit()
        return result
    except HTTPException:
        db.rollback()
        raise
    except LookupError:
        db.rollback()
        raise HTTPException(404, {'code': 'invoice_claim_not_found'}) from None
    except ValueError as exc:
        db.rollback()
        raise HTTPException(409, {'code': str(exc) if isinstance(exc, service.InvoiceMatchConflict)
                                  else 'invoice_match_conflict'}) from None
    except (RuntimeError, OSError, DBAPIError):
        db.rollback()
        raise HTTPException(503, {'code': 'invoice_preview_unavailable'}) from None
