"""One trial action reuses existing claim audit and frozen primary exports."""
from uuid import UUID

from fastapi import APIRouter, Depends, Header, HTTPException, Request
from sqlalchemy.exc import DBAPIError

from mcias.api import dependencies as deps
from mcias.api.features_routes import no_store
from mcias.services import claim_trial_service as service, invoice_matching_service as matching
from mcias.services.authorization_service import check_permission_unified

router = APIRouter(prefix='/api/v1/audits/batches/{batch_id}/trial-run',
    tags=['Claim trial'], dependencies=[Depends(no_store)])


def _perform(db, action):
    try:
        return action()
    except HTTPException:
        db.rollback(); raise
    except LookupError:
        db.rollback(); raise HTTPException(404, {'code': 'claim_trial_not_found'}) from None
    except ValueError:
        db.rollback(); raise HTTPException(409, {'code': 'claim_trial_conflict'}) from None
    except (RuntimeError, OSError, DBAPIError):
        db.rollback(); raise HTTPException(503, {'code': 'claim_trial_unavailable'}) from None


@router.post('', status_code=201)
def run(batch_id: UUID, request: Request, authorization: str | None = Header(default=None),
        actor=Depends(deps.require_permission(*matching.PERMISSIONS)), db=Depends(deps.get_db)):
    def action():
        result = service.execute(db, actor, str(batch_id))
        db.expire_all()
        current = deps.require_auth(request, authorization, db)
        deps.require_permission(*matching.PERMISSIONS)(actor=current, db=db)
        service._batch(db, current, str(batch_id))
        for row in result['rows']:
            matching.authorize_name_access(db, current, row['invoice_match'])
        if check_permission_unified(db, current, 'reports.create'):
            from mcias.services.result_service import freeze
            result['primary_outputs'] = freeze(db, current, str(batch_id), primary=True)
        db.commit()
        return result
    return _perform(db, action)


@router.get('')
def read(batch_id: UUID, actor=Depends(deps.require_permission(*matching.PERMISSIONS)), db=Depends(deps.get_db)):
    result = _perform(db, lambda: service.latest_trial(db, actor, str(batch_id)))
    if result is None:
        raise HTTPException(404, {'code': 'claim_trial_not_found'})
    return result
