"""Existing claim workspace's local A1 advisory review; no financial writes."""
from uuid import UUID

from fastapi import APIRouter, Depends, Header, HTTPException, Query, Request, Response
from sqlalchemy.exc import DBAPIError

from mcias.api import dependencies as deps
from mcias.api.features_routes import no_store
from mcias.schemas.ai_review import AIInputAttestation, AIRunRequest
from mcias.services import ai_evidence_service as evidence
from mcias.services import ai_review_service as service
from mcias.tenant import require_sensitive_field


CODES = ('claims.read','claims.review','ingestion.read')
router = APIRouter(prefix='/api/v1/claims/entries/{claim_id}/ai-review',
    tags=['Local A1 advisory review'], dependencies=[Depends(no_store)])


def _privacy(actor=Depends(deps.require_permission(*CODES)), db=Depends(deps.get_db)):
    require_sensitive_field(db, actor, actor.organization_id, 'text')
    return actor


def _perform(db, operation):
    try:
        return operation()
    except HTTPException:
        db.rollback()
        raise
    except LookupError:
        db.rollback()
        raise HTTPException(404, {'code':'ai_evidence_not_found'}) from None
    except (ValueError, service.AIReviewConflict) as exc:
        db.rollback()
        raise HTTPException(409, {'code':getattr(exc,'code','ai_evidence_conflict')}) from None
    except (RuntimeError, OSError, DBAPIError):
        db.rollback()
        raise HTTPException(503, {'code':'ai_review_unavailable'}) from None


@router.get('/evidence')
def sources(claim_id:UUID, actor=Depends(_privacy), db=Depends(deps.get_db)):
    return _perform(db, lambda:evidence.source_options(db,actor,str(claim_id)))


@router.post('/attestations', status_code=201)
def attest(claim_id:UUID, payload:AIInputAttestation,
           actor=Depends(_privacy), db=Depends(deps.get_db)):
    def action():
        result=evidence.attest(db,actor,str(claim_id),payload)
        db.commit()
        return result
    return _perform(db,action)


@router.get('/runs')
def runs(claim_id:UUID, offset:int=Query(0,ge=0), limit:int=Query(20,ge=1,le=100),
         actor=Depends(_privacy), db=Depends(deps.get_db)):
    return _perform(db,lambda:service.list_runs(db,actor,str(claim_id),offset,limit))


@router.get('/runs/{run_id}')
def read(claim_id:UUID, run_id:UUID, actor=Depends(_privacy), db=Depends(deps.get_db)):
    return _perform(db,lambda:service.read_run(db,actor,str(claim_id),str(run_id)))


@router.post('/runs', status_code=201)
def run(claim_id:UUID, payload:AIRunRequest, request:Request, response:Response,
        authorization:str|None=Header(default=None), actor=Depends(_privacy), db=Depends(deps.get_db)):
    identity=str(claim_id)
    prepared=_perform(db,lambda:service.prepare(db,actor,identity,str(payload.attestation_id),payload.expected_fingerprint))
    # Persist the immutable start before the potentially slow local inference.
    # This permits real pending-state reads and duplicate-run protection.
    _perform(db,db.commit)
    run_id=prepared['run']['id']
    if not prepared['execute']:
        response.status_code=200
        return _perform(db,lambda:service.read_run(db,actor,identity,run_id))
    evaluated=service.evaluate(prepared['input'],prepared['readiness'])
    db.expire_all()
    denied=None
    try:
        actor=deps.require_auth(request,authorization,db)
        deps.require_permission(*CODES)(actor=actor,db=db)
        require_sensitive_field(db,actor,actor.organization_id,'text')
        evidence.authorize_fields(db,actor,prepared['input'])
    except HTTPException as exc:
        denied=exc
        db.rollback()
    def finish():
        service.complete(db,actor,identity,run_id,evaluated,
            blocked_code='ai_authorization_changed' if denied else None)
        db.commit()
        if denied:
            raise HTTPException(denied.status_code,{'code':'ai_authorization_changed'})
        return service.read_run(db,actor,identity,run_id)
    return _perform(db,finish)
