# حزمة حفظ تجربة المطالبة — 26 أكتوبر 2026

هذه حزمة مراجعة وتحديث محلي، وليست برنامج تثبيت أو نشرًا على GitHub.
الأساس الوحيد: `daaed6a1d271933adaff8b899b0bb63ee48fb725`، الفرع
`feat/windows-laptop-testing`. تضم التغييرات المحلية التراكمية لـA1 والمقارنة النصية
وتجربة المطالبة؛ لا تحتاج تطبيق حزم 24 أكتوبر فوقها أو تحتها.

لا تطبق `changes.patch` على شجرة تحتوي التعديلات نفسها، أو على Commit مختلف، أو مع
تعديلات محلية. توقف عند الاختلاف؛ لا تستخدم Reset أو Force أو الكتابة فوق الملفات.
لم يحدث Commit أو Push أو Merge، ولا تتضمن الحزمة قاعدة بيانات أو مفاتيح أو أوزان نماذج.

## المراجعة والتطبيق على نسخة نظيفة من الأساس المحدد

فك الحزمة خارج مجلد Git أولًا. من PowerShell داخل نسخة المشروع النظيفة:

```powershell
$Expected = 'daaed6a1d271933adaff8b899b0bb63ee48fb725'
if ((git rev-parse HEAD).Trim() -ne $Expected) { throw 'توقف: Commit مختلف؛ يلزم فحص التوافق' }
if ((git branch --show-current).Trim() -ne 'feat/windows-laptop-testing') { throw 'توقف: الفرع مختلف' }
if (git status --porcelain) { throw 'توقف: توجد تعديلات محلية؛ لا تكتب فوقها' }
$Patch = 'C:\MCIAS_CLAIM_TRIAL_CHECKPOINT_20261026\changes.patch'
git apply --check -- $Patch
if ($LASTEXITCODE -ne 0) { throw 'توقف: لم ينجح فحص التحديث؛ لا تطبقه قسرًا' }
git apply -- $Patch
if ($LASTEXITCODE -ne 0) { throw 'توقف: افحص سبب تعذر التطبيق' }
```

عدّل مسار `$Patch` فقط إلى مكان الملف المفكوك، وراجع `progress-report.md` وملفات
الأدلة و`receipt.json`. قبل التوزيع المؤسسي يلزم اعتماد مستقل؛ نجاح الفحوص ليس قبولًا إنتاجيًا.

بعد تطبيق التحديث، مع جاهزية Docker Desktop:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\laptop.ps1 -Action Start -InvoiceTrial
powershell -NoProfile -ExecutionPolicy Bypass -File .\scripts\laptop.ps1 -Action Check -InvoiceTrial
```

بيانات الحساب المحلي لا تشارك في المحادثة؛ تظهر على الجهاز عبر `-Action Credentials`.
ارفع عينات `samples/` من شاشة التدقيق واربط فاتورة PDF ببند الخدمة، ثم ابدأ التدقيق
وافتح أسباب النتيجة ونزّل المخرجين. الصافي الاصطناعي المرجعي 900 بعد تحمل100 من1000.

الغياب الافتراضي لسياسة مالية موقعة يبقي العينة ضمن «يحتاج إجراء»، مع استمرار فحوص
المدخلات والمقارنة؛ لا تمنح هذه الحزمة توقيعًا أو صلاحية مالية لتجاوز هذا الشرط.
كل بند يظهر مرة واحدة في المقبول مبدئيًا أو يحتاج إجراء. الأصل والتاريخ محفوظان.

الحد الحالي100 بند. PDF نصي معنّون فقط؛ OCR والتحقيق الاستكشافي ليسا منفذين في هذه
الدورة. راجع الأدلة لحدود إثبات Docker/Windows؛ لا تفترض نجاح Windows أو MFA دون
تجربة فعلية موثقة على اللابتوب. الحزمة لا تغيّر إعدادات Git ولا تنشر ملفات تلقائيًا.
